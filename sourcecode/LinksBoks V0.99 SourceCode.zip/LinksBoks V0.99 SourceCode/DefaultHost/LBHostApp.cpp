
#include "LBHostApp.h"
#include <stdio.h>

#define XBOX_DEFAULT_VERTICAL_MARGIN	30
#define XBOX_DEFAULT_HORIZONTAL_MARGIN	40
#define XBOX_DEFAULT_SENSITIVITY		8
#define XBOX_DEFAULT_DEADZONE			8
#define XBOX_DEFAULT_REPEAT_RATE		120

#define LINKSBOKS_REFRESH_RATE		((g_CurrentMode.standard == XC_VIDEO_STANDARD_PAL_I) ? 15 : 12)


/* The one and only LinksBoks "instance" (window).
Multiple windows will be supported in the future */
LinksBoksWindow *g_pLB = NULL;

/* Table of the custom options for this host app. Provided to LinksBoks_InitCore. */
LinksBoksOption *g_LBHostOptions[] = {
	new LinksBoksOption(NULL, "Xbox-specific options", LINKSBOKS_OPTION_GROUP, 0),
		new LinksBoksOption(NULL, "Network settings (need restart)", LINKSBOKS_OPTION_GROUP, 1),
			new LinksBoksNetworkOption("xbox_network_custom_conf", "Reconfigure network", LINKSBOKS_OPTION_BOOL, 2, 0),
			new LinksBoksNetworkOption("xbox_network_dhcp", "Use DHCP? (instead of static configuration below)", LINKSBOKS_OPTION_BOOL, 2, 1),
			new LinksBoksNetworkOption("xbox_network_ip", "[static only] IP address", LINKSBOKS_OPTION_STRING, 2, (unsigned char *)"192.168.0.28"),
			new LinksBoksNetworkOption("xbox_network_netmask", "[static only] Subnet mask", LINKSBOKS_OPTION_STRING, 2, (unsigned char *)"255.255.255.0"),
			new LinksBoksNetworkOption("xbox_network_gateway", "[static only] Gateway address", LINKSBOKS_OPTION_STRING, 2, (unsigned char *)"192.168.0.1"),
			new LinksBoksNetworkOption("xbox_network_dns", "[static only] DNS server address", LINKSBOKS_OPTION_STRING, 2, (unsigned char *)"192.168.0.1"),
		new LinksBoksOption(NULL, "Video modes", LINKSBOKS_OPTION_GROUP, 1),
			new LinksBoksOption("xbox_no_hdtv", "Disable HDTV", LINKSBOKS_OPTION_BOOL, 2, 0),
			new LinksBoksOption("xbox_no_1080i", "Bypass 1080i detection", LINKSBOKS_OPTION_BOOL, 2, 0),
			new LinksBoksOption("xbox_no_720p", "Bypass 720p detection", LINKSBOKS_OPTION_BOOL, 2, 0),
		new LinksBoksOption(NULL, "Screen margins", LINKSBOKS_OPTION_GROUP, 1),
			new LinksBoksGUIOption("xbox_margin_top"," Top margin", LINKSBOKS_OPTION_INT, 2, XBOX_DEFAULT_HORIZONTAL_MARGIN),
			new LinksBoksGUIOption("xbox_margin_bottom"," Bottom margin", LINKSBOKS_OPTION_INT, 2, XBOX_DEFAULT_HORIZONTAL_MARGIN),
			new LinksBoksGUIOption("xbox_margin_left", "Left margin", LINKSBOKS_OPTION_INT, 2, XBOX_DEFAULT_VERTICAL_MARGIN),
			new LinksBoksGUIOption("xbox_margin_right", "Right margin", LINKSBOKS_OPTION_INT, 2, XBOX_DEFAULT_VERTICAL_MARGIN),
		new LinksBoksOption(NULL, "Mouse pointer sensitivity", LINKSBOKS_OPTION_GROUP, 1),
			new LinksBoksGUIOption("xbox_mouse_sensitivity_x", "X sensitivity", LINKSBOKS_OPTION_INT, 2, XBOX_DEFAULT_SENSITIVITY),
			new LinksBoksGUIOption("xbox_mouse_sensitivity_y", "Y sensitivity", LINKSBOKS_OPTION_INT, 2, XBOX_DEFAULT_SENSITIVITY),
			new LinksBoksGUIOption("xbox_mouse_deadzone", "Gamepad thumbsticks dead zone (0 to 100)", LINKSBOKS_OPTION_INT, 2, XBOX_DEFAULT_DEADZONE),
		new LinksBoksGUIOption("xbox_repeat_rate", "D-pad/keypad repeat rate", LINKSBOKS_OPTION_INT, 1, XBOX_DEFAULT_REPEAT_RATE),
		NULL
};

LinksBoksProtocol *g_LBHostProtocols[] = {
	new LinksBoksHostProtocol(),
	NULL
};

VOID LinksBoksGUIOption::OnAfterChange(void *session)
{
	UpdateXboxOptions();
}

BOOL LinksBoksNetworkOption::OnBeforeChange(void *session, unsigned char *oldvalue, unsigned char *newvalue)
{
	if(inet_addr((const char *)newvalue) == INADDR_NONE)
	{
		MsgBox(session, (unsigned char *)"Invalid network address", (unsigned char *)"This doesn't look like a IP address! Please put an correct IP address (for example, 192.168.0.1).");
		return FALSE;
	}

	return TRUE;
}

VOID LinksBoksNetworkOption::OnAfterChange(void *session)
{
	MsgBox(session, (unsigned char *)"Network configuration", (unsigned char *)"Please save your options, then quit and restart LinksBoks to apply the new network settings.");
}


/* Update the variables from options and force a viewport resize. This function should be
called when updating the options. */
void UpdateXboxOptions()
{
	g_CurrentMode.viewport.margin_top = LinksBoks_GetOptionInt("xbox_margin_top");
	g_CurrentMode.viewport.margin_bottom = LinksBoks_GetOptionInt("xbox_margin_bottom");
	g_CurrentMode.viewport.margin_left = LinksBoks_GetOptionInt("xbox_margin_left");
	g_CurrentMode.viewport.margin_right = LinksBoks_GetOptionInt("xbox_margin_right");
	g_MouseSensitivityX = LinksBoks_GetOptionInt("xbox_mouse_sensitivity_x");
	g_MouseSensitivityY = LinksBoks_GetOptionInt("xbox_mouse_sensitivity_y");
	g_KeyRepeatRate = LinksBoks_GetOptionInt("xbox_repeat_rate");
	g_GamepadDeadZone = (FLOAT)LinksBoks_GetOptionInt("xbox_mouse_deadzone")/100.f;

	if(g_pLB)
		g_pLB->ResizeWindow(g_CurrentMode.viewport);
}


/* Handling of the custom "linksboks:" protocol. */
int LinksBoksHostProtocol::OnCall(unsigned char *url, void *connection)
{
	char *body = NULL;
	
	if(!strcmp((const char *)url, "linksboks:network"))
		body = GetNetworkStatusHTML();

	if(body)
	{
        SendResponse(connection, (unsigned char *)"text/html", (unsigned char *)body, strlen(body));
		delete[] body;
		return LINKSBOKS_RESPONSE_OK;
	}
	else
	{
		return LINKSBOKS_RESPONSE_BAD_URL;
	}
}


/* Function called when trying to open a known type. We get a stupid "commandline"
string to identify what to do, the file path, the fg parameter is not too important :)
If we return <0, the file isn't deleted after we return */
int LaunchViewer(LinksBoksWindow *pLB, unsigned char *cmdline, unsigned char *filepath, int fg)
{
	if(strlen((const char *)cmdline) > 3 && !strncmp("swfx", (const char *)cmdline, 4))
	{
		if(!FlashPlayerInit(pLB, cmdline, filepath, fg))
			g_InputMode = FLASH_PLAYER_MODE;
	}

	return 0;
}

/* This is the LinksBoks loopback function which will be called by the lib regularly
during LinksBoks_FrameMove() because of the registered timer. We do this like that
only to ensure that the screen update won't occur more than needed (50/60 Hz), that
way we get a smoother scrolling.
There is absolutely no need to retrieve the front buffer surface or call Present() in
there, you could simply wait for LinksBoks_FrameMove() to return and do it
afterwards */
static void xbox_check_events( void *pointer )
{
	struct keygroup *kg;

	LPDIRECT3DSURFACE8 pBackBuffer;
	g_pd3dDevice->GetBackBuffer( 0, D3DBACKBUFFER_TYPE_MONO, &pBackBuffer );

	UpdateInput( );

	/* Here's the rendering!
	Copies the LinksBoks front buffer surface directly on the D3D backbuffer */
	g_pd3dDevice->CopyRects( g_pLB->GetSurface(), NULL, 0, pBackBuffer, NULL );


	/* The rest of the function is some logic specific to this host application.
	Handles the mode-based (navigation, text entry...) user input and renders stuff over
	the browser image, directly on the backbuffer */

	switch( g_InputMode )
	{
		case NAVIGATION_MODE:
			HandleGeneralBindings( g_pLB );
			HandleInputNavMode( g_pLB );

			// Render mouse pointer
			g_pLB->CreatePrimitive( (int)g_MouseX - MOUSE_HOTSPOT_X, (int)g_MouseY - MOUSE_HOTSPOT_Y, 32, 32, 0xffffffff );
			g_pd3dDevice->SetTexture( 0, g_pMousePtr );
			g_pLB->RenderPrimitive( pBackBuffer );
			g_pd3dDevice->SetTexture( 0, NULL );

			break;
		case TEXT_INPUT_MODE:
			HandleGeneralBindings( g_pLB );
			kg = GetCurrentKeyGroup();
			HandleInputTextMode( g_pLB, kg );
			DrawTextInputStuff( pBackBuffer );

			break;
		case KEYPAD_MODE:
			HandleGeneralBindings( g_pLB );
			HandleInputKeypadMode( g_pLB );
			DrawKeyPad( pBackBuffer, &g_Font18 );

			break;
		case VIDEO_CALIBRATION_MODE:
			HandleGeneralBindings( g_pLB );
			HandleInputCalibrationMode( g_pLB );
			DrawCalibrationScreen( pBackBuffer );

			break;
		case FLASH_PLAYER_MODE:
			LockFlashSurface();
			HandleInputForFlashPlayer( g_pLB );
			DrawFlashPlayer( g_pLB, pBackBuffer );
			UnlockFlashSurface();

			// Render mouse pointer
			g_pLB->CreatePrimitive( (int)g_MouseX - MOUSE_HOTSPOT_X, (int)g_MouseY - MOUSE_HOTSPOT_Y, 32, 32, 0xffffffff );
			g_pd3dDevice->SetTexture( 0, g_pMousePtr );
			g_pLB->RenderPrimitive( pBackBuffer );
			g_pd3dDevice->SetTexture( 0, NULL );

			break;
		default:
			break;
	}

	g_pd3dDevice->Present( NULL, NULL, NULL, NULL );

	pBackBuffer->Release();


	/* Before returning, the timer has to be re-registered so that this function will
	be called again */
	LinksBoks_RegisterNewTimer( LINKSBOKS_REFRESH_RATE, xbox_check_events, NULL );
}



/* The application's entry point... */
void __cdecl main()
{
	/* First, let's initializes the LinksBoks core, with the provided custom options and protocols */
	LinksBoks_InitCore(g_LBHostOptions, g_LBHostProtocols);

	/* >> At this point the options are registered
	and loaded so you can start accessing them */

	/* Initializes the Xbox D3D system (accesses options to choose the video mode and so on) */
	if( InitGraphics() )
		exit( 1 );

	/* Mount drives & Initialize the Xbox network (accesses options for network paramters) */
	if( InitXboxSystems() )
		exit( 1 );

	/* Ok, we're still here, so we can create our LinksBoksWindow object.
	Since this is the first one, the LinksBoks engine will finish initializing its last
	subsystems (including the graphics driver). */
	g_pLB = LinksBoks_CreateWindow(g_pD3D, g_pd3dDevice, g_CurrentMode.viewport);
	if( !g_pLB )
		exit( 1 );

	/* Let's call this before beginning the loop */
	UpdateXboxOptions();

	/* Register our function for external viewers, in our case the flash miniplayer only.
	We can do this at any time, even change it during execution */
	LinksBoks_SetExecFunction(LaunchViewer);

	/* One last thing to do: register a timer to call the rendering function every
	15ms (NTSC) or 20ms (PAL) */
	LinksBoks_RegisterNewTimer( LINKSBOKS_REFRESH_RATE, xbox_check_events, NULL );


	/* Hey, that's our main loop! We do nothing specific because everything is handled by our
	timer callback */
	do
	{
	}
	while(!LinksBoks_FrameMove());

	/* We're done! */

	/* Clean everything up */
	LinksBoks_Terminate(FALSE);
	//terminate_all_subsystems();

	/* And launch the dashboard; bye! */
	LD_LAUNCH_DASHBOARD LaunchData = { XLD_LAUNCH_DASHBOARD_MAIN_MENU };
	XLaunchNewImage( NULL, (LAUNCH_DATA*)&LaunchData );
}

