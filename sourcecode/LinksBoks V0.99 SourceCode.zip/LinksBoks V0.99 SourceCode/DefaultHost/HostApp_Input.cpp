/*
 * LinksBoks
 * Copyright (c) 2003-2004 ysbox
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "LBHostApp.h"

INT g_MouseSensitivityX, g_MouseSensitivityY;
INT g_KeyRepeatRate;
FLOAT g_GamepadDeadZone;
FLOAT g_MouseX = 320, g_MouseY = 240;
FLOAT g_OldMouseX = 320, g_OldMouseY = 240;
FLOAT g_Borders[4];
XBGAMEPAD*             g_Gamepad;
XBGAMEPAD              g_DefaultGamepad;
DWORD g_lastKeyRepeat = 0;
BOOL g_kpWaitingStickRelease = FALSE;
BYTE g_lastMouseButtons;


static void xbox_translate_key( XINPUT_DEBUG_KEYSTROKE *stroke, int *key, int *flag )
{
	*key  = 0;
	*flag = 0;

	if( (stroke->Flags & XINPUT_DEBUG_KEYSTROKE_FLAG_CTRL) &&
		(stroke->Ascii == 'c') )
	{
		*key = LINKSBOKS_KBD_CTRL_C;
		return;
	}

	/* setting Shift seems to break things
	*
	*  if (event->modifiers & DIMM_SHIFT)
	*     *flag |= LINKSBOKS_KBD_SHIFT;
	*/

	if( stroke->Flags & XINPUT_DEBUG_KEYSTROKE_FLAG_CTRL )
		*flag |= LINKSBOKS_KBD_CTRL;
	if( stroke->Flags & XINPUT_DEBUG_KEYSTROKE_FLAG_ALT )
		*flag |= LINKSBOKS_KBD_ALT;

	switch( stroke->VirtualKey )
	{
		case VK_RETURN:	*key = LINKSBOKS_KBD_ENTER;     break;
		case VK_BACK:	*key = LINKSBOKS_KBD_BS;        break;
		case VK_TAB:	*key = LINKSBOKS_KBD_TAB;       break;
		case VK_ESCAPE:	*key = LINKSBOKS_KBD_ESC;       break;
		case VK_UP:		*key = LINKSBOKS_KBD_UP;        break;
		case VK_DOWN:	*key = LINKSBOKS_KBD_DOWN;      break;
		case VK_LEFT:	*key = LINKSBOKS_KBD_LEFT;      break;
		case VK_RIGHT:	*key = LINKSBOKS_KBD_RIGHT;     break;
		case VK_INSERT:	*key = LINKSBOKS_KBD_INS;       break;
		case VK_DELETE:	*key = LINKSBOKS_KBD_DEL;       break;
		case VK_HOME:	*key = LINKSBOKS_KBD_HOME;      break;
		case VK_END:	*key = LINKSBOKS_KBD_END;       break;
		case VK_PRIOR:	*key = LINKSBOKS_KBD_PAGE_UP;   break;
		case VK_NEXT:	*key = LINKSBOKS_KBD_PAGE_DOWN; break;
		case VK_F1:		*key = LINKSBOKS_KBD_F1;        break;
		case VK_F2:		*key = LINKSBOKS_KBD_F2;        break;
		case VK_F3:		*key = LINKSBOKS_KBD_F3;        break;
		case VK_F4:		*key = LINKSBOKS_KBD_F4;        break;
		case VK_F5:		*key = LINKSBOKS_KBD_F5;        break;
		case VK_F6:		*key = LINKSBOKS_KBD_F6;        break;
		case VK_F7:		*key = LINKSBOKS_KBD_F7;        break;
		case VK_F8:		*key = LINKSBOKS_KBD_F8;        break;
		case VK_F9:		*key = LINKSBOKS_KBD_F9;        break;
		case VK_F10:	*key = LINKSBOKS_KBD_F10;       break;
		case VK_F11:	*key = LINKSBOKS_KBD_F11;       break;
		case VK_F12:	*key = LINKSBOKS_KBD_F12;       break;

		default:
			*key = stroke->Ascii;
			break;
	}
}


HRESULT InitXboxInput()
{
    HRESULT hr;
	
	XInitDevices( 0, NULL );

    // Create the gamepad devices
	OutputDebugString( "XBApp: Creating gamepad devices...\n" );
    if( FAILED( hr = XBInput_CreateGamepads( &g_Gamepad ) ) )
    {
		OutputDebugString( "Call to CreateGamepads() failed!\n" );
        return hr;
    }

    // Initialize the debug keyboard
    if( FAILED( hr = XBInput_InitDebugKeyboard() ) )
	{
		OutputDebugString( "Failed to initialize keyboard!\n" );
        return hr;
	}

    // Initialize the debug mouse
    if( FAILED( hr = XBInput_InitDebugMouse() ) )
	{
		OutputDebugString( "Failed to initialize mouse!\n" );
        return hr;
	}

	return S_OK;
}


VOID UpdateInput()
{
	DWORD i;

    //-----------------------------------------
    // Handle input
    //-----------------------------------------

	if( (g_lastKeyRepeat > 0) && (timeGetTime( ) - g_lastKeyRepeat > g_KeyRepeatRate) )
	{
		// Handle d-pad repeat rate!
	    for( i=0; i<4; i++ )
			g_Gamepad[i].wLastButtons &= 0x11111110;

		g_lastKeyRepeat = 0;
	}


	// Read the input for all connected gamepads
    XBInput_GetInput( g_Gamepad );




    // Lump inputs of all connected gamepads into one common structure.
    // This is done so apps that need only one gamepad can function with
    // any gamepad.
    ZeroMemory( &g_DefaultGamepad, sizeof(g_DefaultGamepad) );

    for( i=0; i<4; i++ )
    {
        if( g_Gamepad[i].hDevice )
        {
            // Only account for thumbstick info beyond the deadzone
            if( abs(g_Gamepad[i].fX1) > abs(g_GamepadDeadZone))
	            g_DefaultGamepad.fX1 += g_Gamepad[i].fX1;
			if( abs(g_Gamepad[i].fY1) > abs(g_GamepadDeadZone))
	            g_DefaultGamepad.fY1 += g_Gamepad[i].fY1;
            if( abs(g_Gamepad[i].fX2) > abs(g_GamepadDeadZone))
	            g_DefaultGamepad.fX2 += g_Gamepad[i].fX2;
            if( abs(g_Gamepad[i].fY2) > abs(g_GamepadDeadZone))
	            g_DefaultGamepad.fY2 += g_Gamepad[i].fY2;

            g_DefaultGamepad.wButtons         |= g_Gamepad[i].wButtons;
            g_DefaultGamepad.wPressedButtons  |= g_Gamepad[i].wPressedButtons;
            g_DefaultGamepad.wReleasedButtons |= g_Gamepad[i].wReleasedButtons;
            g_DefaultGamepad.wLastButtons     |= g_Gamepad[i].wLastButtons;

            for( DWORD b=0; b<8; b++ )
            {
                g_DefaultGamepad.bAnalogButtons[b]         |= g_Gamepad[i].bAnalogButtons[b];
                g_DefaultGamepad.bPressedAnalogButtons[b]  |= g_Gamepad[i].bPressedAnalogButtons[b];
                g_DefaultGamepad.bReleasedAnalogButtons[b] |= g_Gamepad[i].bReleasedAnalogButtons[b];
                g_DefaultGamepad.bLastAnalogButtons[b]     |= g_Gamepad[i].bLastAnalogButtons[b];
            }
        }
    }

    // Handle special input combo to trigger a reboot to the Xbox Dashboard
    if( g_DefaultGamepad.bAnalogButtons[XINPUT_GAMEPAD_LEFT_TRIGGER] > 0 )
    {
        if( g_DefaultGamepad.bAnalogButtons[XINPUT_GAMEPAD_RIGHT_TRIGGER] > 0 )
        {
            if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_BLACK] )
            {
                LD_LAUNCH_DASHBOARD LaunchData = { XLD_LAUNCH_DASHBOARD_MAIN_MENU };
			    XLaunchNewImage( NULL, (LAUNCH_DATA*)&LaunchData );
            }
        }
    }

}

VOID HandleGeneralBindings(LinksBoksWindow *pLB)
{

	// Left thumbstick pressed => change input mode
	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_LEFT_THUMB) == XINPUT_GAMEPAD_LEFT_THUMB)
	{
		g_InputMode = (g_InputMode == NAVIGATION_MODE) ? TEXT_INPUT_MODE : NAVIGATION_MODE;
	}

	// That's it for the video calibration mode
	if( g_InputMode == VIDEO_CALIBRATION_MODE )
		return;

	// Back pressed => video calibration mode
	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_BACK) == XINPUT_GAMEPAD_BACK )
	{
		g_Borders[0] = (FLOAT)LinksBoks_GetOptionInt("xbox_margin_top");
		g_Borders[1] = (FLOAT)LinksBoks_GetOptionInt("xbox_margin_bottom");
		g_Borders[2] = (FLOAT)LinksBoks_GetOptionInt("xbox_margin_left");
		g_Borders[3] = (FLOAT)LinksBoks_GetOptionInt("xbox_margin_right");
		g_DefaultGamepad.wPressedButtons ^= XINPUT_GAMEPAD_BACK;
		g_InputMode = VIDEO_CALIBRATION_MODE;
		return;
	}

	// Debug keyboard: simply "translate" the keystroke and pass it to the keyboard handler
	XINPUT_DEBUG_KEYSTROKE *kbdStroke;
	int kbkey, kbflag;
	while( kbdStroke = XBInput_GetKeyboardInput() )
	{
		xbox_translate_key( kbdStroke, &kbkey, &kbflag );
		pLB->KeyboardAction( kbkey, kbflag );
	}

	// Start pressed => ENTER
	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_START) == XINPUT_GAMEPAD_START )
	{
		pLB->KeyboardAction( LINKSBOKS_KBD_ENTER, 0 );
	}

	// Pressing right thumbstick pastes
/*	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_RIGHT_THUMB) )
	{
		if( dev )
			pLB->KeyboardAction( LINKSBOKS_KBD_PASTE, 0 );
	}
doesn't work
*/

	// Directions on the dpad => equivalent arrow keys
	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_DPAD_LEFT) == XINPUT_GAMEPAD_DPAD_LEFT )
	{
		g_lastKeyRepeat = timeGetTime( );
		pLB->KeyboardAction( LINKSBOKS_KBD_LEFT, 0 );
	}
	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_DPAD_RIGHT) == XINPUT_GAMEPAD_DPAD_RIGHT )
	{
		g_lastKeyRepeat = timeGetTime( );
		pLB->KeyboardAction( LINKSBOKS_KBD_RIGHT, 0 );
	}
	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_DPAD_UP) == XINPUT_GAMEPAD_DPAD_UP )
	{
		g_lastKeyRepeat = timeGetTime( );
		pLB->KeyboardAction( LINKSBOKS_KBD_UP, 0 );
	}
	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_DPAD_DOWN) == XINPUT_GAMEPAD_DPAD_DOWN )
	{
		g_lastKeyRepeat = timeGetTime( );
		pLB->KeyboardAction( LINKSBOKS_KBD_DOWN, 0 );
	}

}


VOID UpdateMouseStatus( LinksBoksWindow *pLB, XINPUT_STATE *currentMouseState, BYTE *mousePressedButtons, BYTE *mouseReleasedButtons )
{
	//-----------------------------------------
    // Update mouse position
    //-----------------------------------------

	// Poll debug mouse too
    DWORD dwMousePortsChanged = XBInput_GetMouseInput();
    ZeroMemory( currentMouseState, sizeof(XINPUT_STATE) );

    for( DWORD i=0; i < XGetPortCount() * 2; i++ )
    {
        if( dwMousePortsChanged & ( 1 << i ) ) 
            *currentMouseState = g_MouseState[i];
    }

	if( dwMousePortsChanged )
    {
		// TRUE HACK: Change the values in the gamepad structures
        FLOAT fRotX1 = 0.0f, fRotY1 = 0.0f;
        g_DefaultGamepad.fX1 += currentMouseState->DebugMouse.cMickeysX / (96.0f / (float)g_MouseSensitivityX);
        g_DefaultGamepad.fY1 -= currentMouseState->DebugMouse.cMickeysY / (96.0f / (float)g_MouseSensitivityY);
	}
	*mousePressedButtons = (g_lastMouseButtons ^ currentMouseState->DebugMouse.bButtons) & currentMouseState->DebugMouse.bButtons;
	*mouseReleasedButtons = (g_lastMouseButtons ^ currentMouseState->DebugMouse.bButtons) & (currentMouseState->DebugMouse.bButtons ^ 0xFF);
	g_lastMouseButtons = currentMouseState->DebugMouse.bButtons;



	// END debug mouse


	int g_OldMouseX = (int)g_MouseX, g_OldMouseY = (int)g_MouseY;
	g_MouseX += g_DefaultGamepad.fX1 * g_MouseSensitivityX;
	if( g_MouseX < 0 )
		g_MouseX = 0;
	if( g_MouseX > pLB->GetViewPortWidth() )
		g_MouseX = (float)pLB->GetViewPortWidth();

	g_MouseY -= g_DefaultGamepad.fY1 * g_MouseSensitivityY;
	if( g_MouseY < 0 )
		g_MouseY = 0;
	if( g_MouseY > pLB->GetViewPortHeight() )
		g_MouseY = (float)pLB->GetViewPortHeight();
}


/*****************************************************************************/
/***************************** NAVIGATION MODE *******************************/
/*****************************************************************************/

VOID HandleInputNavMode( LinksBoksWindow *pLB )
{
	BYTE mousePressedButtons, mouseReleasedButtons;
	XINPUT_STATE CurrentMouseState;

	UpdateMouseStatus(pLB, &CurrentMouseState, &mousePressedButtons, &mouseReleasedButtons);

	//-----------------------------------------
    // Call handlers
    //-----------------------------------------
	int flags;	


	// "Wheel movement" (right thumbstick or mouse wheel)
	if( abs(g_DefaultGamepad.fY2) > 0.2 )
	{
		// Up/down
		if( g_DefaultGamepad.fY2 > 0 )
			pLB->MouseAction( (int)g_MouseX, (int)g_MouseY,
					(abs(g_DefaultGamepad.fY2) > 0.8) ? LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELUP : LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELUP1 );
		else
			pLB->MouseAction( (int)g_MouseX, (int)g_MouseY,
					(abs(g_DefaultGamepad.fY2) > 0.8) ? LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELDOWN : LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELDOWN1 );
	}
	if( abs(g_DefaultGamepad.fX2) > 0.2 )
	{
		// Left/right
		if( g_DefaultGamepad.fX2 > 0 )
			pLB->MouseAction( (int)g_MouseX, (int)g_MouseY,
					(abs(g_DefaultGamepad.fX2) > 0.8) ? LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELRIGHT : LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELRIGHT1 );
		else
			pLB->MouseAction( (int)g_MouseX, (int)g_MouseY,
					(abs(g_DefaultGamepad.fX2) > 0.8) ? LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELLEFT : LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELLEFT1 );
	}
	if( CurrentMouseState.DebugMouse.cWheel )
	{
		// Up/down (debug mouse wheel)
		if( CurrentMouseState.DebugMouse.cWheel > 0 )
			pLB->MouseAction( (int)g_MouseX, (int)g_MouseY,
					(abs(CurrentMouseState.DebugMouse.cWheel) > 2) ? LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELUP : LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELUP );
		else
			pLB->MouseAction( (int)g_MouseX, (int)g_MouseY,
					(abs(CurrentMouseState.DebugMouse.cWheel) > 2) ? LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELDOWN : LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELDOWN );
	}


	// Mouse movement (left thumbstick)
	if( ((int)g_MouseX != (int)g_OldMouseX) || ((int)g_MouseY != (int)g_OldMouseY) )
	{
		flags = 0;

		if( (g_DefaultGamepad.bAnalogButtons[XINPUT_GAMEPAD_A] > XINPUT_GAMEPAD_MAX_CROSSTALK)
			|| (CurrentMouseState.DebugMouse.bButtons & XINPUT_DEBUG_MOUSE_LEFT_BUTTON))
			flags = LINKSBOKS_MOUSE_LEFT | LINKSBOKS_MOUSE_DRAG;

		if( (g_DefaultGamepad.bAnalogButtons[XINPUT_GAMEPAD_X] > XINPUT_GAMEPAD_MAX_CROSSTALK)
			|| (CurrentMouseState.DebugMouse.bButtons & XINPUT_DEBUG_MOUSE_RIGHT_BUTTON))
			flags = LINKSBOKS_MOUSE_RIGHT | LINKSBOKS_MOUSE_DRAG;

		if( (g_DefaultGamepad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB)
			|| (CurrentMouseState.DebugMouse.bButtons & XINPUT_DEBUG_MOUSE_MIDDLE_BUTTON))
			flags = LINKSBOKS_MOUSE_MIDDLE | LINKSBOKS_MOUSE_DRAG;

		if( !flags )
			flags |= LINKSBOKS_MOUSE_MOVE;
		
		pLB->MouseAction( (int)g_MouseX, (int)g_MouseY, flags);
	}


	// A (left mouse button) or X (right mouse button) pressed
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_A]
		|| g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_X]
		|| (mousePressedButtons & XINPUT_DEBUG_MOUSE_LEFT_BUTTON)
		|| (mousePressedButtons & XINPUT_DEBUG_MOUSE_RIGHT_BUTTON)
		|| (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_RIGHT_THUMB)
		|| (mousePressedButtons & XINPUT_DEBUG_MOUSE_MIDDLE_BUTTON))
	{
		flags = 0;

		if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_A]
		|| (mousePressedButtons & XINPUT_DEBUG_MOUSE_LEFT_BUTTON))
		{
			flags |= LINKSBOKS_MOUSE_LEFT;
		}

		if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_X]
		|| (mousePressedButtons & XINPUT_DEBUG_MOUSE_RIGHT_BUTTON))
		{
			flags |= LINKSBOKS_MOUSE_RIGHT;
		}

		if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_RIGHT_THUMB)
		|| (mousePressedButtons & XINPUT_DEBUG_MOUSE_MIDDLE_BUTTON))
		{
			flags |= LINKSBOKS_MOUSE_MIDDLE;
		}


		flags |= LINKSBOKS_MOUSE_DOWN;
		

		pLB->MouseAction( (int)g_MouseX, (int)g_MouseY, flags);

		return;
	}

	// A (left mouse button) or X (right mouse button) released
	if( g_DefaultGamepad.bReleasedAnalogButtons[XINPUT_GAMEPAD_A]
		|| g_DefaultGamepad.bReleasedAnalogButtons[XINPUT_GAMEPAD_X]
		|| (mouseReleasedButtons & XINPUT_DEBUG_MOUSE_LEFT_BUTTON)
		|| (mouseReleasedButtons & XINPUT_DEBUG_MOUSE_RIGHT_BUTTON)
		|| (g_DefaultGamepad.wReleasedButtons & XINPUT_GAMEPAD_RIGHT_THUMB)
		|| (mouseReleasedButtons & XINPUT_DEBUG_MOUSE_MIDDLE_BUTTON))
{
		flags = 0;

		if( g_DefaultGamepad.bReleasedAnalogButtons[XINPUT_GAMEPAD_A]
		|| (mouseReleasedButtons & XINPUT_DEBUG_MOUSE_LEFT_BUTTON))
		{		
			flags |= LINKSBOKS_MOUSE_LEFT;
		}

		if( g_DefaultGamepad.bReleasedAnalogButtons[XINPUT_GAMEPAD_X]
		|| (mouseReleasedButtons & XINPUT_DEBUG_MOUSE_RIGHT_BUTTON))
		{
			flags |= LINKSBOKS_MOUSE_RIGHT;
		}

		if( (g_DefaultGamepad.wReleasedButtons & XINPUT_GAMEPAD_RIGHT_THUMB)
		|| (mouseReleasedButtons & XINPUT_DEBUG_MOUSE_MIDDLE_BUTTON))
		{
			flags |= LINKSBOKS_MOUSE_MIDDLE;
		}

		flags |= LINKSBOKS_MOUSE_UP;
		
		pLB->MouseAction( (int)g_MouseX, (int)g_MouseY, flags);

		return;
	}

	// left trigger pressed => back
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_LEFT_TRIGGER] ||
		(mousePressedButtons & XINPUT_DEBUG_MOUSE_XBUTTON1))
	{
		pLB->KeyboardAction( (int)'z', 0 );
	}

	// right trigger pressed => forward
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_RIGHT_TRIGGER] ||
		(mousePressedButtons & XINPUT_DEBUG_MOUSE_XBUTTON2))
	{
		pLB->KeyboardAction( (int)'`', 0 );
	}

	// B pressed => ESC
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_B] )
	{
		pLB->KeyboardAction( LINKSBOKS_KBD_ESC, 0 );
	}

	// Y pressed => close tab
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_Y] )
	{
		pLB->KeyboardAction( (int)'c', 0 );
	}

	// Black pressed => bookmarks
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_BLACK] )
	{
		pLB->KeyboardAction( (int)'s', 0 );
	}

	// White pressed => goto URL
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_WHITE] )
	{
		pLB->KeyboardAction( (int)'g', 0 );
	}
}


/*****************************************************************************/
/***************************** TEXT INPUT MODE *******************************/
/*****************************************************************************/

GamepadKeyInput g_keysNormal[9] =
{
	// center
	{{
		{	L"Space",	L' '	},
		{	L"BkSp",	LINKSBOKS_KBD_BS	},
		{	L"Del",		LINKSBOKS_KBD_DEL	},
		{	L".",		NULL	},
	}},
	// bottom-left
	{{
		{	L"a",		NULL	},
		{	L"b",		NULL	},
		{	L"c",		NULL	},
		{	L"d",		NULL	},
	}},
	// middle-left
	{{
		{	L"e",		NULL	},
		{	L"f",		NULL	},
		{	L"g",		NULL	},
		{	L"h",		NULL	},
	}},
	// top-left
	{{
		{	L"i",		NULL	},
		{	L"j",		NULL	},
		{	L"k",		NULL	},
		{	L"l",		NULL	},
	}},
	// top-center
	{{
		{	L"m",		NULL	},
		{	L"n",		NULL	},
		{	L"o",		NULL	},
		{	L"p",		NULL	},
	}},
	// top-right
	{{
		{	L"q",		NULL	},
		{	L"r",		NULL	},
		{	L"s",		NULL	},
		{	L"t",		NULL	},
	}},
	// middle-right
	{{
		{	L"u",		NULL	},
		{	L"v",		NULL	},
		{	L"w",		NULL	},
		{	L"x",		NULL	},
	}},
	// bottom-right
	{{
		{	L"y",		NULL	},
		{	L"z",		NULL	},
		{	L"/",		NULL	},
		{	L"~",		NULL	},
	}},
	// bottom-middle
	{{
		{	L".com",	NULL	},
		{	L".net",	NULL	},
		{	L".org",	NULL	},
		{	L"-",		NULL	},
	}},
};

struct _GamepadKeyInput g_keysCaps[9] =
{
	// center
	{{
		{	L"Space",	L' '	},
		{	L"BkSp",	LINKSBOKS_KBD_BS	},
		{	L"Del",		LINKSBOKS_KBD_DEL	},
		{	L".",		NULL	},
	}},
	// bottom-left
	{{
		{	L"A",		NULL	},
		{	L"B",		NULL	},
		{	L"C",		NULL	},
		{	L"D",		NULL	},
	}},
	// middle-left
	{{
		{	L"E",		NULL	},
		{	L"F",		NULL	},
		{	L"G",		NULL	},
		{	L"H",		NULL	},
	}},
	// top-left
	{{
		{	L"I",		NULL	},
		{	L"J",		NULL	},
		{	L"K",		NULL	},
		{	L"L",		NULL	},
	}},
	// top-center
	{{
		{	L"M",		NULL	},
		{	L"N",		NULL	},
		{	L"O",		NULL	},
		{	L"P",		NULL	},
	}},
	// top-right
	{{
		{	L"Q",		NULL	},
		{	L"R",		NULL	},
		{	L"S",		NULL	},
		{	L"T",		NULL	},
	}},
	// middle-right
	{{
		{	L"U",		NULL	},
		{	L"V",		NULL	},
		{	L"W",		NULL	},
		{	L"X",		NULL	},
	}},
	// bottom-right
	{{
		{	L"Y",		NULL	},
		{	L"Z",		NULL	},
		{	L"/",		NULL	},
		{	L"~",		NULL	},
	}},
	// bottom-middle
	{{
		{	L".com",	NULL	},
		{	L".net",	NULL	},
		{	L".org",	NULL	},
		{	L"-",		NULL	},
	}},
};

struct _GamepadKeyInput g_keysSymbols[9] =
{
	// center
	{{
		{	L"Space",	L' '	},
		{	L"BkSp",	LINKSBOKS_KBD_BS	},
		{	L"Del",		LINKSBOKS_KBD_DEL	},
		{	L".",		NULL	},
	}},
	// bottom-left
	{{
		{	L".",		NULL	},
		{	L",",		NULL	},
		{	L";",		NULL	},
		{	L":",		NULL	},
	}},
	// middle-left
	{{
		{	L"+",		NULL	},
		{	L"-",		NULL	},
		{	L"*",		NULL	},
		{	L"/",		NULL	},
	}},
	// top-left
	{{
		{	L"=",		NULL	},
		{	L"_",		NULL	},
		{	L"'",		NULL	},
		{	L"\"",		NULL	},
	}},
	// top-center
	{{
		{	L"(",		NULL	},
		{	L")",		NULL	},
		{	L"[",		NULL	},
		{	L"]",		NULL	},
	}},
	// top-right
	{{
		{	L"{",		NULL	},
		{	L"}",		NULL	},
		{	L"\\",		NULL	},
		{	L"|",		NULL	},
	}},
	// middle-right
	{{
		{	L"<",		NULL	},
		{	L">",		NULL	},
		{	L"?",		NULL	},
		{	L"!",		NULL	},
	}},
	// bottom-right
	{{
		{	L"@",		NULL	},
		{	L"#",		NULL	},
		{	L"$",		NULL	},
		{	L"%",		NULL	},
	}},
	// bottom-middle
	{{
		{	L"&",	NULL	},
		{	L"`",	NULL	},
		{	L"^",	NULL	},
		{	L"�",	NULL	},
	}},
};

int GetKeyGroupOffset()
{
	if( STICKCENTER && STICKMIDDLE )
		return 0;
	if( STICKLEFT && STICKBOTTOM )
		return 1;
	if( STICKLEFT && STICKMIDDLE )
		return 2;
	if( STICKLEFT && STICKTOP )
		return 3;
	if( STICKCENTER && STICKTOP )
		return 4;
	if( STICKRIGHT && STICKTOP )
		return 5;
	if( STICKRIGHT && STICKMIDDLE )
		return 6;
	if( STICKRIGHT && STICKBOTTOM )
		return 7;
	if( STICKCENTER && STICKBOTTOM )
		return 8;

	// Shouldn't get there
	return 0;
}

struct keygroup *GetKeyGroup( int i )
{
	if( g_DefaultGamepad.bAnalogButtons[XINPUT_GAMEPAD_LEFT_TRIGGER] > XINPUT_GAMEPAD_MAX_CROSSTALK )
		return( (struct keygroup *)(&g_keysCaps[i]) );
	else if( g_DefaultGamepad.bAnalogButtons[XINPUT_GAMEPAD_RIGHT_TRIGGER] > XINPUT_GAMEPAD_MAX_CROSSTALK )
		return( (struct keygroup *)(&g_keysSymbols[i]) );
	else
		return( (struct keygroup *)(&g_keysNormal[i]) );
}

struct keygroup *GetCurrentKeyGroup()
{
	return GetKeyGroup( GetKeyGroupOffset() );
}



VOID TextModeKeyStroke( LinksBoksWindow *pLB, struct keygroup kg )
{
	if( kg.links_code )
		pLB->KeyboardAction( kg.links_code, 0 );
	else
		for( int i = 0; i < wcslen( kg.text ); i++ )
		{
			pLB->KeyboardAction( (int)(kg.text[i]), 0 );
		}
}

VOID HandleInputTextMode( LinksBoksWindow *pLB, struct keygroup *kg )
{
	// Go to keypad mode
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_BLACK] )
		g_InputMode = KEYPAD_MODE;

	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_A] )
		TextModeKeyStroke( pLB, kg[0] );
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_B] )
		TextModeKeyStroke( pLB, kg[1] );
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_X] )
		TextModeKeyStroke( pLB, kg[2] );
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_Y] )
		TextModeKeyStroke( pLB, kg[3] );

}


/*****************************************************************************/
/******************************* KEYPAD MODE *********************************/
/*****************************************************************************/

WCHAR* g_KeyPad[12] = { L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", L"9", L":", L"0", L"." };
INT g_kpActiveKey = 4;

VOID HandleInputKeypadMode( LinksBoksWindow *pLB )
{
	if( g_kpWaitingStickRelease )
	{
		if( STICKCENTER && STICKMIDDLE )
			g_kpWaitingStickRelease = FALSE;

		if( timeGetTime( ) - g_lastKeyRepeat > g_KeyRepeatRate )
			g_kpWaitingStickRelease = FALSE;
	}
	else
	{
		if( STICKTOP )
			g_kpActiveKey = (g_kpActiveKey > 2) ? g_kpActiveKey - 3 : g_kpActiveKey + 9;

		if( STICKBOTTOM )
			g_kpActiveKey = (g_kpActiveKey < 9) ? g_kpActiveKey + 3 : g_kpActiveKey - 9;

		if( STICKRIGHT )
			g_kpActiveKey = (g_kpActiveKey % 3 != 2) ? g_kpActiveKey + 1 : g_kpActiveKey - 2;

		if( STICKLEFT )
			g_kpActiveKey = (g_kpActiveKey % 3 != 0) ? g_kpActiveKey - 1 : g_kpActiveKey + 2;

		if( !STICKCENTER || !STICKMIDDLE )
		{
			g_lastKeyRepeat = timeGetTime( );
			g_kpWaitingStickRelease = TRUE;
		}
		
	}

	// Send keystroke
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_A] )
		pLB->KeyboardAction( (int)(*g_KeyPad[g_kpActiveKey]), 0 );

	// Backspace
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_B] )
		pLB->KeyboardAction( LINKSBOKS_KBD_BS, 0 );

	// Delete
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_X] )
		pLB->KeyboardAction( LINKSBOKS_KBD_DEL, 0 );

	// Return to text input mode
	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_BLACK] )
		g_InputMode = TEXT_INPUT_MODE;
}

/*****************************************************************************/
/************************* VIDEO CALIBRATION MODE ****************************/
/*****************************************************************************/

VOID HandleInputCalibrationMode( LinksBoksWindow *pLB )
{
	int oldBorders[4];
	BOOL changed = FALSE;
	const char *varnames[4] = {
		"xbox_margin_top",
		"xbox_margin_bottom",
		"xbox_margin_left",
		"xbox_margin_right",
	};

	// Back pressed => back to navigation mode
	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_BACK) == XINPUT_GAMEPAD_BACK )
	{
		g_InputMode = NAVIGATION_MODE;
		return;
	}

	for( int i = 0; i < 4; i++ )
		oldBorders[i] = (int)g_Borders[i];

	g_Borders[0] -= (abs(g_DefaultGamepad.fY1) >= STICK_THRESHOLD) ? ((g_DefaultGamepad.fY1 > 0) ? 0.5 : -0.5) : 0;
	g_Borders[1] += (abs(g_DefaultGamepad.fY2) >= STICK_THRESHOLD) ? ((g_DefaultGamepad.fY2 > 0) ? 0.5 : -0.5) : 0;
	g_Borders[2] += (abs(g_DefaultGamepad.fX1) >= STICK_THRESHOLD) ? ((g_DefaultGamepad.fX1 > 0) ? 0.5 : -0.5) : 0;
	g_Borders[3] -= (abs(g_DefaultGamepad.fX2) >= STICK_THRESHOLD) ? ((g_DefaultGamepad.fX2 > 0) ? 0.5 : -0.5) : 0;

	for( i = 0; i < 4; i++ )
	{
		if( g_Borders[i] < 0 )
			g_Borders[i] = 0;

		if( g_Borders[i] > 125 )
			g_Borders[i] = 125;

		if( oldBorders[i] == (int)g_Borders[i] )
		{
			LinksBoks_SetOptionInt( varnames[i], (int)g_Borders[i] );
			changed = TRUE;
		}
	}

	/* Change the font size with the dpad! */
	if( ( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_DPAD_UP) == XINPUT_GAMEPAD_DPAD_UP ) &&
		( LinksBoks_GetOptionInt("html_font_size") < 30 ) )
	{
		LinksBoks_SetOptionInt("html_font_size", LinksBoks_GetOptionInt("html_font_size") + 1);
	}

	/* Change the font size with the dpad! */
	if( ( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_DPAD_DOWN) == XINPUT_GAMEPAD_DPAD_DOWN ) &&
		( LinksBoks_GetOptionInt("html_font_size") > 10 ) )
	{
		LinksBoks_SetOptionInt("html_font_size", LinksBoks_GetOptionInt("html_font_size") - 1);
	}

	if( changed )
		UpdateXboxOptions();
}

/*****************************************************************************/
/*************************** FLASH PLAYER MODE *******************************/
/*****************************************************************************/

VOID HandleInputForFlashPlayer(LinksBoksWindow *pLB)
{
	BYTE mousePressedButtons, mouseReleasedButtons;
	FlashEvent fe;
	BOOL bWakeUp = FALSE;
	XINPUT_STATE CurrentMouseState;

	UpdateMouseStatus(pLB, &CurrentMouseState, &mousePressedButtons, &mouseReleasedButtons);

	XINPUT_DEBUG_KEYSTROKE *kbdStroke = XBInput_GetKeyboardInput();

	// Mouse movement (left thumbstick)
	if( ((int)g_MouseX != (int)g_OldMouseX) || ((int)g_MouseY != (int)g_OldMouseY) )
	{
		fe.type = FeMouseMove;
		fe.x = (int)g_MouseX - (pLB->GetViewPortWidth() - g_FD.width) / 2;
		fe.y = (int)g_MouseY - (pLB->GetViewPortHeight() - g_FD.height) / 2;
		if(FlashExec(g_FH, FLASH_EVENT, &fe, &g_FlashNextWakeUp))
			bWakeUp = TRUE;
	}

	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_A]
	|| (mousePressedButtons & XINPUT_DEBUG_MOUSE_LEFT_BUTTON))
	{
		fe.type = FeButtonPress;
		if(FlashExec(g_FH, FLASH_EVENT, &fe, &g_FlashNextWakeUp))
			bWakeUp = TRUE;
	}

	if( g_DefaultGamepad.bReleasedAnalogButtons[XINPUT_GAMEPAD_A]
	|| (mouseReleasedButtons & XINPUT_DEBUG_MOUSE_LEFT_BUTTON))
	{
		fe.type = FeButtonRelease;
		if(FlashExec(g_FH, FLASH_EVENT, &fe, &g_FlashNextWakeUp))
			bWakeUp = TRUE;
	}

	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_Y]
	|| (kbdStroke &&kbdStroke->Ascii == 'P'))
	{
		/* Pause/unpause */
		if(!g_bFlashPaused)
		{
			if(FlashExec(g_FH, FLASH_STOP, NULL, &g_FlashNextWakeUp))
				bWakeUp = TRUE;
			g_bFlashPaused = TRUE;
		}
		else
		{
			if(FlashExec(g_FH, FLASH_CONT, NULL, &g_FlashNextWakeUp))
				bWakeUp = TRUE;
			g_bFlashPaused = FALSE;
		}
	}

	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_WHITE]
	|| (kbdStroke && kbdStroke->Ascii == 'R'))
	{
		/* Rewind */
		if(FlashExec(g_FH, FLASH_REWIND, NULL, &g_FlashNextWakeUp))
			bWakeUp = TRUE;
	}

	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_DPAD_UP) == XINPUT_GAMEPAD_DPAD_UP
	|| (kbdStroke && kbdStroke->VirtualKey == VK_UP))
	{
		/* Up */
		fe.type = FeKeyPress;
		fe.key = FeKeyUp;
		if(FlashExec(g_FH, FLASH_EVENT, &fe, &g_FlashNextWakeUp))
			bWakeUp = TRUE;
	}

	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_DPAD_DOWN) == XINPUT_GAMEPAD_DPAD_DOWN
	|| (kbdStroke && kbdStroke->VirtualKey == VK_DOWN))
	{
		/* Down */
		fe.type = FeKeyPress;
		fe.key = FeKeyDown;
		if(FlashExec(g_FH, FLASH_EVENT, &fe, &g_FlashNextWakeUp))
			bWakeUp = TRUE;
	}

	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_DPAD_LEFT) == XINPUT_GAMEPAD_DPAD_LEFT
	|| (kbdStroke && kbdStroke->VirtualKey == VK_LEFT))
	{
		/* Left */
		fe.type = FeKeyPress;
		fe.key = FeKeyLeft;
		if(FlashExec(g_FH, FLASH_EVENT, &fe, &g_FlashNextWakeUp))
			bWakeUp = TRUE;
	}

	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_DPAD_RIGHT) == XINPUT_GAMEPAD_DPAD_RIGHT
	|| (kbdStroke && kbdStroke->VirtualKey == VK_RIGHT))
	{
		/* Right */
		fe.type = FeKeyPress;
		fe.key = FeKeyRight;
		if(FlashExec(g_FH, FLASH_EVENT, &fe, &g_FlashNextWakeUp))
			bWakeUp = TRUE;
	}

	if( (g_DefaultGamepad.wPressedButtons & XINPUT_GAMEPAD_START) == XINPUT_GAMEPAD_START
		|| (kbdStroke && kbdStroke->VirtualKey == VK_RETURN))
	{
		/* Return */
		fe.type = FeKeyPress;
		fe.key = FeKeyEnter;
		if(FlashExec(g_FH, FLASH_EVENT, &fe, &g_FlashNextWakeUp))
			bWakeUp = TRUE;
	}

	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_BLACK]
		|| (kbdStroke && kbdStroke->VirtualKey == VK_TAB))
	{
		/* Next ('Tab' or black button) */
		fe.type = FeKeyPress;
		fe.key = FeKeyNext;
		if(FlashExec(g_FH, FLASH_EVENT, &fe, &g_FlashNextWakeUp))
			bWakeUp = TRUE;
	}

	if( g_DefaultGamepad.bPressedAnalogButtons[XINPUT_GAMEPAD_B]
	|| (mousePressedButtons & XINPUT_DEBUG_MOUSE_LEFT_BUTTON))
	{
		/* Bail out */
		FlashPlayerTerminate();
		g_InputMode = NAVIGATION_MODE;
	}

}
