LinksBoks "default" host app
============================

It's the plain vanilla LinksBoks you already know, now
using the library as every other application can. If
you want to use that library, this is your reference
(with the EmbeddedSample and the comments inside the
linksboks.h) to learn how things work together.

ysbox, 20050416