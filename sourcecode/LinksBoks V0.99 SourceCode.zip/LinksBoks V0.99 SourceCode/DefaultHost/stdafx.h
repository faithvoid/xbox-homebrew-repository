// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#define DEBUG_KEYBOARD

#include "common/mouse.h"
#include "common/keyboard.h"
#include "common/xbinput.h"
#include "common/xbfont.h"
#include <xtl.h>


// TODO: reference additional headers your program requires here
