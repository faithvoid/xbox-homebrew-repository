/*
 * LinksBoks
 * Copyright (c) 2003-2004 ysbox
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef _LBHOSTAPP_H_
#define _LBHOSTAPP_H_

#include "stdafx.h"
#include "linksboks.h"
#include "flash.h"

struct videomode {
	const WCHAR *name;
	LinksBoksViewPort viewport;
	DWORD standard;
	DWORD flags_in, flags_out;
};

typedef enum {
	NAVIGATION_MODE,
	TEXT_INPUT_MODE,
	KEYPAD_MODE,
	VIDEO_CALIBRATION_MODE,
	FLASH_PLAYER_MODE
} INPUT_MODE;

struct keygroup {
	WCHAR* text;
	int links_code;
};

typedef struct _GamepadKeyInput
{
	struct keygroup group[4];
} GamepadKeyInput;

class LinksBoksGUIOption : public LinksBoksOption
{
public:
	LinksBoksGUIOption(const char *name, const char *caption, int type, int depth, int default_value = 0) :
	  LinksBoksOption(name, caption, type, depth, default_value) {}
	VOID OnAfterChange(void *session);
};

class LinksBoksNetworkOption : public LinksBoksOption
{
public:
	LinksBoksNetworkOption(const char *name, const char *caption, int type, int depth, unsigned char *default_value = NULL) :
	  LinksBoksOption(name, caption, type, depth, default_value) {}
	LinksBoksNetworkOption(const char *name, const char *caption, int type, int depth, int default_value = NULL) :
	  LinksBoksOption(name, caption, type, depth, default_value) {}
	BOOL OnBeforeChange(void *session, unsigned char *oldvalue, unsigned char *newvalue);
	VOID OnAfterChange(void *session);
};

class LinksBoksHostProtocol : public LinksBoksInternalProtocol
{
public:
	int OnCall(unsigned char *url, void *connection);
	LinksBoksHostProtocol(void) :
	  LinksBoksInternalProtocol((unsigned char *)"linksboks", 0, 0, 0, 0) {}
};

extern GamepadKeyInput g_keysNormal[9];
extern GamepadKeyInput g_keysCaps[9];
extern GamepadKeyInput g_keysSymbols[9];

extern WCHAR* g_KeyPad[12];
extern INT g_kpActiveKey;

extern CXBFont    g_Font18;						// Medium-sized font
extern CXBFont    g_BigFont;					// Big shadowed font
extern CXBFont    g_FontButtons;				// Xbox Button font


extern LinksBoksWindow *g_pLB;


#define STICK_THRESHOLD		0.3
#define STICKLEFT	(g_DefaultGamepad.fX1 <= -STICK_THRESHOLD)
#define STICKCENTER	(g_DefaultGamepad.fX1 > -STICK_THRESHOLD && g_DefaultGamepad.fX1 < STICK_THRESHOLD)
#define STICKRIGHT	(g_DefaultGamepad.fX1 >= STICK_THRESHOLD)
#define STICKBOTTOM	(g_DefaultGamepad.fY1 <= -STICK_THRESHOLD)
#define STICKMIDDLE	(g_DefaultGamepad.fY1 > -STICK_THRESHOLD && g_DefaultGamepad.fY1 < STICK_THRESHOLD)
#define STICKTOP	(g_DefaultGamepad.fY1 >= STICK_THRESHOLD)

extern int g_MouseSensitivityX, g_MouseSensitivityY, g_KeyRepeatRate;
extern FLOAT g_GamepadDeadZone;
#define MOUSE_HOTSPOT_X		8
#define MOUSE_HOTSPOT_Y		4


//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------
extern LPDIRECT3D8             g_pD3D;
extern LPDIRECT3DDEVICE8       g_pd3dDevice;
extern LPDIRECT3DTEXTURE8		g_pMousePtr;

extern FLOAT g_MouseX, g_MouseY;
extern XBGAMEPAD*             g_Gamepad;
extern XBGAMEPAD              g_DefaultGamepad;

extern LinksBoksWindow		*g_pLB;
extern struct videomode g_CurrentMode;
extern INPUT_MODE g_InputMode;

extern struct FlashInfo g_FI;
extern FlashDisplay g_FD;
extern FlashHandle g_FH;
extern struct timeval g_FlashNextWakeUp;
extern BOOL g_bFlashPaused;

//-----------------------------------------------------------------------------
// Prototypes
//-----------------------------------------------------------------------------
INT InitXboxSystems();
INT InitGraphics();
HRESULT InitXboxInput();
int FlashPlayerInit(LinksBoksWindow *pLB, unsigned char *cmdline, unsigned char *file, int fd);
char *GetNetworkStatusHTML();
VOID HandleMouseInput(LinksBoksWindow *pLB);
VOID UpdateInput();
void UpdateXboxOptions();
VOID HandleInputNavMode(LinksBoksWindow *pLB);
VOID HandleInputTextMode(LinksBoksWindow *pLB, struct keygroup *kg);
VOID HandleInputKeypadMode(LinksBoksWindow *pLB);
VOID HandleInputCalibrationMode(LinksBoksWindow *pLB);
VOID HandleGeneralBindings(LinksBoksWindow *pLB);
VOID HandleInputForFlashPlayer(LinksBoksWindow *pLB);
VOID DrawKeyPad( LPDIRECT3DSURFACE8 pSurface, CXBFont *pFont );
VOID DrawTextInputStuff( LPDIRECT3DSURFACE8 pSurface );
VOID DrawFlashPlayer(LinksBoksWindow *pLB, LPDIRECT3DSURFACE8 pSurface);
void DrawCalibrationScreen( LPDIRECT3DSURFACE8 pSurface );
VOID LockFlashSurface();
VOID UnlockFlashSurface();
VOID FlashPlayerTerminate();

struct keygroup *GetKeyGroup(int i);
struct keygroup *GetCurrentKeyGroup();

#endif