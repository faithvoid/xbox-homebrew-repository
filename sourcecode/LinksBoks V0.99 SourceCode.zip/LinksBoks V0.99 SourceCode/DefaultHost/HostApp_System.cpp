/*
 * LinksBoks
 * Copyright (c) 2003-2004 ysbox
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


#include "LBHostApp.h"
#include "stdio.h"

/* Most of this comes from Team Assembly, kudos to them */

typedef struct   
{   
	DWORD	Data_00;            // Check Block Start   
	DWORD	Data_04;   
	DWORD	Data_08;   
	DWORD	Data_0c;   
	DWORD	Data_10;            // Check Block End   
  
	DWORD	V1_IP;              // 0x14   
	DWORD	V1_Subnetmask;      // 0x18   
	DWORD	V1_Defaultgateway;  // 0x1c   
	DWORD	V1_DNS1;            // 0x20   
	DWORD	V1_DNS2;            // 0x24   

	DWORD	Data_28;            // Check Block Start   
	DWORD	Data_2c;   
	DWORD	Data_30;   
	DWORD	Data_34;   
	DWORD	Data_38;            // Check Block End   

	DWORD	V2_Tag;             // V2 Tag "XBV2"   
 
	DWORD	Flag;				// 0x40   
	DWORD	Data_44;   

	DWORD	V2_IP;              // 0x48   
	DWORD	V2_Subnetmask;      // 0x4c   
	DWORD	V2_Defaultgateway;  // 0x50   
	DWORD	V2_DNS1;            // 0x54   
	DWORD	V2_DNS2;            // 0x58   

	DWORD   Data_xx[0x200-0x5c];

} TXNetConfigParams,*PTXNetConfigParams;   

typedef struct _UnicodeString
{
	USHORT	Length;
	USHORT	MaximumLength;
	PSTR	Buffer;
} UNICODE_STRING;


extern "C" INT WINAPI XNetLoadConfigParams(LPBYTE);   
extern "C" INT WINAPI XNetSaveConfigParams(LPBYTE);     

extern "C" XBOXAPI LONG WINAPI IoCreateSymbolicLink(IN UNICODE_STRING *SymbolicLinkName, IN UNICODE_STRING *DeviceName);


/* Helper function to mount a drive. */
LONG MountDevice(LPSTR sSymbolicLinkName, LPSTR sDeviceName)
{

	UNICODE_STRING deviceName, symbolicLinkName;

	deviceName.Buffer  = sDeviceName;
	deviceName.Length = (USHORT)strlen(sDeviceName);
	deviceName.MaximumLength = (USHORT)strlen(sDeviceName) + 1;

	symbolicLinkName.Buffer  = sSymbolicLinkName;
	symbolicLinkName.Length = (USHORT)strlen(sSymbolicLinkName);
	symbolicLinkName.MaximumLength = (USHORT)strlen(sSymbolicLinkName) + 1;

	return IoCreateSymbolicLink(&symbolicLinkName, &deviceName);

}

/* This function returns a char * containing some HTML describing the current network status.
It is called by the handler function of the linksboks: protocol for responding to linkboks:network */
char *GetNetworkStatusHTML()
{
	char *result = new char[2048];	/* F34R */
	XNADDR pXna;
	DWORD dwNetStatus = XNetGetTitleXnAddr(&pXna);
	char ipaddr[32];
	
	XNetInAddrToString(pXna.ina, ipaddr, 32);

	strcpy(result, "<html>\n\
				   <head><title>Network status and troubleshoot</title></head>\n\
				   <body>\n\
				   <h3>LinksBoks</h3>\n\
				   <h4>Network status and troubleshoot</h4>\n\
				   <p>");

	/* (Re)configuration */
	if(LinksBoks_GetOptionBool("xbox_network_custom_conf"))
		strcat(result, "The following network settings have been <b>reconfigured by LinksBoks</b> on startup\n\
					   as defined in the Options Manager.");
	else
		strcat(result, "The following network settings have been <b>set by a previous executed program</b>\n\
					   (ie. a dashboard); LinksBoks didn't change them.");

	strcat(result, "</p><p>Use the Options Manager (Xbox-specific options>Network settings) or your dashboard to alter these settings.</p>\n\
				   <table cellpadding=\"2\">\n");

	/* Ethernet link */
	strcat(result, "<tr><td><b>Ethernet link</b></td><td>");
	if((XNetGetEthernetLinkStatus() & XNET_ETHERNET_LINK_ACTIVE) == XNET_ETHERNET_LINK_ACTIVE)
	{
		strcat(result, "Connected, ");

		if((XNetGetEthernetLinkStatus() & XNET_ETHERNET_LINK_100MBPS) == XNET_ETHERNET_LINK_100MBPS)
			strcat(result, "100 Mbps, ");
		else
			strcat(result, "10 Mbps, ");

		if((XNetGetEthernetLinkStatus() & XNET_ETHERNET_LINK_FULL_DUPLEX) == XNET_ETHERNET_LINK_FULL_DUPLEX)
			strcat(result, "full duplex");
		else
			strcat(result, "half duplex");
	}
	else
		strcat(result, "<font color=red>NOT CONNECTED</font>");

	strcat(result, "</td></tr>\n");

	/* Network status */
	strcat(result, "<tr><td><b>Network system status</b></td><td>");
	if(dwNetStatus == XNET_GET_XNADDR_PENDING)
		strcat(result, "<font color=red>ADDRESS ACQUISITION PENDING<br></font></td></tr>");
	else if((dwNetStatus & XNET_GET_XNADDR_NONE) == XNET_GET_XNADDR_NONE)
		strcat(result, "<font color=red>NOT INITIALIZED<br></font></td></tr>");
	else
	{
		strcat(result, "Initialized</td></tr>\n");

		if((dwNetStatus & XNET_GET_XNADDR_DHCP) == XNET_GET_XNADDR_DHCP)
			strcat(result, "<tr><td><b>IP configuration mode</b></td><td>Automatic, assigned via DHCP</td></tr>\n");
		else if((dwNetStatus & XNET_GET_XNADDR_PPPOE) == XNET_GET_XNADDR_PPPOE)
			strcat(result, "<tr><td><b>IP configuration</b></td><td>Automatic, assigned via PPPoE (direct connection to ADSL modem)</td></tr>\n");
		else if((dwNetStatus & XNET_GET_XNADDR_STATIC) == XNET_GET_XNADDR_STATIC)
			strcat(result, "<tr><td><b>IP configuration</b></td><td>Manual, static addresses</td></tr>\n");
		else
			strcat(result, "<tr><td><b>IP assignation mode</b></td><td><font color=red>NONE</font></td></tr>\n");

		/* IP address */
		strcat(result, "<tr><td><b>Current Xbox IP address</b></td><td>");
		strcat(result, ipaddr);
		if(!strcmp((const char *)ipaddr, "0.0.0.0"))
			strcat(result, "&nbsp;&nbsp;<font color=red>(INVALID)</font>");

		strcat(result, "</td></tr>");
	}

	strcat(result, "</table>");

	strcat(result, "<hr>");

	/* Troubleshooting advices */
	if((dwNetStatus & XNET_GET_XNADDR_TROUBLESHOOT) == XNET_GET_XNADDR_TROUBLESHOOT)
		strcat(result, "<p><font color=red>Your network settings are not configured properly and need troubleshooting.</font></p>\n");
	if((dwNetStatus & XNET_GET_XNADDR_GATEWAY) == 0)
		strcat(result, "<p><font color=red>You have no configured gateway. The gateway is the IP address of your router or your PC who is sharing the Internet connection to the rest of the network.</font></p>");
	if((dwNetStatus & XNET_GET_XNADDR_DNS) == 0)
		strcat(result, "<p><font color=red>You have no configured DNS servers. Without it, you can translate host names like www.google.com into its correponding IP address. The DNS server is often the same as the gateway.</font></p>");
	if(dwNetStatus == XNET_GET_XNADDR_PENDING)
		strcat(result, "<p><font color=red>Your Xbox is still trying to get its network configuration from a DHCP server. Please verify that you have one working properly. If you have a Windows PC with Internet Connection Sharing activated, this PC normally acts as a DHCP server too.</font></p>");
	if((dwNetStatus & XNET_GET_XNADDR_NONE) == XNET_GET_XNADDR_NONE)
		strcat(result, "<p><font color=red>Your network is not initialized at all. Please check your physical connection (network cables and hubs/switchs), then verify that you have properly configured your network settings.</font></p>");
	if((XNetGetEthernetLinkStatus() & XNET_ETHERNET_LINK_ACTIVE) == 0)
		strcat(result, "<p><font color=red>Please check your physical connection (network cables and hubs/switchs), it appears to be broken.</font></p>");

	strcat(result, "<p></p><p>Please correct any problem in red above. If you don't see any red, your network settings seem to be in order (but they still can be wrong, or the problem can be elsewhere).</p>");
	strcat(result, "<p>If you still can't connect, try to tell LinksBoks in the Options Manager to reconfigure the network, and switch between Static (with the default addresses) and DHCP mode.</p>");

	strcat(result, "</body></html>");

	return result;
}

INT InitXboxSystems()
{
	/* Mount drives */
	MountDevice( "\\??\\C:", "\\Device\\Harddisk0\\Partition2" );
	MountDevice( "\\??\\E:", "\\Device\\Harddisk0\\Partition1" );
	MountDevice( "\\??\\F:", "\\Device\\Harddisk0\\Partition6" );
	MountDevice( "\\??\\G:", "\\Device\\Harddisk0\\Partition7" );
	MountDevice( "\\??\\X:", "\\Device\\Harddisk0\\Partition3" );
	MountDevice( "\\??\\Y:", "\\Device\\Harddisk0\\Partition4" );
	MountDevice( "\\??\\Z:", "\\Device\\Harddisk0\\Partition5" );


    // Initialize the network stack. For default initialization, call
    // XNetStartup( NULL );
    XNetStartupParams xnsp;
	int iResult;
    WSADATA WsaData;
	struct sockaddr_in saHost;
	TXNetConfigParams configParams; 
	int bXboxVersion2;

	XNetLoadConfigParams( (LPBYTE) &configParams );

	bXboxVersion2 = (configParams.V2_Tag == 0x58425632 ); // "XBV2"

	if(!LinksBoks_GetOptionBool("xbox_network_custom_conf"))
		goto no_network_config;
	
	configParams.Flag = (LinksBoks_GetOptionBool("xbox_network_dhcp")) ? 0 : 0x04 | 0x08;		// static IP or DHCP

	if (bXboxVersion2)
	{
		configParams.V2_IP = inet_addr((const char *)LinksBoks_GetOptionString("xbox_network_ip"));
		configParams.V2_Subnetmask = inet_addr((const char *)LinksBoks_GetOptionString("xbox_network_netmask"));
		configParams.V2_Defaultgateway = inet_addr((const char *)LinksBoks_GetOptionString("xbox_network_gateway"));
		configParams.V2_DNS1 = inet_addr((const char *)LinksBoks_GetOptionString("xbox_network_dns"));
		saHost.sin_addr.S_un.S_addr = configParams.V2_IP;
	}
	else
	{
		configParams.V1_IP = inet_addr((const char *)LinksBoks_GetOptionString("xbox_network_ip"));
		configParams.V1_Subnetmask = inet_addr((const char *)LinksBoks_GetOptionString("xbox_network_netmask"));
		configParams.V1_Defaultgateway = inet_addr((const char *)LinksBoks_GetOptionString("xbox_network_gateway"));
		configParams.V1_DNS1 = inet_addr((const char *)LinksBoks_GetOptionString("xbox_network_dns"));
		saHost.sin_addr.S_un.S_addr = configParams.V1_IP;
	}

	XNetSaveConfigParams( (LPBYTE) &configParams );


no_network_config:
    ZeroMemory( &xnsp, sizeof(xnsp) );
    xnsp.cfgSizeOfStruct = sizeof(xnsp);

	// create more memory for networking
	xnsp.cfgPrivatePoolSizeInPages = 64; // == 256kb, default = 12 (48kb)
	xnsp.cfgEnetReceiveQueueLength = 16; // == 32kb, default = 8 (16kb)
	xnsp.cfgIpFragMaxSimultaneous = 16; // default = 4
	xnsp.cfgIpFragMaxPacketDiv256 = 32; // == 8kb, default = 8 (2kb)
	xnsp.cfgSockMaxSockets = 64; // default = 64
	xnsp.cfgSockDefaultRecvBufsizeInK = 128; // default = 16
	xnsp.cfgSockDefaultSendBufsizeInK = 128; // default = 16

    xnsp.cfgFlags = XNET_STARTUP_BYPASS_SECURITY;
    iResult = XNetStartup( &xnsp );
    if( iResult != NO_ERROR )
        return -1;

    // Standard WinSock startup. The Xbox allows all versions of Winsock
    // up through 2.2 (i.e. 1.0, 1.1, 2.0, 2.1, and 2.2), although it 
    // technically supports only and exactly what is specified in the 
    // Xbox network documentation, not necessarily the full Winsock 
    // functional specification.
    iResult = WSAStartup( MAKEWORD(2,2), &WsaData );
    if( iResult != NO_ERROR )
        return -1;

	XNADDR xna;	DWORD dwState;
	// Wait during DHCP negotiation...
	do	{		dwState = XNetGetTitleXnAddr(&xna);		Sleep(50);	} while (dwState==XNET_GET_XNADDR_PENDING);


    return 0;

}