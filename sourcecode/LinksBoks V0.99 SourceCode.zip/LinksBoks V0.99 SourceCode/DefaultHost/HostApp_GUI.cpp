/*
 * LinksBoks
 * Copyright (c) 2003-2004 ysbox
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "LBHostApp.h"
#include "stdio.h"

#define LINKSBOKS_REFRESH_RATE		((g_CurrentMode.viewport.standard == XC_VIDEO_STANDARD_PAL_I) ? 15 : 12)

LPDIRECT3D8             g_pD3D       = NULL; // Used to create the D3DDevice
LPDIRECT3DDEVICE8       g_pd3dDevice = NULL; // Our rendering device
LPDIRECT3DTEXTURE8		g_pMousePtr  = NULL; // Mouse pointer texture

struct videomode g_VideoModes[] =
{
	{ L"HDTV 1080i",	{1920, 1080, 40, 40, 30, 30}, XC_VIDEO_STANDARD_NTSC_M, XC_VIDEO_FLAGS_HDTV_1080i, D3DPRESENTFLAG_WIDESCREEN | D3DPRESENTFLAG_INTERLACED },
	{ L"HDTV 720p",		{1280,  720, 40, 40, 30, 30}, XC_VIDEO_STANDARD_NTSC_M, XC_VIDEO_FLAGS_HDTV_720p,  D3DPRESENTFLAG_WIDESCREEN | D3DPRESENTFLAG_PROGRESSIVE },
	{ L"HDTV 480p",		{720,  480, 40, 40, 30, 30}, XC_VIDEO_STANDARD_NTSC_M, XC_VIDEO_FLAGS_HDTV_480p,  D3DPRESENTFLAG_PROGRESSIVE },
	{ L"NTSC-M",		{720,  480, 40, 40, 30, 30}, XC_VIDEO_STANDARD_NTSC_M, 0, 0 },
	{ L"PAL-I",			{720,  576, 40, 40, 30, 30}, XC_VIDEO_STANDARD_PAL_I,  0, 0 },
	{ L"NTSC-J",		{720,  480, 40, 40, 30, 30}, XC_VIDEO_STANDARD_NTSC_J, 0, 0 },
	{ L"Compatible",	{640,  480, 40, 40, 30, 30}, 0, 0, 0 },
	{  NULL, {0, 0, 0, 0, 0, 0}, 0, 0, 0 },
};

struct videomode g_CurrentMode;

INPUT_MODE g_InputMode = NAVIGATION_MODE;

CXBFont    g_Font18;					// Medium-sized font
CXBFont    g_BigFont;					// Big shadowed font
CXBFont    g_FontButtons;				// Xbox Button font

CXBPackedResource		g_pResources;	// Textures resources



// Xboxdings font button mappings
const WCHAR* TEXT_A_BUTTON = L"A";
const WCHAR* TEXT_B_BUTTON = L"B";
const WCHAR* TEXT_X_BUTTON = L"C";
const WCHAR* TEXT_Y_BUTTON = L"D";

typedef enum
{
	DRAWDIRECTION_RIGHT,
	DRAWDIRECTION_DOWN,
	DRAWDIRECTION_LEFT,
	DRAWDIRECTION_UP,
} DRAWDIRECTION;



HRESULT DrawOutlineRectangle( int x, int y, int w, int h, int color, int outlinecolor, LPDIRECT3DSURFACE8 pSurface )
{
	LPDIRECT3DTEXTURE8 pTexture = NULL;

	if( FAILED( g_pd3dDevice->CreateTexture( w, h, 0, 0, D3DFMT_LIN_A8R8G8B8, 0, &pTexture ) ) )
		return E_FAIL;

    D3DLOCKED_RECT d3dlr;
    pTexture->LockRect( 0, &d3dlr, NULL, 0 );
	DWORD * pDst = (DWORD *)d3dlr.pBits;
	int DPitch = d3dlr.Pitch/4;

	for (int j=0; j<h; ++j)
		for (int i=0; i<w; ++i)
			pDst[j*DPitch + i] = color;

	if( outlinecolor )
	{
		for(int i=0; i<w; ++i)
		{
			pDst[0*DPitch + i] = outlinecolor;
			pDst[(h-1)*DPitch + i] = outlinecolor;
		}
		for(int j=0; j<h; ++j)
		{
			pDst[j*DPitch + 0] = outlinecolor;
			pDst[j*DPitch + w-1] = outlinecolor;
		}
	}

	pTexture->UnlockRect( 0 );

	g_pLB->CreatePrimitive( x, y, w + 1, h + 1, 0 );
	g_pd3dDevice->SetTexture( 0, pTexture );
	g_pLB->RenderPrimitive( pSurface );
	g_pd3dDevice->SetTexture( 0, NULL );
	pTexture->Release( );

	return S_OK;
}

VOID DrawKeyPad( LPDIRECT3DSURFACE8 pSurface, CXBFont *pFont )
{
	INT x = g_pLB->GetViewPortWidth() - 120;
	INT y = g_pLB->GetViewPortHeight() - 150;

	for( int i = 0; i < 12; i++ )
	{
		DrawOutlineRectangle( x, y, 30, 30,
				(g_kpActiveKey == i) ? 0xbbc0c070 : 0xc09090ff,
				(g_kpActiveKey == i) ? 0xff000000 : 0xe0404040,
				pSurface );

		pFont->DrawTextEx( (FLOAT)(g_CurrentMode.viewport.margin_left + x + 15), (FLOAT)(g_CurrentMode.viewport.margin_top + y + 15),
				(g_kpActiveKey == i) ? 0xff000000 : 0xc0404040, g_KeyPad[i], 1,
				XBFONT_CENTER_X | XBFONT_CENTER_Y, 0.0 );

		if( i % 3 == 2 )
		{
			x -= 60;
			y += 30;
		}
		else
			x += 30;
	}

	g_BigFont.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.margin_left + 120), (FLOAT)(g_CurrentMode.viewport.margin_top + g_pLB->GetViewPortHeight() - 25), 0xffffffff,
		GLYPH_BLACK_BUTTON L"Return", wcslen( GLYPH_BLACK_BUTTON L"Return" ) );
}

VOID DrawBigButtons( int x, int y, struct keygroup *kg, LPDIRECT3DSURFACE8 pSurface )
{
	if( x > 0 )
		x = g_CurrentMode.viewport.margin_left + x;
	else
		x = g_CurrentMode.viewport.margin_left + g_pLB->GetViewPortWidth() + x;

	if( y > 0 )
		y = g_CurrentMode.viewport.margin_top + y;
	else
		y = g_CurrentMode.viewport.margin_top + g_pLB->GetViewPortHeight() + y;

	// Draw the 4 colored buttons
	g_FontButtons.DrawTextEx( (FLOAT)x+4, (FLOAT)y+20, 0xffffffff, TEXT_A_BUTTON, 1, XBFONT_CENTER_X | XBFONT_CENTER_Y );
	g_FontButtons.DrawTextEx( (FLOAT)x+20, (FLOAT)y, 0xffffffff, TEXT_B_BUTTON, 1, XBFONT_CENTER_X | XBFONT_CENTER_Y );
	g_FontButtons.DrawTextEx( (FLOAT)x-20, (FLOAT)y, 0xffffffff, TEXT_X_BUTTON, 1, XBFONT_CENTER_X | XBFONT_CENTER_Y );
	g_FontButtons.DrawTextEx( (FLOAT)x-4, (FLOAT)y-20, 0xffffffff, TEXT_Y_BUTTON, 1, XBFONT_CENTER_X | XBFONT_CENTER_Y );

	// Draw the text near the buttons

	g_BigFont.DrawTextEx( (FLOAT)x+4, (FLOAT)y+20, 0xffffffff, kg[0].text, wcslen(kg[0].text), XBFONT_CENTER_X | XBFONT_CENTER_Y );
	g_BigFont.DrawTextEx( (FLOAT)x+20, (FLOAT)y-1, 0xffffffff, kg[1].text, wcslen(kg[1].text),
			(wcslen(kg[1].text) < 2) ? (XBFONT_CENTER_X | XBFONT_CENTER_Y) : (XBFONT_LEFT | XBFONT_CENTER_Y) );
	g_BigFont.DrawTextEx( (FLOAT)x-20, (FLOAT)y-1, 0xffffffff, kg[2].text, wcslen(kg[2].text),
			(wcslen(kg[2].text) < 2) ? (XBFONT_CENTER_X | XBFONT_CENTER_Y) : (XBFONT_RIGHT | XBFONT_CENTER_Y) );
	g_BigFont.DrawTextEx( (FLOAT)x-4, (FLOAT)y-20, 0xffffffff, kg[3].text, wcslen(kg[3].text), XBFONT_CENTER_X | XBFONT_CENTER_Y );
}

VOID DrawHelpers( int basex, int basey, struct keygroup *kg, DRAWDIRECTION direction, LPDIRECT3DSURFACE8 pSurface, CXBFont *pFont )
{
	int x = basex;
	int y = basey;
	DWORD helperBkColor[4] = { 0xa0007000, 0xa0700000, 0xa0000070, 0xa0707000 };

	for( int i = 0; i < 4; i++ )
	{
		DrawOutlineRectangle( x, y, 30, 30, helperBkColor[i], 0xc0404040, pSurface );

		if( wcslen(kg[i].text) > 2 )
			pFont->SetScaleFactors( 0.5, 1.0 );

		pFont->DrawTextEx( (FLOAT)(g_CurrentMode.viewport.margin_left + x + 15), (FLOAT)(g_CurrentMode.viewport.margin_top + y + 15),
				0xffffffff, kg[i].text, wcslen(kg[i].text),
				XBFONT_CENTER_X | XBFONT_CENTER_Y, 0.0 );
		
		if( wcslen(kg[i].text) > 2 )
			pFont->SetScaleFactors( 1.0, 1.0 );

		switch( direction )
		{
			case DRAWDIRECTION_RIGHT:
				x += 30;
				break;
			case DRAWDIRECTION_DOWN:
				y += 30;
				break;
			case DRAWDIRECTION_LEFT:
				x -= 30;
				break;
			case DRAWDIRECTION_UP:
				y -= 30;
				break;
		}
	}
}

VOID DrawTextInputStuff( LPDIRECT3DSURFACE8 pSurface )
{
	INT helpersX[8] = { 90, 0,
			0, g_pLB->GetViewPortWidth()/2-60,	g_pLB->GetViewPortWidth()-30*4,
			g_pLB->GetViewPortWidth()-30, g_pLB->GetViewPortWidth()-30,
			g_pLB->GetViewPortWidth()/2-60 };
	INT helpersY[8] = { g_pLB->GetViewPortHeight()-30, g_pLB->GetViewPortHeight()/2+30,
			0, 0, 0,
			g_pLB->GetViewPortHeight()/2-60, g_pLB->GetViewPortHeight()-30,
			g_pLB->GetViewPortHeight()-30 };
	DRAWDIRECTION helpersD[8] = { DRAWDIRECTION_LEFT, DRAWDIRECTION_UP,
			DRAWDIRECTION_RIGHT, DRAWDIRECTION_RIGHT, DRAWDIRECTION_RIGHT,
			DRAWDIRECTION_DOWN, DRAWDIRECTION_LEFT,
			DRAWDIRECTION_RIGHT };

	// Negative values mean distance from the right/bottom of the viewport
	INT BigBtX[8] = { 40, 40, 40, g_pLB->GetViewPortWidth()/2, -40, -40, -40, g_pLB->GetViewPortWidth()/2 };
	INT BigBtY[8] = { -40, g_pLB->GetViewPortHeight()/2, 40, 40, 40, g_pLB->GetViewPortHeight()/2, -40, -40 };

	BOOL bigButtonsDrawn = FALSE;

	for( int i = 0; i < 8; i++ )
	{
		if( GetCurrentKeyGroup() == GetKeyGroup( i + 1 ) )
		{
			DrawBigButtons( BigBtX[i], BigBtY[i], GetKeyGroup( i + 1 ), pSurface );
			bigButtonsDrawn = TRUE;
		}
		else
			DrawHelpers( helpersX[i], helpersY[i], GetKeyGroup( i + 1 ), helpersD[i], pSurface, &g_Font18 );
	}

	if( !bigButtonsDrawn )
		DrawBigButtons( -190, -40, GetKeyGroup( 0 ), pSurface );

	g_BigFont.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.margin_left + 120), (FLOAT)(g_CurrentMode.viewport.margin_top + g_pLB->GetViewPortHeight() - 25), 0xffffffff,
		GLYPH_BLACK_BUTTON L"Keypad", wcslen( GLYPH_BLACK_BUTTON L"Keypad" ) );
}

void DrawCalibrationScreen( LPDIRECT3DSURFACE8 pSurface )
{
	WCHAR buf[64];

//	DrawOutlineRectangle( 0, 0, g_pLB->GetViewPortWidth(), g_pLB->GetViewPortHeight(), 0x40000000, 0xffff0000, pSurface );

	DrawOutlineRectangle( 0, 0, 100, 10, 0xffff0000, 0xffff0000, pSurface );
	DrawOutlineRectangle( 0, 10, 10, 90, 0xffff0000, 0xffff0000, pSurface );

	DrawOutlineRectangle( g_pLB->GetViewPortWidth()-10, g_pLB->GetViewPortHeight()-100, 10, 100, 0xffff0000, 0xffff0000, pSurface );
	DrawOutlineRectangle( g_pLB->GetViewPortWidth()-100, g_pLB->GetViewPortHeight()-10, 90, 10, 0xffff0000, 0xffff0000, pSurface );

	g_BigFont.SetScaleFactors( 1.5, 1.5 );
	g_BigFont.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.width - g_CurrentMode.viewport.margin_right - 50.0), (FLOAT)(g_CurrentMode.viewport.margin_top + 50.0), 0xffc0c0ff, g_CurrentMode.name, wcslen( g_CurrentMode.name ), (XBFONT_RIGHT | XBFONT_CENTER_Y) );
	g_BigFont.SetScaleFactors( 1.0, 1.0 );

	swprintf( buf, L"%dx%d", g_CurrentMode.viewport.width, g_CurrentMode.viewport.height );
	g_BigFont.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.width - g_CurrentMode.viewport.margin_right - 50.0), (FLOAT)(g_CurrentMode.viewport.margin_top + 80.0), 0xffc0c0ff, buf, wcslen( buf ), (XBFONT_RIGHT | XBFONT_CENTER_Y) );

	swprintf( buf, L"(%d,%d)", g_CurrentMode.viewport.margin_left, g_CurrentMode.viewport.margin_top );
	g_BigFont.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.margin_left + 50.0), (FLOAT)(g_CurrentMode.viewport.margin_top + 50.0), 0xffffff00, buf, wcslen( buf ), (XBFONT_LEFT | XBFONT_CENTER_Y) );

	swprintf( buf, L"(%d,%d)", g_CurrentMode.viewport.margin_right, g_CurrentMode.viewport.margin_bottom );
	g_BigFont.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.width - g_CurrentMode.viewport.margin_right - 50.0), (FLOAT)(g_CurrentMode.viewport.height - g_CurrentMode.viewport.margin_bottom - 50.0), 0xffffff00, buf, wcslen( buf ), (XBFONT_RIGHT | XBFONT_CENTER_Y) );

	g_BigFont.SetScaleFactors( 1.2, 1.2 );
	swprintf( buf, L"%dx%d", g_pLB->GetViewPortWidth(), g_pLB->GetViewPortHeight() );
	g_BigFont.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.width / 2), (FLOAT)(g_CurrentMode.viewport.height / 2), 0xffffff00, buf, wcslen( buf ), (XBFONT_CENTER_X | XBFONT_CENTER_Y) );

	DrawOutlineRectangle( 30, g_pLB->GetViewPortHeight() - 77, 263, 69, 0xaa000000, 0x00000000, pSurface);
	g_BigFont.SetScaleFactors( 1.0, 1.0 );
	g_BigFont.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.margin_left + 50.0), (FLOAT)(g_CurrentMode.viewport.height - g_CurrentMode.viewport.margin_bottom - 65.0), 0xff70ffff, L"Video calibration", wcslen( L"Video calibration" ), (XBFONT_LEFT | XBFONT_CENTER_Y) );
	g_BigFont.SetScaleFactors( 0.8, 0.8 );
	g_BigFont.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.margin_left + 50.0), (FLOAT)(g_CurrentMode.viewport.height - g_CurrentMode.viewport.margin_bottom - 45.0), 0xffffffff, L"Adjust with thumbsticks", wcslen( L"Adjust with thumbsticks" ), (XBFONT_LEFT | XBFONT_CENTER_Y) );
	g_BigFont.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.margin_left + 50.0), (FLOAT)(g_CurrentMode.viewport.height - g_CurrentMode.viewport.margin_bottom - 30.0), 0xffffffff, L"Change font size with d-pad", wcslen( L"Change font size with d-pad" ), (XBFONT_LEFT | XBFONT_CENTER_Y) );
	g_BigFont.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.margin_left + 50.0), (FLOAT)(g_CurrentMode.viewport.height - g_CurrentMode.viewport.margin_bottom - 15.0), 0xffffffff, L"BACK to return", wcslen( L"BACK to return" ), (XBFONT_LEFT | XBFONT_CENTER_Y) );
	g_BigFont.SetScaleFactors( 1.0, 1.0 );

}




VOID DrawSplashScreen()
{
	WCHAR *welcome = L"Welcome to LinksBoks";
	WCHAR *msg = L"Please wait, initializing...";

	LPDIRECT3DSURFACE8 pBackBuffer, pLogoSurface;
	LPDIRECT3DTEXTURE8 pLinksBoksLogo;

    g_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 
                         D3DCOLOR_XRGB(0,0,0), 1.0f, 0L );

	g_pd3dDevice->GetBackBuffer( 0, D3DBACKBUFFER_TYPE_MONO, &pBackBuffer );

	g_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );

	pLinksBoksLogo = g_pResources.GetTexture( "LinksBoksLogo" );
	pLinksBoksLogo->GetSurfaceLevel(0, &pLogoSurface);

	RECT srcRect;
	POINT dstPoint;

	SetRect( &srcRect, 0, 0, 256, 256 );
	dstPoint.x = (g_CurrentMode.viewport.width / 2) - 128;
	dstPoint.y = (g_CurrentMode.viewport.height / 2) - 160;

	g_pd3dDevice->CopyRects( pLogoSurface, &srcRect, 1, pBackBuffer, &dstPoint );

	g_BigFont.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.width / 2), (FLOAT)(g_CurrentMode.viewport.height / 2) + 150, 0xffa0d000, welcome, wcslen( welcome ), (XBFONT_CENTER_X | XBFONT_CENTER_Y) );
	g_Font18.SetScaleFactors( .8, .8 );
	g_Font18.DrawTextEx( (FLOAT)(g_CurrentMode.viewport.width / 2), (FLOAT)(g_CurrentMode.viewport.height / 2) + 175, 0xffc0c0c0, msg, wcslen( msg ), (XBFONT_CENTER_X | XBFONT_CENTER_Y) );
	g_Font18.SetScaleFactors( 1.0, 1.0 );

	g_pd3dDevice->Present( NULL, NULL, NULL, NULL );

	pLogoSurface->Release();
	pBackBuffer->Release();
	pLinksBoksLogo->Release();
}



INT InitGraphics()
{
	char buf[64];
	int i = 0;

	// Create the D3D object.
    if( NULL == ( g_pD3D = Direct3DCreate8( D3D_SDK_VERSION ) ) )
        return 1;

	DWORD videoflags = XGetVideoFlags();

	D3DDISPLAYMODE d3ddm;
	g_pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &d3ddm );

    // Set up the structure used to create the D3DDevice.
    D3DPRESENT_PARAMETERS d3dpp; 
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.BackBufferFormat       = D3DFMT_LIN_X8R8G8B8;
    //d3dpp.BackBufferFormat       = d3ddm.Format;
    d3dpp.BackBufferCount        = 1;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
//    d3dpp.AutoDepthStencilFormat = D3DFMT_D24S8;
    d3dpp.SwapEffect             = D3DSWAPEFFECT_DISCARD;
    d3dpp.FullScreen_PresentationInterval = D3DPRESENT_INTERVAL_ONE_OR_IMMEDIATE;

	if( XGetVideoStandard() == XC_VIDEO_STANDARD_NTSC_M )
	{
		if( LinksBoks_GetOptionBool( "xbox_no_hdtv" ) )
		{
			OutputDebugString( "Skipping all 3 HDTV modes\n" );
			i = 3;
		}
	}
	else
		i = 4;

	// Choose an appropriate video mode
	for(; g_VideoModes[i].name ; i++ )
	{
		g_CurrentMode = g_VideoModes[i];

		if(	((i == 0) && (LinksBoks_GetOptionBool("xbox_no_1080i")))
		||	((i == 1) && (LinksBoks_GetOptionBool("xbox_no_720p"))) )
		{
			sprintf( buf, "Skipping %S (disabled explicitely)\n", g_CurrentMode.name );
			OutputDebugString( buf );
			continue;
		}

		sprintf(buf, "Trying %S...\n", g_CurrentMode.name);
		OutputDebugString( buf );

		if( !g_CurrentMode.standard || (g_CurrentMode.standard == XGetVideoStandard()) )
		{
			if( !g_CurrentMode.flags_in || ((videoflags & g_CurrentMode.flags_in) == g_CurrentMode.flags_in) )
			{
				sprintf(buf, "Found appropriate resolution: %S!\n", g_CurrentMode.name);
				OutputDebugString( buf );

				// Ok, this mode should work
			    d3dpp.BackBufferWidth = g_CurrentMode.viewport.width;
			    d3dpp.BackBufferHeight = g_CurrentMode.viewport.height;
				d3dpp.Flags = g_CurrentMode.flags_out;

			    // Create the Direct3D device.
				if( !FAILED( g_pD3D->CreateDevice( 0, D3DDEVTYPE_HAL, NULL,
												D3DCREATE_HARDWARE_VERTEXPROCESSING,
												&d3dpp, &g_pd3dDevice ) ) )
					break;
			}
		}
	}

	// Load texture and misc resources
	if( FAILED( g_pResources.Create( "LinksBoks.xpr" ) ) )
		return 3;


    // Arial Unicode MS 18, regular, 32-376, for keys
    if( FAILED( g_Font18.Create( "Font18.xpr" ) ) )
        return 3;

    // Arial 12, bold, 32-255, for capital words on keys
    if( FAILED( g_BigFont.Create( "BigFont.xpr" ) ) )
        return 3;

    // Xbox dingbats (buttons) 24
    if( FAILED( g_FontButtons.Create( "Xboxdings_24.xpr" ) ) )
        return 3;

	// Since we have a working video mode and our textures/fonts, draw our pretty (?) splash screen!
	DrawSplashScreen();

	if( FAILED( InitXboxInput() ) )
        return 2;

	g_pMousePtr = g_pResources.GetTexture( "MousePointer" );
	if( !g_pMousePtr )
		return 4;

	return 0;
}