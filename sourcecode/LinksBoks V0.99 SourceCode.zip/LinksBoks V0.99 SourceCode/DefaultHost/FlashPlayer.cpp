#include "LBHostApp.h"

struct FlashInfo g_FI;
FlashDisplay g_FD;
FlashHandle g_FH;
struct timeval g_FlashNextWakeUp;
LPDIRECT3DSURFACE8 g_pFlashSurface = NULL;
LPDIRECT3DTEXTURE8 g_pFlashTexture = NULL;
BOOL g_bFlashPaused;

static void FlashGoToURL(char *url, char *target, void *pointer)
{
	LinksBoksWindow *pLB = (LinksBoksWindow *)pointer;

	pLB->GoToURLInNewTab((unsigned char *)url);
}

int FlashPlayerInit(LinksBoksWindow *pLB, unsigned char *cmdline, unsigned char *file, int fd)
{
	int zoomedheight, zoomedwidth;
	void *buffer;
	DWORD size;
	int status;

	g_FH = FlashNew();

	XBUtil_LoadFile((const char *)file, &buffer, &size);

	/* Need to handle errors here... */
	do {
		status = FlashParse(g_FH, 0, (char *)buffer, (long)size);
	} while (status & FLASH_PARSE_NEED_DATA);

	FlashGetInfo(g_FH, &g_FI);

	/* Graphics init */
    LPDIRECT3DTEXTURE8 pTexture = NULL;
	UINT w = (UINT)g_FI.frameWidth/20, h = (UINT)g_FI.frameHeight/20; 

	zoomedwidth = w;
	zoomedheight = h;

	g_pd3dDevice->CreateTexture( zoomedwidth, zoomedheight, 0, 0, D3DFMT_LIN_X8R8G8B8, 0, &g_pFlashTexture );
	g_pd3dDevice->CreateImageSurface( zoomedwidth, zoomedheight, D3DFMT_LIN_X8R8G8B8, &g_pFlashSurface );

    D3DLOCKED_RECT d3dlr;
    g_pFlashSurface->LockRect( &d3dlr, NULL, 0 );
	DWORD * pDst = (DWORD *)d3dlr.pBits;
	int DPitch = d3dlr.Pitch/4;

	g_FD.pixels = d3dlr.pBits;
	g_FD.bpl = d3dlr.Pitch;
	g_FD.bpp = 4;
	g_FD.depth = 32;
	g_FD.width = zoomedwidth;
	g_FD.height = zoomedheight;
	FlashGraphicInit(g_FH, &g_FD);

	g_bFlashPaused = FALSE;

	//FlashSettings(g_FH, PLAYER_LOOP);
	FlashSetGetUrlMethod(g_FH, FlashGoToURL, pLB);

	FlashExec(g_FH, FLASH_WAKEUP, NULL, &g_FlashNextWakeUp);

	g_pFlashSurface->UnlockRect();

	return 0;
}

VOID LockFlashSurface()
{
    D3DLOCKED_RECT d3dlr;
    g_pFlashSurface->LockRect( &d3dlr, NULL, 0 );
	DWORD * pDst = (DWORD *)d3dlr.pBits;
	g_FD.pixels = d3dlr.pBits;
}

VOID UnlockFlashSurface()
{
	if(g_InputMode != FLASH_PLAYER_MODE)
		return;

	g_pFlashSurface->UnlockRect();
}

VOID DrawFlashPlayer(LinksBoksWindow *pLB, LPDIRECT3DSURFACE8 pDestSurface)
{
	if(g_InputMode != FLASH_PLAYER_MODE)
		return;

	/* Wakeup */
	long delay = (g_FlashNextWakeUp.tv_sec*1000 + g_FlashNextWakeUp.tv_usec/1000) - timeGetTime();
	if(delay < 0)
	{
		FlashExec(g_FH, FLASH_WAKEUP, NULL, &g_FlashNextWakeUp);
	}

    if(g_FD.flash_refresh)
	{
		LPDIRECT3DSURFACE8 pSurface = NULL;

		g_pFlashTexture->GetSurfaceLevel(0, &pSurface);
		g_pd3dDevice->CopyRects(g_pFlashSurface, NULL, 0, pSurface, NULL);
		pSurface->Release();
		
		g_FD.flash_refresh = 0;
	}

	g_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );
	pLB->CreatePrimitive( (pLB->GetViewPortWidth() - g_FD.width) / 2,
						  (pLB->GetViewPortHeight() - g_FD.height) / 2,
						  g_FD.width, g_FD.height, 0 );
	g_pd3dDevice->SetTexture( 0, g_pFlashTexture );
	pLB->RenderPrimitive( pDestSurface );
	g_pd3dDevice->SetTexture( 0, NULL );
	g_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
}

VOID FlashPlayerTerminate()
{
	FlashClose(g_FH);
	UnlockFlashSurface();
	g_pFlashSurface->Release();
	g_pFlashSurface = NULL;
	g_pFlashTexture->Release();
	g_pFlashTexture = NULL;
}
