
#include "linksboks.h"
#include <xact.h>

/* "demo:" protocol: an internal protocol */
class DemoProtocol : public LinksBoksInternalProtocol
{
public:
	int OnCall(unsigned char *url, void *connection);
	DemoProtocol(void) :
	  LinksBoksInternalProtocol((unsigned char *)"demo", 0, 1, 0, 0) {}
};

/* "soundtrack:" protocol: an external protocol */
class SoundTrackProtocol : public LinksBoksExternalProtocol
{
public:
	int OnCall(unsigned char *url, void *session);
	SoundTrackProtocol(void) :
	  LinksBoksExternalProtocol((unsigned char *)"soundtrack", 0, 0, 0, 0) {}
};

HRESULT InitializeXACT(void);


LinksBoksProtocol *g_DemoProtocols[];