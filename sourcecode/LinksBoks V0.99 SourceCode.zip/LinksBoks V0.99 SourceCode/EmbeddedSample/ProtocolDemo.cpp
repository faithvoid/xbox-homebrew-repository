
#include "ProtocolDemo.h"
#include <dsstdfx.h>
#include <vector>
#include "XactSounds.h"

using namespace std;



class CSoundtrack
{
public:
    CSoundtrack() {}

    VOID    GetSoundtrackName( WCHAR* strName ) { wcscpy( strName, m_strName ); }
    UINT    GetSongCount() { return m_uSongCount; }

    WCHAR       m_strName[MAX_SOUNDTRACK_NAME];
    UINT        m_uSongCount;
    BOOL        m_bGameSoundtrack;
    union 
    {
        UINT    m_uSoundtrackID;
        UINT    m_uSoundtrackIndex;
    };
};


// Volume scaling factor
static const FLOAT VOLUME_SCALE = 5.0f;

struct MM_SONG
{
    WCHAR*  strName;
    CHAR*   strFilename;
    DWORD   dwLength;
};

struct MM_GAMESOUNDTRACK
{
    WCHAR*  strName;
    CHAR*   strDir;
    UINT    uNumSongs;
};

MM_GAMESOUNDTRACK g_aGameSoundtracks[] =
{
    { L"LinksBoks sample's soundtrack", "d:\\media\\sounds\\soundtrack", 1 },
};


#define NUM_GAME_SOUNDTRACKS ( sizeof(g_aGameSoundtracks) / sizeof(g_aGameSoundtracks[0]) )

CONST CHAR g_strSoundtrackCue[] = "Cue1";

IXACTEngine*            g_pXACT;                            // XACT Engine
BYTE*                   g_pbSoundBank;                      // Sound Bank data
PXACTSOUNDBANK          g_pSoundBank;                       // XACT Sound Bank
DWORD                   g_dwSoundCueIndex;                  // Current sound cue index
PXACTWMAPLAYLIST        g_pWMAPlaylist;                     // WMA Playlist for soundtracks
vector<CSoundtrack>     g_vSoundtracks;                     // Vector of soundtracks

#define SOUNDTRACK_CATEGORY XACT_CATEGORY_BGMUSIC


//-----------------------------------------------------------------------------
// Name: XBUtil_LoadFile()
// Desc: Loads the specified file into a newly allocated buffer. Note that
//       dwSize is the size of the actual data, which is not necessarily the
//       size of the buffer. Caller is expected to free the buffer using free().  
//-----------------------------------------------------------------------------
HRESULT XACTLoadFile( const CHAR* strFile, VOID** ppFileData, DWORD* pdwSize )
{
    if( ( NULL == strFile ) || ( NULL ==ppFileData ) )
        return E_INVALIDARG;

    // Initialize output values in case of error
    if( ppFileData )   (*ppFileData) = NULL;
    if( pdwSize )      (*pdwSize)    = 0;

    // Attempt to open the file
    HANDLE hFile = CreateFile( strFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
                               FILE_FLAG_OVERLAPPED | FILE_FLAG_NO_BUFFERING, NULL );
    if( INVALID_HANDLE_VALUE == hFile )
        return E_FAIL;

    // Determine how large the file is
    DWORD dwFileSize = GetFileSize( hFile, NULL );
    if( dwFileSize == (DWORD)-1 )
    {
        CloseHandle( hFile );
        return E_FAIL;
    }

    // Round the file size up to DVD sector multiple
    dwFileSize += XBOX_DVD_SECTOR_SIZE - 1;
    dwFileSize /= XBOX_DVD_SECTOR_SIZE;
    dwFileSize *= XBOX_DVD_SECTOR_SIZE;

    // Allocate a buffer to store the file data
    VOID* pDataBuffer = malloc( dwFileSize );
    if( pDataBuffer == NULL )
    {
        CloseHandle( hFile );
        return E_OUTOFMEMORY;
    }

    // Kick off the read
    OVERLAPPED overlapped = {0};
    BOOL bResult = ReadFile( hFile, pDataBuffer, dwFileSize, NULL, &overlapped );

    // If there was an error other than IO_PENDING, the read failed
    if( !bResult && GetLastError() != ERROR_IO_PENDING )
    {
        free( pDataBuffer );
        CloseHandle( hFile );
        return GetLastError();
    }

    // Wait for the operation to finish
    DWORD dwBytesRead;
    if( !GetOverlappedResult( hFile, &overlapped, &dwBytesRead, TRUE ) )
    {
        free( pDataBuffer );
        CloseHandle( hFile );
        return GetLastError();
    }

    // Pass the data pointer back to the caller and clean up
    if( ppFileData )    (*ppFileData) = pDataBuffer;
    if( pdwSize )       (*pdwSize)    = dwBytesRead;
    CloseHandle( hFile );

    return S_OK;
}


HRESULT InitializeXACT(void)
{

    // Initialize the XACT Engine

    // Create the XACT runtime engine
    // Note: We only really need one concurrent stream here, but
    // concurrent streams are also used for auditioning, so we'll
    // just leave a few extra.
    // The dwMaxConcurrentStreams parameter may be removed in a future
    // release of the XACT audio library, but it's here for the July 2002 XDK
    XACT_RUNTIME_PARAMETERS xrParams;
    xrParams.dwMax2DHwVoices        = 128;
    xrParams.dwMax3DHwVoices        = 32;
    xrParams.dwMaxConcurrentStreams = 16;
    xrParams.dwMaxNotifications     = 0;
    if( FAILED( XACTEngineCreate( &xrParams, &g_pXACT ) ) )
        return E_FAIL;

    // Register our (almost) empty soundbank with XACT
    //
    // All we really need is a soundbank with a single empty cue (i.e., one
    // that does not bind to any audio files), however, XACT does not allow
    // soundbanks consisting only of empty cues.  Empty cues can reside among
    // other functioning cues, but not alone.
    //
    // The XactSounds.xsb soundbank in this sample has a single cue that binds to
    // a small audio file in a wavebank.  Note that we have not loaded a
    // wavebank anywhere in this code.  This is because we are going to use the
    // cue in this soundbank for a WMA playlist, and we will never play the
    // audio to which the cue refers
    DWORD dwFileSize;
    if( FAILED( XACTLoadFile( "d:\\media\\sounds\\XactSounds.xsb", (VOID **)&g_pbSoundBank, &dwFileSize ) ) )
        return E_FAIL;
    if( FAILED( g_pXACT->CreateSoundBank( g_pbSoundBank, dwFileSize, &g_pSoundBank ) ) )
        return E_FAIL;

    // Download the standard DirectSound effects image
    DSEFFECTIMAGELOC EffectLoc;
    EffectLoc.dwI3DL2ReverbIndex = GraphI3DL2_I3DL2Reverb;
    EffectLoc.dwCrosstalkIndex   = GraphXTalk_XTalk;
    if( FAILED( XAudioDownloadEffectsImage( "d:\\media\\dsstdfx.bin", 
                                            &EffectLoc, 
                                            XAUDIO_DOWNLOADFX_EXTERNFILE, 
                                            NULL ) ) )
        return E_FAIL;

    // Find the index of the cue we've reserved for soundtracks
    if( FAILED( g_pSoundBank->GetSoundCueIndexFromFriendlyName( g_strSoundtrackCue, &g_dwSoundCueIndex ) ) )
        return E_FAIL;


    // Add each game provided soundtrack to the soundtrack vector
    for( UINT i = 0; i < NUM_GAME_SOUNDTRACKS; ++i )
    {
        CSoundtrack sndtrk;

        sndtrk.m_bGameSoundtrack    = TRUE;
        sndtrk.m_uSoundtrackIndex   = i;
        sndtrk.m_uSongCount         = g_aGameSoundtracks[i].uNumSongs;
        wcscpy( sndtrk.m_strName, g_aGameSoundtracks[i].strName );

        g_vSoundtracks.push_back( sndtrk );
    }

    // Add each user provided soundtrack to the soundtrack vector
    XSOUNDTRACK_DATA stData;
    HANDLE hSoundtrack = XFindFirstSoundtrack( &stData );
    if( INVALID_HANDLE_VALUE != hSoundtrack )
    {
        do
        {
            // Ignore empty soundtracks
            if( stData.uSongCount > 0 )
            {
                CSoundtrack sndtrk;

                sndtrk.m_bGameSoundtrack    = FALSE;
                sndtrk.m_uSoundtrackID      = stData.uSoundtrackId;
                sndtrk.m_uSongCount         = stData.uSongCount;
                wcscpy( sndtrk.m_strName, stData.szName );

                g_vSoundtracks.push_back( sndtrk );
            }
        } while( XFindNextSoundtrack( hSoundtrack, &stData ) );
    }

    XFindClose(hSoundtrack);

	return S_OK;
}

HRESULT MakePlaylist( DWORD dwSoundtrack )
{
    // Clear out any previous playlist
    if( g_pWMAPlaylist )
    {
        g_pWMAPlaylist->Release();
        g_pWMAPlaylist = NULL;
    }

    // Create the WMA Playlist
    if( FAILED( g_pSoundBank->CreateWmaPlayList( g_dwSoundCueIndex, 0, &g_pWMAPlaylist ) ) )
    {
        return E_FAIL;
    }

    // Add all songs in the soundtrack to the playlist
    XACT_WMA_PLAYLIST_ADD xwpAddInfo = { 0 };

    if( g_vSoundtracks[dwSoundtrack].m_bGameSoundtrack )
    {
        xwpAddInfo.dwType           = eXACTWmaPlayListAdd_Directory;
        xwpAddInfo.pszFileName      = g_aGameSoundtracks[ g_vSoundtracks[ dwSoundtrack ].m_uSoundtrackIndex ].strDir;
    }
    else
    {
        xwpAddInfo.dwType           = eXACTWmaPlayListAdd_Soundtrack;
        xwpAddInfo.dwSoundtrackId   = g_vSoundtracks[ dwSoundtrack ].m_uSoundtrackID;
    }

    g_pWMAPlaylist->Add( &xwpAddInfo, NULL );

	return S_OK;
}











/************** Our demo protocols and their handler functions ***************/

LinksBoksProtocol *g_DemoProtocols[] = {
	new DemoProtocol(),
	new SoundTrackProtocol(),
	NULL
};

int DemoProtocol::OnCall(unsigned char *url, void *connection)
{
	/* Yet another possible exploit! Hope you don't have a lot of soundtracks... */
	char body[10000];
	
	/* Page header */
	strcpy( body,
"<html>\n\
<head>\n\
<title>Demo Page</title>\n\
</head>\n\
\n\
<body bgcolor=gray link=red vlink=red alink=red text=black>\n\
\n\
<table border=0 width=\"90%\" align=center cellspacing=0 cellpadding=2 bgcolor=black><tr><td>\n\
<table border=0 width=\"100%\" align=center cellspacing=0 cellpadding=4 bgcolor=white><tr><td>\n\
");

	/* Intro text */
	strcat(body, "<h2 align=center>LinksBoks Embedded Demo</h2>\n");
	strcat(body, "<i>NOTE: use the right thumbstick to scroll, the d-pad to navigate (up/down: jump\n\
				 between hyperlinks, right: follow link, left: go back) and the BACK button to quit.</i>\n");

	strcat(body, "<p>You're running a little demo which covers these specific features:\n\
				 <ul>\n\
				 <li>LinksBoks engine creating and basic use;\n\
				 <li>Setting options;\n\
				 <li>Sending input (keyboard/mouse) events to the engine;\n\
				 <li>Retrieving the browser window's surface and make it into a texture;\n\
				 <li>Registering and catching external and internal protocols.\n\
				 </ul></p>");

	/* Soundtracks */
	strcat(body, "<h3>Soundtracks</h3>");
	strcat(body, "<p>To explain the different protocol types, we created in this sample 2 protocols:\n\
				 one 'demo:' internal protocol to build this page, and one 'soundtrack:' external protocol to\n\
				 play songs. \"Internal\" protocols are expected to return something to display\n\
				 (like the http: protocol); \"external\" protocols are not really protocols, they are\n\
				 only used to simply call a function when the right URL is called (examples\n\
				 include the mailto: or javascript: pseudo-protocols). You can see all links below\n\
				 are <code>soundtrack:something</code> while this page's URL is <code>demo:about</code>.</p>\n");

	char temp[256];
	for(DWORD i = 0; i < g_vSoundtracks.size(); i++)
	{
		WCHAR strSoundtrack[MAX_SOUNDTRACK_NAME];
		g_vSoundtracks[i].GetSoundtrackName( strSoundtrack );
		sprintf(temp, "<h4>%S</h4>\n<ol>\n", strSoundtrack);
		strcat(body, temp);
		MakePlaylist(i);

		for(UINT j = 0; j < g_vSoundtracks[i].GetSongCount(); j++)
		{
			g_pWMAPlaylist->Next();
			WCHAR strSongName[MAX_SONG_NAME * sizeof(WCHAR)];
			DWORD dwSongLength;
			g_pWMAPlaylist->GetCurrentSongInfo(&dwSongLength, strSongName, MAX_SONG_NAME * sizeof(WCHAR), NULL);

			sprintf(temp, "<li><a href='soundtrack:%d/%d'>%S</a></li>\n", i, j, strSongName);
			strcat(body, temp);
		}

		strcat(body, "</ol>\n");
	}

	strcat(body, "<h3>Some external links</h3>\n");
	strcat(body, "<p>Just in case you want to test this weird browser on other sites :)</p>\n\
				 <a href=\"http://www.google.com/\">Google</a><br>\n\
				 <a href=\"http://ysbox.online.fr/\">The LinksBoks Wiki</a><br>\n\
				 <a href=\"http://www.xbox-scene.com/\">Xbox-scene</a>\n\
				 <a href=\"http://www.gueux.be/\">Gueux</a>\n");


	/* Page footer */
	strcat(body, "</td></tr></table>\n</td></tr></table>\n</body>\n</html>\n");

	OutputDebugString(body);
	SendResponse(connection, (unsigned char *)"text/html", (unsigned char *)body, strlen(body));

	return LINKSBOKS_RESPONSE_OK;
}

int SoundTrackProtocol::OnCall(unsigned char *url, void *session)
{
	DWORD dwSoundtrack = 0, dwSong = 0;

	/* This can be exploited, but hey it's just a silly demo... */
	sscanf((const char *)url, "soundtrack:%d/%d", &dwSoundtrack, &dwSong);
	MakePlaylist(dwSoundtrack);

	for(DWORD i = 0; i <= dwSong; i++)
		g_pWMAPlaylist->Next();

    g_pSoundBank->Play( g_dwSoundCueIndex, NULL, XACT_FLAG_SOUNDCUE_AUTORELEASE, NULL );

	/* Return value for external protocols is unused, just fill some value in */
	return 0;
}
