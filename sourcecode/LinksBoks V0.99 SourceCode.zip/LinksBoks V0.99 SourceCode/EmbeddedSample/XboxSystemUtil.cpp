
#include <xtl.h>


typedef struct _UnicodeString
{
	USHORT	Length;
	USHORT	MaximumLength;
	PSTR	Buffer;
} UNICODE_STRING;

extern "C" XBOXAPI LONG WINAPI IoCreateSymbolicLink(IN UNICODE_STRING *SymbolicLinkName, IN UNICODE_STRING *DeviceName);


/* Helper function to mount a drive. */
LONG MountDevice(LPSTR sSymbolicLinkName, LPSTR sDeviceName)
{

	UNICODE_STRING deviceName, symbolicLinkName;

	deviceName.Buffer  = sDeviceName;
	deviceName.Length = (USHORT)strlen(sDeviceName);
	deviceName.MaximumLength = (USHORT)strlen(sDeviceName) + 1;

	symbolicLinkName.Buffer  = sSymbolicLinkName;
	symbolicLinkName.Length = (USHORT)strlen(sSymbolicLinkName);
	symbolicLinkName.MaximumLength = (USHORT)strlen(sSymbolicLinkName) + 1;

	return IoCreateSymbolicLink(&symbolicLinkName, &deviceName);

}


INT InitXboxSystems()
{
	/* Mount drives */
	MountDevice( "\\??\\C:", "\\Device\\Harddisk0\\Partition2" );
	MountDevice( "\\??\\E:", "\\Device\\Harddisk0\\Partition1" );
	MountDevice( "\\??\\F:", "\\Device\\Harddisk0\\Partition6" );
	MountDevice( "\\??\\G:", "\\Device\\Harddisk0\\Partition7" );
	MountDevice( "\\??\\X:", "\\Device\\Harddisk0\\Partition3" );
	MountDevice( "\\??\\Y:", "\\Device\\Harddisk0\\Partition4" );
	MountDevice( "\\??\\Z:", "\\Device\\Harddisk0\\Partition5" );


    // Initialize the network stack. For default initialization, call
    // XNetStartup( NULL );
    XNetStartupParams xnsp;
	int iResult;
    WSADATA WsaData;

    ZeroMemory( &xnsp, sizeof(xnsp) );
    xnsp.cfgSizeOfStruct = sizeof(xnsp);

	// create more memory for networking
	xnsp.cfgPrivatePoolSizeInPages = 64; // == 256kb, default = 12 (48kb)
	xnsp.cfgEnetReceiveQueueLength = 16; // == 32kb, default = 8 (16kb)
	xnsp.cfgIpFragMaxSimultaneous = 16; // default = 4
	xnsp.cfgIpFragMaxPacketDiv256 = 32; // == 8kb, default = 8 (2kb)
	xnsp.cfgSockMaxSockets = 64; // default = 64
	xnsp.cfgSockDefaultRecvBufsizeInK = 128; // default = 16
	xnsp.cfgSockDefaultSendBufsizeInK = 128; // default = 16

    xnsp.cfgFlags = XNET_STARTUP_BYPASS_SECURITY;
    iResult = XNetStartup( &xnsp );
    if( iResult != NO_ERROR )
        return -1;

    // Standard WinSock startup. The Xbox allows all versions of Winsock
    // up through 2.2 (i.e. 1.0, 1.1, 2.0, 2.1, and 2.2), although it 
    // technically supports only and exactly what is specified in the 
    // Xbox network documentation, not necessarily the full Winsock 
    // functional specification.
    iResult = WSAStartup( MAKEWORD(2,2), &WsaData );
    if( iResult != NO_ERROR )
        return -1;

	return 0;
}