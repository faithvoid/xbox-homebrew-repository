LinksBoks "Embedded" Sample
===========================

This little demo illustrates some of the neat stuff
that can be achieved with the new "library-host app"
approach. Enjoy.

The Terrain class is from from andypike.com, slightly
hacked with my dirty lines of code.

ysbox, 20050416