// EmbeddedSample.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "Terrain.h"
#include "linksboks.h"
#include "xbinput.h"
#include "ProtocolDemo.h"

//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------
LPDIRECT3D8             g_pD3D2       = NULL; // Used to create the D3DDevice
LPDIRECT3DDEVICE8       g_pD3D2Device = NULL; // Our rendering device

// A structure for our custom vertex type
struct CUSTOMVERTEX
{
    FLOAT x, y, z;		// The vertex position
	FLOAT nx, ny, nz;	// Lightning normals
    DWORD color;		// The vertex color
	FLOAT u, v;			// Texture coords
};

// Our custom FVF, which describes our custom vertex structure
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1)

FLOAT fSecsPerTick;
LARGE_INTEGER qwTime, qwLastTime, qwElapsedTime, qwAppTime, qwElapsedAppTime;
FLOAT fTime, fElapsedTime, fAppTime, fElapsedAppTime;

LPDIRECT3DSURFACE8 g_pdBackground;

XBGAMEPAD*             g_Gamepad;

CTerrain *g_pTerrain;

LinksBoksViewPort g_ViewPort = { 320, 240, 0, 0, 0, 0 };
LinksBoksWindow *g_pLB;

extern INT InitXboxSystems();

// 1 megabyte
#define KB	(1024)

// Add one line of text to the output buffer.
#define AddStr(a,b) (pstrOut += wsprintf( pstrOut, a, b ))

void debug_memory_status(void)
{
    MEMORYSTATUS stat;
    CHAR strOut[1024], *pstrOut;

    // Get the memory status.
    GlobalMemoryStatus( &stat );

    // Setup the output string.
    pstrOut = strOut;
    AddStr( "%4d total kB of virtual memory.\n", stat.dwTotalVirtual / KB );
    AddStr( "%4d  free kB of virtual memory.\n", stat.dwAvailVirtual / KB );
    AddStr( "%4d total kB of physical memory.\n", stat.dwTotalPhys / KB );
    AddStr( "%4d  free kB of physical memory.\n", stat.dwAvailPhys / KB );
    AddStr( "%4d total kB of paging file.\n", stat.dwTotalPageFile / KB );
    AddStr( "%4d  free kB of paging file.\n", stat.dwAvailPageFile / KB );
    AddStr( "%4d  percent of memory is in use.\n", stat.dwMemoryLoad );

    // Output the string.
    OutputDebugString( strOut );
}




VOID InitLight( D3DLIGHT8& light, D3DLIGHTTYPE ltType,
                       FLOAT x, FLOAT y, FLOAT z )
{
    ZeroMemory( &light, sizeof(D3DLIGHT8) );
    light.Type         = ltType;
    light.Diffuse.r    = 1.0f;
    light.Diffuse.g    = 1.0f;
    light.Diffuse.b    = 1.0f;
    light.Position     = D3DXVECTOR3(x,y,z);
    light.Position.x   = x;
    light.Position.y   = y;
    light.Position.z   = z;
    light.Direction     = D3DXVECTOR3(x,y,z);
	D3DXVec3Normalize( (D3DXVECTOR3*)&light.Direction, (D3DXVECTOR3*)&light.Direction );
    light.Range        = 1000.0f;
	light.Falloff      = 0.6f;
	light.Theta        = D3DX_PI/5.0f;
	light.Phi          = D3DX_PI/3.0f;
}



VOID InitMaterial( D3DMATERIAL8& mtrl, FLOAT r, FLOAT g, FLOAT b,
                          FLOAT a )
{
    ZeroMemory( &mtrl, sizeof(D3DMATERIAL8) );
    mtrl.Diffuse.r = mtrl.Ambient.r = r;
    mtrl.Diffuse.g = mtrl.Ambient.g = g;
    mtrl.Diffuse.b = mtrl.Ambient.b = b;
    mtrl.Diffuse.a = mtrl.Ambient.a = a;
}



VOID InitTime()
{
    // Get the frequency of the timer
	LARGE_INTEGER qwTicksPerSec;
    QueryPerformanceFrequency( &qwTicksPerSec );
    fSecsPerTick = 1.0f / (FLOAT)qwTicksPerSec.QuadPart;

    // Save the start time
    QueryPerformanceCounter( &qwTime );
    qwLastTime.QuadPart = qwTime.QuadPart;

    qwAppTime.QuadPart        = 0;
    qwElapsedTime.QuadPart    = 0;
    qwElapsedAppTime.QuadPart = 0;
}



HRESULT InitD3D()
{
    // Create the D3D object.
    if( NULL == ( g_pD3D2 = Direct3DCreate8( D3D_SDK_VERSION ) ) )
        return E_FAIL;

    // Set up the structure used to create the D3DDevice.
    D3DPRESENT_PARAMETERS d3dpp; 
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.BackBufferWidth        = 640;
    d3dpp.BackBufferHeight       = 480;
    d3dpp.BackBufferFormat       = D3DFMT_LIN_X8R8G8B8;
    d3dpp.BackBufferCount        = 1;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D24S8;
    d3dpp.SwapEffect             = D3DSWAPEFFECT_DISCARD;
    d3dpp.FullScreen_PresentationInterval = D3DPRESENT_INTERVAL_ONE_OR_IMMEDIATE;

    // Create the Direct3D device.
    if( FAILED( g_pD3D2->CreateDevice( 0, D3DDEVTYPE_HAL, NULL,
                                      D3DCREATE_HARDWARE_VERTEXPROCESSING,
                                      &d3dpp, &g_pD3D2Device ) ) )
        return E_FAIL;

    D3DXMATRIX matView;
    D3DXMatrixLookAtLH(&matView, &D3DXVECTOR3(0.0f, 350.0f, -150.0f),	//Camera Position
                                 &D3DXVECTOR3(0.0f, 0.0f, 0.0f),		//Look At Position
                                 &D3DXVECTOR3(0.0f, 0.0f, 1.0f));		//Up Direction
    g_pD3D2Device->SetTransform(D3DTS_VIEW, &matView);

	//Here we specify the field of view, aspect ration and near and far clipping planes.
    D3DXMATRIX matProj;
    D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI/4, 1.0f, 1.0f, 2000.0f);
    g_pD3D2Device->SetTransform(D3DTS_PROJECTION, &matProj);

    return S_OK;
}

HRESULT InitGamepad(void)
{
	HRESULT hr;

	XInitDevices( 0, NULL );

    // Create the gamepad devices
	OutputDebugString( "XBApp: Creating gamepad devices...\n" );
    if( FAILED( hr = XBInput_CreateGamepads( &g_Gamepad ) ) )
    {
		OutputDebugString( "Call to CreateGamepads() failed!\n" );
        return hr;
    }

	return S_OK;
}


VOID UpdateTime()
{
    QueryPerformanceCounter( &qwTime );
    qwElapsedTime.QuadPart = qwTime.QuadPart - qwLastTime.QuadPart;
    qwLastTime.QuadPart    = qwTime.QuadPart;
    qwElapsedAppTime.QuadPart = qwElapsedTime.QuadPart;
    qwAppTime.QuadPart    += qwElapsedAppTime.QuadPart;

    // Store the current time values as floating point
    fTime           = fSecsPerTick * ((FLOAT)(qwTime.QuadPart));
    fElapsedTime    = fSecsPerTick * ((FLOAT)(qwElapsedTime.QuadPart));
    fAppTime        = fSecsPerTick * ((FLOAT)(qwAppTime.QuadPart));
    fElapsedAppTime = fSecsPerTick * ((FLOAT)(qwElapsedAppTime.QuadPart));
}



VOID Update()
{
	
	/* Mess with the world matrix to make that cosy "swing" effect */
	D3DXMATRIX matRotate;
    D3DXMATRIX matWorld;
    g_pD3D2Device->GetTransform( D3DTS_WORLD, &matWorld );
    FLOAT fZRotate = cos(-fElapsedTime*D3DX_PI*0.5f);
    D3DXMatrixRotationYawPitchRoll( &matRotate, cos(fAppTime/4.0)*0.002f, cos(fAppTime/3.0)*0.0005f, cos(fAppTime/4.0)*0.002f );
    D3DXMatrixMultiply( &matWorld, &matWorld, &matRotate );
    g_pD3D2Device->SetTransform( D3DTS_WORLD, &matWorld );

	// This is where LinksBoks does all its stuff (this call does one pass in
	// the LinksBoks' main loop)
	// Note that this function can block a significant amount of time.
	// TODO: see what we can do with threads
	LinksBoks_FrameMove();


	// Let XACT do its work
    XACTEngineDoWork();


    // Setup a material
    D3DMATERIAL8 mtrl;
    InitMaterial( mtrl, 1.0f, 1.0f, 1.0f, 1.0f );
    g_pD3D2Device->SetMaterial( &mtrl );

    // Set up a light
    D3DLIGHT8 light;
	InitLight( light, D3DLIGHT_DIRECTIONAL, -25.0f, 0.0f, -15.0f );
    light.Ambient.r = 0.1f;
    light.Ambient.g = 0.1f;
    light.Ambient.b = 0.1f;
    light.Diffuse.r = 0.3f;
    light.Diffuse.g = 0.3f;
    light.Diffuse.b = 0.3f;
    light.Range        = 40.0f;
    light.Attenuation1 = 0.4f;
    g_pD3D2Device->SetLight( 0, &light );
    g_pD3D2Device->LightEnable( 0, TRUE );

    // Set up another light
    D3DLIGHT8 light2;
	InitLight( light2, D3DLIGHT_SPOT, -70.0f, 110.0f, -20.0f );
    light2.Ambient.r = 0.0f;
    light2.Ambient.g = 0.0f;
    light2.Ambient.b = 1.0f;
	light2.Direction = D3DXVECTOR3(80.0f,-150.0f,20.0f);

	D3DXVec3Normalize( (D3DXVECTOR3*)&light2.Direction, (D3DXVECTOR3*)&light2.Direction );
	light2.Specular.r = 0.0f;
    light2.Specular.g = 1.0f;
    light2.Specular.b = 0.0f;
    light2.Range        = 750.0f;
    light2.Attenuation1 = 0.01f;
    g_pD3D2Device->SetLight( 1, &light2 );
    g_pD3D2Device->LightEnable( 1, TRUE );
    g_pD3D2Device->SetRenderState( D3DRS_LIGHTING, TRUE );


	///////////////////////////////////////////
	// Handle input and pass it to LinksBoks //
	///////////////////////////////////////////

	// Read the input for all connected gamepads
    XBInput_GetInput( g_Gamepad );


	if( (g_Gamepad[0].wPressedButtons & XINPUT_GAMEPAD_DPAD_LEFT) == XINPUT_GAMEPAD_DPAD_LEFT )
		g_pLB->KeyboardAction( LINKSBOKS_KBD_LEFT, 0 );
	if( (g_Gamepad[0].wPressedButtons & XINPUT_GAMEPAD_DPAD_RIGHT) == XINPUT_GAMEPAD_DPAD_RIGHT )
		g_pLB->KeyboardAction( LINKSBOKS_KBD_RIGHT, 0 );
	if( (g_Gamepad[0].wPressedButtons & XINPUT_GAMEPAD_DPAD_UP) == XINPUT_GAMEPAD_DPAD_UP )
		g_pLB->KeyboardAction( LINKSBOKS_KBD_UP, 0 );
	if( (g_Gamepad[0].wPressedButtons & XINPUT_GAMEPAD_DPAD_DOWN) == XINPUT_GAMEPAD_DPAD_DOWN )
		g_pLB->KeyboardAction( LINKSBOKS_KBD_DOWN, 0 );

	// Handle scrolling
	if( abs(g_Gamepad[0].fY2) > 0.2 )
	{
		// Up/down
		if( g_Gamepad[0].fY2 > 0 )
			g_pLB->MouseAction( 160, 120, LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELUP1 );
		else
			g_pLB->MouseAction( 160, 120, LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELDOWN1 );
	}
	if( abs(g_Gamepad[0].fX2) > 0.2 )
	{
		// Left/right
		if( g_Gamepad[0].fX2 > 0 )
			g_pLB->MouseAction( 160, 120, LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELRIGHT1 );
		else
			g_pLB->MouseAction( 160, 120, LINKSBOKS_MOUSE_MOVE | LINKSBOKS_MOUSE_WHEELLEFT1 );
	}

	if( (g_Gamepad[0].wPressedButtons & XINPUT_GAMEPAD_BACK) == XINPUT_GAMEPAD_BACK )
	{
		LD_LAUNCH_DASHBOARD LaunchData = { XLD_LAUNCH_DASHBOARD_MAIN_MENU };
		XLaunchNewImage( NULL, (LAUNCH_DATA*)&LaunchData );
	}

}



VOID Render()
{
	RECT srcRect;
	POINT dstPoint;

    g_pD3D2Device->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 
                         D3DCOLOR_XRGB(0,0,255), 1.0f, 0L );
	
	// Begin the scene
	g_pD3D2Device->BeginScene();

	g_pD3D2Device->SetRenderState(D3DRS_AMBIENT, D3DCOLOR_XRGB(60, 60, 60));

	// Copies the background texture directly to the backbuffer
	SetRect( &srcRect, 0, 0, 640, 480 );
	dstPoint.x = 0; dstPoint.y = 0;

	LPDIRECT3DSURFACE8 pBackBuffer;
	g_pD3D2Device->GetBackBuffer( 0, D3DBACKBUFFER_TYPE_MONO, &pBackBuffer );

	g_pD3D2Device->CopyRects( g_pdBackground, &srcRect, 1, pBackBuffer, &dstPoint );

	pBackBuffer->Release();


	// Creates a texture and copies the LinksBoks surface into it
	LPDIRECT3DTEXTURE8 pTexture = NULL;
	LPDIRECT3DSURFACE8 pSurface = NULL;

	g_pD3D2Device->CreateTexture( 320, 240, 1, 0, D3DFMT_LIN_A8R8G8B8, 0, &pTexture );

	pTexture->GetSurfaceLevel(0, &pSurface);
	g_pD3D2Device->CopyRects( g_pLB->GetSurface(), NULL, 0, pSurface, NULL );

    g_pD3D2Device->SetRenderState( D3DRS_ZENABLE, FALSE );


	// Finally, render the terrain
	g_pTerrain->SetTexture(pTexture);
	g_pTerrain->Render();


	pSurface->Release();
	pTexture->Release();

    // End the scene
    g_pD3D2Device->EndScene();
}




//-----------------------------------------------------------------------------
// Name: main()
// Desc: The application's entry point
//-----------------------------------------------------------------------------
void __cdecl main()
{
    // Initialize Direct3D
    if( FAILED( InitD3D() ) )
        return;

    // Initialize the terrain
	g_pTerrain = new CTerrain(g_pD3D2Device, 50, 50, 4.0, 40);

	/* Other initializations */
	InitTime();
	InitGamepad();
	InitXboxSystems();
	InitializeXACT();

	/* Dump memory status without LinksBoks loaded */
	debug_memory_status();

	/* Inits the LinksBoks core, with our custom protocols */
	LinksBoks_InitCore(NULL, g_DemoProtocols);

	/* Redefine some options before */
	LinksBoks_SetOptionString("homepage", (unsigned char *)"demo:about");
	LinksBoks_SetOptionBool("toolbar_button_visibility_back", FALSE);
	LinksBoks_SetOptionBool("toolbar_button_visibility_history", FALSE);
	LinksBoks_SetOptionBool("toolbar_button_visibility_forward", FALSE);
	LinksBoks_SetOptionBool("toolbar_button_visibility_reload", FALSE);
	LinksBoks_SetOptionBool("toolbar_button_visibility_stop", FALSE);
	LinksBoks_SetOptionBool("toolbar_button_visibility_bookmarks", FALSE);
	LinksBoks_SetOptionBool("tabs_show", FALSE);

	/* Create the LinksBoks window and dump memory status */
	g_pLB = LinksBoks_CreateWindow(g_pD3D2, g_pD3D2Device, g_ViewPort);
	debug_memory_status();

	/* Wait until the network is available */
	XNADDR xna;
	DWORD dwState;
	do
	{
		dwState = XNetGetTitleXnAddr(&xna);
		Sleep(50);
	} while (dwState==XNET_GET_XNADDR_PENDING);

	/* Loads the background texture */
	LPDIRECT3DTEXTURE8 pBackground;

	D3DXCreateTextureFromFileExA(g_pD3D2Device, "D:\\Media\\background.tga", 0, 0,
		1, 0, D3DFMT_LIN_X8R8G8B8, D3DPOOL_MANAGED, D3DX_FILTER_NONE, D3DX_FILTER_NONE, 0,
		NULL, NULL, &pBackground);
	
	pBackground->GetSurfaceLevel(0, &g_pdBackground);
	g_pTerrain->SetTexture( pBackground );

	pBackground->Release();

    while( TRUE )
    {
        // What time is it?
        UpdateTime();
        // Update the world
        Update();   
        // Render the scene
        Render();

        // Present the backbuffer contents to the display
        g_pD3D2Device->Present( NULL, NULL, NULL, NULL );

    }
}
