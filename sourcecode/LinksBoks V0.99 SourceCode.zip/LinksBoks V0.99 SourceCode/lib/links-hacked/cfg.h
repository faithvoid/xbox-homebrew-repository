/* cfg.h
 * (c) 2002 Mikulas Patocka
 * This file is a part of the Links program, released under GPL.
 */

#ifndef CFG_H
#define CFG_H
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
#ifdef HAVE_CONFIG2_H
#include "config2.h"
#endif
#endif

/* Xbox Configuration! */

#ifndef __XBOX__
#define __XBOX__

#pragma code_seg( "LINKSBOX" )
#pragma data_seg( "LBOX_RW" )
#pragma bss_seg( "LBOX_RW" )
#pragma const_seg( "LBOX_RD" )

#define DEBUG_KEYBOARD
#define DEBUG_MOUSE

#include "../lpng125/png.h"

#include <xtl.h>
#include "xbox-wrapper.h"
#include "xbox-dns.h"

#define G

#define JS
#define CHCEME_FLEXI_LIBU
#define GLOBHIST

#define HAVE_JPEG
#define HAVE_PNG
#define PNG_THREAD_UNSAFE_OK
#define HAVE_STRFTIME

#define HAVE_SSL

#define VERSION		"0.91"

#endif


/* no one will probably ever port svgalib on atheos or beos or port atheos
   interface to beos, but anyway: make sure they don't clash */

#ifdef __BEOS__
#ifdef GRDRV_SVGALIB
#undef GRDRV_SVGALIB
#endif
#ifdef GRDRV_ATHEOS
#undef GRDRV_ATHEOS
#endif
#endif

#ifdef GRDRV_ATHEOS
#ifdef GRDRV_SVGALIB
#undef GRDRV_SVGALIB
#endif
#endif
