
@BOTTOM@

/* Define to 1 if NLS is requested.  */
#undef ENABLE_NLS

/* Define as 1 if you have catgets and don't want to use GNU gettext.  */
#undef HAVE_CATGETS

/* Define as 1 if you have gettext and don't want to use GNU gettext.  */
#undef HAVE_GETTEXT

/* Define if your locale.h file contains LC_MESSAGES.  */
#undef HAVE_LC_MESSAGES

/* Define to 1 if you have the stpcpy function.  */
#undef HAVE_STPCPY

/* */
#undef HAVE_TYPEOF

/* */
#undef HAVE_LONG_LONG

/* */
#undef HAVE_SIGSETJMP

/* */
#undef HAVE_CHMOD

/* */
#undef HAVE_ALARM

/* */
#undef HAVE_CFMAKERAW

/* */
#undef HAVE_HERROR

/* */
#undef HAVE_BEGINTHREAD

/* */
#undef HAVE_MOUOPEN

/* */
#undef HAVE_READ_KBD

/* */
#undef HAVE_CLONE

/* */
#undef HAVE_PTHREADS

/* */
#undef HAVE_LUA

/* */
#undef HAVE_SSL

/* */
#undef X2

/* */
#undef JS

/* */
#undef CHCEME_FLEXI_LIBU

/* */
#undef G

/* */
#undef GRDRV_SVGALIB

/* */
#undef GRDRV_FB

/* */
#undef GRDRV_DIRECTFB

/* */
#undef GRDRV_PMSHELL

/* */
#undef GRDRV_X

/* */
#undef GRDRV_ATHEOS

/* */
#undef DONT_INCLUDE_SETJMP

/* Tiff by Brain */
#undef HAVE_TIFF

/* Jpeg by Clock */
#undef HAVE_JPEG

/* */
#undef AC_BIG_ENDIAN

/* */
#undef AC_LITTLE_ENDIAN

/* FreeType support */
#undef HAVE_FREETYPE

/* Define to 1 if we should include global history */
#undef GLOBHIST

/* Define if you have the <bzlib.h> header file.  */
#undef HAVE_BZLIB_H

/* Define if you have the <zlib.h> header file.  */
#undef HAVE_ZLIB_H

/* Define if you have the bz2 library (-lbz2).  */
#undef HAVE_LIBBZ2

/* Define if you have the z library (-lz).  */
#undef HAVE_LIBZ

/* Form saving */
#undef FORM_SAVE

/* Backtrace support */
#undef BACKTRACE
