
~@;:-_%(.,<<[{)>:;.]}==+
+                       +
|  fuirippu@hotpop.com  |
+                       +
~@;:-_%(.,<<[{)>:;.]}==+


 So here's my second game. It was a college project on WinXP, DirectX9.
I finished early, got bored and decided to port it (1P only) to Xbox.

 You'll need the "media files" from the bin distribution (they go in
the same dir as the xbe, doh!)

  The port was very rough and ready (<4hrs). Hope you like it.

========================================================================
Shouts to Tenessee Shawn, Paul, Steve and Sanka.
  JagManJim - not forgotten. And MegaXavier who made it possible.
========================================================================
(~=20fps on Win, ~=120fps on X, huh?)
========================================================================

Media files:
	Arial16.xpr
	ComboA.bmp
	ComboA2.bmp
	fuelguage2.bmp
	gameover.bmp
	RaceTrack1.xpr
	Shadow.bmp
	Ship.x
	skyback.jpg
	skydown.jpg
	skyfront.jpg
	skyleft.jpg
	skyright.jpg
	skyup.jpg
	title2.bmp

Obvious optimizations:
  The game still has all the 2P stuff in it.
  Cut out skydown.jpg - you never see it.
  Change textures to xpr, change .x to .xbg.
  ("Never optimize, till you've profiled!")



========================================================================
    Xbox APPLICATION : FuelCrisis Project Overview
========================================================================

AppWizard has created this FuelCrisis application for you.  
This file contains a summary of what you will find in each of the files that
make up your FuelCrisis application.


FuelCrisis.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

FuelCrisis.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named FuelCrisis.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
