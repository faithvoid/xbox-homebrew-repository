//-----------------------------------------------------------------------------
// File: app.h		v1.04
//
// Desc: APPLICATION shit
//
// Copyright (c) Huirippu. All rights reserved.
//-----------------------------------------------------------------------------
#ifndef APPLIC_H
#define APPLIC_H


//#define		MAX_LEVEL		8		// This means there are 8 levels
//#define		MAX_TREASURE	20
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Name: Class CApp
// Desc: main application object
//-----------------------------------------------------------------------------
class CApp
{
public:
	CApp();
	~CApp();

	HRESULT		Init();

	void		ReadInput();
	void		FrameMove();
	void		Render();

private:
	LPDIRECT3D8			m_pD3D;
	LPDIRECT3DDEVICE8	m_pd3dDevice;

	CXBFont						m_Font;
	CTokei*						m_pTokei;



	CGameMgr	m_GameMgr;
};
//-----------------------------------------------------------------------------

#endif // APPLIC_H
