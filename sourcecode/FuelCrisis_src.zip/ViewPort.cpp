//#include <d3dx9.h>
//#include "DXUtil.h"

#include <xtl.h>


#include ".\viewport.h"

#include "DxObjects.h"

//-----------------------------------------------------------------------------

CViewPort::CViewPort(void)
{
	// Constant parameters
	m_vp.X    = 0;
	m_vp.MaxZ = 1.0f;
	m_vp.MinZ = 0.0f;

	// Parameters set by 
	m_vp.Y      = 0;
	m_vp.Height = 0;
	m_vp.Width  = 0;
}

//-----------------------------------------------------------------------------

CViewPort::~CViewPort(void)
{
}

//-----------------------------------------------------------------------------

void CViewPort::SetViewPort(DWORD y, DWORD height, DWORD width)
{
	m_vp.Y      = y;
	m_vp.Height = height;
	m_vp.Width  = width;
}

//-----------------------------------------------------------------------------

void CViewPort::Activate() const
{
	LPDIRECT3DDEVICE8 pDevice = CDxObjects::GetDevice();
	pDevice->SetViewport(&m_vp);
}