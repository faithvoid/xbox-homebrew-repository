#pragma once


//#define RNDR_NRMLS


class CLandScape
{
public:
	CLandScape(void);
	~CLandScape(void);

	HRESULT	InitDeviceObjects(const CHeightMap &HeightMap);
	void	DeleteDeviceObjects();
	HRESULT RestoreDeviceObjects();

	void	Render() const;

private:
	struct CUSTOMVERTEX
	{
		D3DXVECTOR3 position;
		D3DXVECTOR3	normal;
		float		tu, tv;
		//DWORD		diffuse;
	};
	LPDIRECT3DVERTEXBUFFER8		m_pVB;

#ifdef RNDR_NRMLS
	struct LINELIST
	{
		D3DXVECTOR3 position;
	};
	LPDIRECT3DVERTEXBUFFER8		m_pVBLine;
#endif

	DWORD						m_dwFVF;
	LPDIRECT3DINDEXBUFFER8		m_pIndexBuf;
	CXBPackedResource			m_xbprTexture;
	LPDIRECT3DTEXTURE8			m_pTexture;
	D3DMATERIAL8				m_mtrl;

	bool m_bRender;

	HRESULT CreateVertexBuffer(const CHeightMap &HeightMap);
	int		m_nNumVerts;

	HRESULT CreateIndexBuffer(const CHeightMap &HeightMap);
	int		m_nNumPrims;
};
