#pragma once

class CHeightMap;

class CUniqGeom
{
public:
	CUniqGeom(void);
	~CUniqGeom(void);

	HRESULT InitDeviceObjects();
	void	DeleteDeviceObjects();
	HRESULT	RestoreDeviceObjects();
	void	InvalidateDeviceObjects();

	void	FrameMove(const CShip &Ship, const CHeightMap &HeightMap);
	void	Render(bool bGameOver) const;

private:
	CShadow		m_Shadow;
	CAltimeter	m_Altimeter;
	CFuelGuage	m_FuelGuage;

	CGameOver	m_GameOver;
};
