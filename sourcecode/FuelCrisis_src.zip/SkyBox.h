#pragma once

#define NUM_SKY_TEXTURES	6

class CSkyBox
{
public:
	CSkyBox(void);
	~CSkyBox(void);

	HRESULT	InitDeviceObjects();
	void	DeleteDeviceObjects();

	void	Render() const;

private:
	LPDIRECT3DVERTEXBUFFER8		m_pVB;
	LPDIRECT3DTEXTURE8			m_apTextures[NUM_SKY_TEXTURES];
	struct CUSTOMVERTEX {
		D3DXVECTOR3 position;
		float		tu, tv;
	};
	DWORD			m_dwFVF;
	enum { NUM_VERTS = 36 };
	D3DXMATRIX		m_matWorld;

	bool			m_bRender;

	CCloudBox		m_CloudBox;

	HRESULT CreateVertexBuffer();
};
