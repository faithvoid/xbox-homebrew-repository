#pragma once

class CPhilBuf
{
private:
	CPhilBuf(void);
	~CPhilBuf(void);

	static char m_strBuf[1024];

public:
	static void SetText(char* pBuf);
	static void AppendText(char* pBuf);
	static char* GetText();
};
