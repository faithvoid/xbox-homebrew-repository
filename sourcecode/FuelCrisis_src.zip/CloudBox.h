#pragma once

class CCloudBox
{
public:
	CCloudBox(void);
	~CCloudBox(void);

	HRESULT	InitDeviceObjects();
	void	DeleteDeviceObjects();

	void	Render() const;

private:
	LPDIRECT3DVERTEXBUFFER8		m_pVB;
	struct CUSTOMVERTEX {
		D3DXVECTOR3 position;       // vertex position
		DWORD		diffuse;
	};
	DWORD		m_dwFVF;
	enum { NUM_PRIMS = 16, NUM_VERTS = 48 };

	bool		m_bRender;

	HRESULT CreateVertexBuffer();
};
