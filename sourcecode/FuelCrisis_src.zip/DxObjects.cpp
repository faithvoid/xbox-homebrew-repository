//#include <d3d9.h>
#include <xtl.h>

#include ".\DxObjects.h"

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

LPDIRECT3DDEVICE8	CDxObjects::m_pd3dDevice = NULL;
//D3DSURFACE_DESC*	CDxObjects::m_pd3dsdBackBuffer = NULL;

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

CDxObjects::CDxObjects(void)
{
}

//-----------------------------------------------------------------------------

CDxObjects::~CDxObjects(void)
{
}

//-----------------------------------------------------------------------------

void CDxObjects::SetDevice(LPDIRECT3DDEVICE8 pDevice)
{
	m_pd3dDevice = pDevice;
}

//-----------------------------------------------------------------------------

LPDIRECT3DDEVICE8 CDxObjects::GetDevice()
{
	return(m_pd3dDevice);
}

//-----------------------------------------------------------------------------
/*
void CDxObjects::SetBackBufferSurfaceDescriptor(D3DSURFACE_DESC* pSurface)
{
	m_pd3dsdBackBuffer = pSurface;
}

//-----------------------------------------------------------------------------

D3DSURFACE_DESC* CDxObjects::GetBackBufferSurfaceDescriptor()
{
	return(m_pd3dsdBackBuffer);
}
*/