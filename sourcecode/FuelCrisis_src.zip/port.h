/*
 * PORT.H
 */

#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }
