//-----------------------------------------------------------------------------
// File: tokei.h		v1.01
//
// Desc: TIMING shit
//
// Copyright (c) Huirippu. All rights reserved.
//-----------------------------------------------------------------------------
#ifndef TOKEI_H
#define TOKEI_H

//-----------------------------------------------------------------------------
// Name: Class CTokei
// Desc: 
//-----------------------------------------------------------------------------
class CTokei
{
public:
	CTokei();
	~CTokei();

	void Initialize();
	void Update();

	FLOAT	GetAppSecs() {return(m_fAppTime);}

	WCHAR      m_strFrameRate[20];  // Frame rate written to a string

	FLOAT      m_fElapsedTime;      // Elapsed absolute time since last frame
private:
	FLOAT      m_fTime;             // Current absolute time in seconds
	FLOAT      m_fAppTime;          // Current app time in seconds
	FLOAT      m_fElapsedAppTime;   // Elapsed app time since last frame
	BOOL       m_bPaused;           // Whether app time is paused by user
	FLOAT      m_fFPS;              // instantaneous frame rate

	//HANDLE     m_hFrameCounter;     // Handle to frame rate perf counter
};
//-----------------------------------------------------------------------------

#endif // TOKEI_H
