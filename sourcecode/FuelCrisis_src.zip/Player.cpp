//#include <d3dx9.h>
//#define DIRECTINPUT_VERSION 0x0800
//#include <dinput.h>
//#include "DXUtil.h"
#include <xtl.h>

//#include "Input.h"
#include "Ship.h"

#include ".\player.h"

//-----------------------------------------------------------------------------

CPlayer::CPlayer(void)
{
//	m_nKeyLeft		= DIK_LEFT;
//	m_nKeyRight		= DIK_RIGHT;
//	m_nKeyThrust	= DIK_UP;
}

//-----------------------------------------------------------------------------

CPlayer::~CPlayer(void)
{
}

//-----------------------------------------------------------------------------

void CPlayer::SetKeyLeft(int nKey)
{
	m_nKeyLeft = nKey;
}

//-----------------------------------------------------------------------------

void CPlayer::SetKeyRight(int nKey)
{
	m_nKeyRight = nKey;
}

//-----------------------------------------------------------------------------

void CPlayer::SetKeyThrust(int nKey)
{
	m_nKeyThrust = nKey;
}

//-----------------------------------------------------------------------------

void CPlayer::ProcessInput(const CInput &input, CShip &ship) const
{
	//if(input.KeyPressed(m_nKeyLeft))
	//	ship.TurnLeft();
	//else if(input.KeyPressed(m_nKeyRight))
	//	ship.TurnRight();

	//if(input.KeyPressed(m_nKeyThrust))
	//	ship.Thrust();
}

//-----------------------------------------------------------------------------
