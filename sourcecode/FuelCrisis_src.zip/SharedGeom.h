#pragma once

class CHeightMap;
class CShip;
class CPickUp;


class CSharedGeom
{
public:
	CSharedGeom(void);
	~CSharedGeom(void);

	HRESULT	InitDeviceObjects(const CHeightMap &HeightMap);
	void	DeleteDeviceObjects();
	HRESULT	RestoreDeviceObjects();

	void	RenderSkyBox() const;
	void	RenderScene(int				nPlayer,
						const CShip		&Ship1,
						const CShip		*Ship2,
						const CPickUp	&PickUp) const;

private:
	CLandScape	m_LandScape;
	CSkyBox		m_SkyBox;
	CShipModel	m_ShipModel;

	CFuelTank	m_FuelTank;
};
