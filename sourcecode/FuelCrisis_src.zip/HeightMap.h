#pragma once

class CHeightMap
{
public:
	CHeightMap(void);
	~CHeightMap(void);

	HRESULT Initialise();
	float GetData(float fZ, float fX) const;
	float GetData(int nZ, int nX) const;

	int	GetSizeZ() const;
	int	GetSizeX() const;

private:
	float SplineInterpolation(	float SplineInterpolationValue	,
								float Height0, float Height1	,
								float Height2, float Height3	) const;

	int			m_nSizeZ;
	int			m_nSizeX;
	float*		m_pData;
};
