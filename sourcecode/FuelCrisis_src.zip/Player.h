#pragma once

class CInput;
class CShip;

class CPlayer
{
public:
	CPlayer(void);
	~CPlayer(void);

	void SetKeyLeft(int nKey);
	void SetKeyRight(int nKey);
	void SetKeyThrust(int nKey);

	void ProcessInput(const CInput &input, CShip &ship) const;

private:
	int		m_nKeyLeft;
	int		m_nKeyRight;
	int		m_nKeyThrust;
};
