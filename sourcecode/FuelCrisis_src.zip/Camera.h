#pragma once

class CCamera
{
public:
	CCamera(void);
	~CCamera(void);

	void FrameMove(const D3DXVECTOR3 &vecTarget, float fBearing);

	void SetViewNoTranslate() const;
	void SetView() const;

private:
	float	m_fCameraDistance;
	float	m_fCameraAltitude;

	D3DXMATRIX	m_matView;
	D3DXMATRIX	m_matViewNoTranslate;

};
