#pragma once

class CShipModel
{
public:
	CShipModel();
	~CShipModel(void);

	HRESULT	InitDeviceObjects();
	void	DeleteDeviceObjects();

	void	Render(int nPlayer, const D3DXMATRIX &mat) const;
	void	Render9(int nPlayer, const D3DXMATRIX &mat) const;

private:
	LPD3DXMESH			m_pMesh;
	LPDIRECT3DTEXTURE8*	m_pTextures;
	D3DXMATRIX			m_matXform;

	bool				m_bRender;
};
