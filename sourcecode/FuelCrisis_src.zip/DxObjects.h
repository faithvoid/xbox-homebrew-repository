#pragma once

class CDxObjects
{
private:
	CDxObjects(void);
	~CDxObjects(void);

	static LPDIRECT3DDEVICE8	m_pd3dDevice;
//	static D3DSURFACE_DESC*		m_pd3dsdBackBuffer;

public:
	static void SetDevice(LPDIRECT3DDEVICE8 pDevice);
	static LPDIRECT3DDEVICE8 GetDevice();

//	static void SetBackBufferSurfaceDescriptor(D3DSURFACE_DESC* pSurface);
//	static D3DSURFACE_DESC *GetBackBufferSurfaceDescriptor();
};
