#pragma once

class CViewPort
{
public:
	CViewPort(void);
	~CViewPort(void);

	void SetViewPort(DWORD y, DWORD height, DWORD width);
	void Activate() const;

private:
	D3DVIEWPORT8 m_vp;
};
