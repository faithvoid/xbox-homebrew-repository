/*
    Hero's Of Roswell
    Copyright (C) 2003 Patrick Avella

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
extern SDL_Joystick *GAMEPAD;
extern Sint16 joyx, joyy; //axes
extern Sint16 blackbutton;
extern Sint16 abutton; //A button
extern Sint16 bbutton;
extern Sint16 xbutton;
extern Sint16 ybutton;
extern Sint16 backbutton; //BACK button
extern Sint16 startbutton; //START button
extern Sint16 rstick; 
extern Sint16 dpad; //dpad
extern Sint16 ltrigger, rtrigger; //Trigger buttons

void cutscene(SDL_Surface *app, int lvl) {
    bool running= true;
    int count=0;
    Uint32 started= SDL_GetTicks();
    Uint32 okaytogo= started+1000;

    SDL_Surface *curscreen;

    pc.dir= NOMOVEMENT;
    pc.x= 368; pc.y=500;

    if(lvl==0) {
        Mix_PlayMusic(audio.story, -1);        
        curscreen= SDL_LoadBMP("d:\\story\\00.bmp");
        }
    if(lvl==1) {
        Mix_PlayMusic(audio.story2, -1);        
        curscreen= SDL_LoadBMP("d:\\story\\10.bmp");
        }        
    if(lvl==2) {
        Mix_PlayMusic(audio.story, -1);        
        curscreen= SDL_LoadBMP("d:\\story\\20.bmp");
        }        
    if(lvl==3) {
        Mix_PlayMusic(audio.story, -1);        
        curscreen= SDL_LoadBMP("d:\\story\\30.bmp");
        }        
    if(lvl==4) {
        Mix_PlayMusic(audio.victorymid, -1);        
        curscreen= SDL_LoadBMP("d:\\story\\40.bmp");
        }        
  
    while (running) {
         SDL_Event event;
		SDL_PumpEvents();
		SDL_JoystickUpdate(); //manual refresh of the gamepad(s)
	//parse all gamepads
	joyx = SDL_JoystickGetAxis(GAMEPAD, 0);
	joyy = SDL_JoystickGetAxis(GAMEPAD, 1);
	dpad = SDL_JoystickGetHat(GAMEPAD, 0);
	blackbutton = SDL_JoystickGetButton(GAMEPAD, 4); //Black Button
	abutton = SDL_JoystickGetButton(GAMEPAD, 0); //Get A-Button(0)
	bbutton = SDL_JoystickGetButton(GAMEPAD, 1);
	backbutton = SDL_JoystickGetButton(GAMEPAD, 9); //Get BACK-Button(9)
	rstick = SDL_JoystickGetButton(GAMEPAD,11);
	ltrigger = SDL_JoystickGetButton(GAMEPAD,6);
	rtrigger = SDL_JoystickGetButton(GAMEPAD,7);
	xbutton = SDL_JoystickGetButton(GAMEPAD,2);
	ybutton = SDL_JoystickGetButton(GAMEPAD,3);
	startbutton = SDL_JoystickGetButton(GAMEPAD,8);

	event.type = SDL_KEYUP;

	if(abutton||bbutton||startbutton){
		event.type = SDL_KEYDOWN;
	}

	if(blackbutton){
		event.type = SDL_QUIT;
	}

	SDL_Delay(250);





		 //while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) { XLaunchNewImage(NULL, (LAUNCH_DATA*)&LaunchData ); }
            if ( (event.type == SDL_KEYDOWN) && (SDL_GetTicks() > okaytogo) ) {
                if(lvl==0 && count==0) curscreen= SDL_LoadBMP("d:\\story\\01.bmp");
                if(lvl==0 && count==1) curscreen= SDL_LoadBMP("d:\\story\\02.bmp");
                if(lvl==0 && count==1) Mix_PlayMusic(audio.story2, -1);
              //  if(lvl==0 && count==1) Mix_PlayChannel(-1, audio.exp64, 0);
                if(lvl==0 && count==2) curscreen= SDL_LoadBMP("d:\\story\\03.bmp");
                if(lvl==0 && count==2) Mix_HaltMusic();
                if(lvl==0 && count==3) running=false;
                if(lvl==0 && count==3) lastlevelplayed=1;
                if(lvl==1 && count==0) curscreen= SDL_LoadBMP("d:\\story\\11.bmp");
                if(lvl==1 && count==0) Mix_HaltMusic();
                if(lvl==1 && count==1) running=false;
                if(lvl==1 && count==1) lastlevelplayed=2;
                if(lvl==2 && count==0) curscreen= SDL_LoadBMP("d:\\story\\21.bmp");
                if(lvl==2 && count==0) Mix_HaltMusic();
                if(lvl==2 && count==1) running=false;
                if(lvl==2 && count==1) lastlevelplayed=3;
                if(lvl==3 && count==0) curscreen= SDL_LoadBMP("d:\\story\\31.bmp");
                if(lvl==3 && count==0) Mix_HaltMusic();
                if(lvl==3 && count==1) running=false;
                if(lvl==3 && count==1) lastlevelplayed=4;
                if(lvl==4 && count==0) Mix_HaltMusic();
                if(lvl==4 && count==0) running=false;
                if(lvl==4 && count==0) lastlevelplayed=1;
                if(lvl==4 && count==0) cheatson=true;
                count++;
                okaytogo= SDL_GetTicks()+1000;
                }
            //}       

         SDL_BlitSurface(curscreen,NULL,app,NULL);

         SDL_Flip(app);
         }

       SDL_FreeSurface(curscreen);
       pc.lastdrawn= SDL_GetTicks();
       return;
       }  
       
void pausegame(SDL_Surface *app) {
    bool running= true;
    SDL_Surface *curscreen;


    SDL_Surface *buf= SDL_LoadBMP("d:\\bmp\\paused.bmp");
    curscreen= SDL_DisplayFormatAlpha(buf);
    SDL_SetColorKey(curscreen, SDL_SRCCOLORKEY, SDL_MapRGB(
        curscreen->format, 214, 123, 124) );
    SDL_FreeSurface(buf);

   
    while (running) {
         SDL_Event event;

		SDL_PumpEvents();
		SDL_JoystickUpdate(); //manual refresh of the gamepad(s)
	//parse all gamepads
	joyx = SDL_JoystickGetAxis(GAMEPAD, 0);
	joyy = SDL_JoystickGetAxis(GAMEPAD, 1);
	dpad = SDL_JoystickGetHat(GAMEPAD, 0);
	blackbutton = SDL_JoystickGetButton(GAMEPAD, 4); //Black Button
	abutton = SDL_JoystickGetButton(GAMEPAD, 0); //Get A-Button(0)
	bbutton = SDL_JoystickGetButton(GAMEPAD, 1);
	backbutton = SDL_JoystickGetButton(GAMEPAD, 9); //Get BACK-Button(9)
	rstick = SDL_JoystickGetButton(GAMEPAD,11);
	ltrigger = SDL_JoystickGetButton(GAMEPAD,6);
	rtrigger = SDL_JoystickGetButton(GAMEPAD,7);
	xbutton = SDL_JoystickGetButton(GAMEPAD,2);
	ybutton = SDL_JoystickGetButton(GAMEPAD,3);
	startbutton = SDL_JoystickGetButton(GAMEPAD,8);

	if(startbutton){
		event.type = SDL_KEYDOWN;
		event.key.keysym.sym = SDLK_LSHIFT;
	}

		 //while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) { XLaunchNewImage(NULL, (LAUNCH_DATA*)&LaunchData ); }
            if ( (event.type == SDL_KEYDOWN) && (event.key.keysym.sym == SDLK_LSHIFT) ) {
                running= false;
                }
            //}       

  
         SDL_BlitSurface(curscreen,NULL,app,NULL);

         SDL_Flip(app);
         }

       SDL_FreeSurface(curscreen);
       pc.lastdrawn= SDL_GetTicks();
       return;
       }                 
                       
                               
                                       
                                               
                                                               
