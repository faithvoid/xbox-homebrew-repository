/*
    Hero's Of Roswell
    Copyright (C) 2003 Patrick Avella

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
void initpc (pcstruct *pc) {
    pc->x=300; pc->y=500; pc->oldx=300; pc->oldy=500; pc->curframe=0; pc->dir=0;
    pc->movedelay= 16; pc->lastmove= 0; pc->speed=10; pc->accel=10; pc->lastdrawn=SDL_GetTicks();
    pc->hp= 5; pc->lives= 3; pc->weapon= LVL1BULLET;
    pc->h=64; pc->w=64;; pc->deathcount=0; pc->shieldsarelow= false;
    pc->animdelay= 170; pc->maxspeed=22; pc->iaccel=0;
    pc->score=0; pc->killcount=0;
    }


void movepc (pcstruct *pc) {
    int dir= pc->dir;
    if(pc->hp == 0) {
        pc->deathcount++;
        if ((pc->deathcount==60) && (pc->lives==0)){
                Mix_PlayMusic(audio.gameover, -1);
                dropclip(gameover,clips,UP, 144, 600);
                }
        if ((pc->deathcount==530) && (pc->lives==0)) main(0,NULL);
        if ((pc->deathcount==150) && (pc->lives > 0)) {
                pc->hp=5;
                pc->x=332; pc->y=500;
                pc->deathcount=0;
                Mix_PlayChannel(-1, audio.hpup, 0);
                }
        }
        
        if (pc->hp != 0) {
        for (int i=0; i < 32; i++) {
            if ((bullets[i].x > pc->x - bullets[i].w) 
              && (bullets[i].x < pc->x + pc->w) 
              && (bullets[i].y > pc->y - bullets[i].h) 
              && (bullets[i].y < pc->y + pc->h)
              && bullets[i].ai != NOMOVEMENT ) {
              Uint8 r,g,b,r2,g2,b2;
              r=0;g=0;b=0;r2=0;g2=0;b2=0;
              int x1a,x2a;
              x1a= bullets[i].x - pc->x;
              x2a= (bullets[i].x+bullets[i].w)-pc->x;
              if ( (x1a > -1) || (x2a > -1) ) {
              Uint32 pix1= getpixel(cast.pclevel[0], x1a, (bullets[i].y+(bullets[i].h/2))-pc->y);
              Uint32 pix2= getpixel(cast.pclevel[0], x2a, (bullets[i].y+(bullets[i].h/2))-pc->y);
              SDL_GetRGB(pix1,cast.pclevel[0]->format, &r,&g,&b);
              SDL_GetRGB(pix2,cast.pclevel[0]->format, &r2,&g2,&b2);
              }
              if( !(((r==0)&&(g==0)&&(b==0)) || ((r2==0)&&(g2==0)&&(b2==0))) ) {

              if(bullets[i].sprite == NME1BULLET) {
                 pc->hp-=1;
                 dropclip(explosion16,clips,NOMOVEMENT,bullets[i].x,bullets[i].y);
                 bullets[i].ai= NOMOVEMENT;
                 Mix_PlayChannel(-1, audio.exp16, 0);
                 }
              if(bullets[i].sprite == NME2BULLET) {
                 pc->hp-=2;
                 dropclip(explosion16,clips,NOMOVEMENT,bullets[i].x,bullets[i].y);
                 bullets[i].ai= NOMOVEMENT;
                 Mix_PlayChannel(-1, audio.exp16, 0);
                 }
               }
              }
        }

        if (pc->hp == 1) {
           if (!pc->shieldsarelow) {
              Mix_PlayChannel(-1, audio.shieldsarelow, 0);
              dropclip(shieldsarelow,clips,NOMOVEMENT,144,236);
              Mix_PlayChannel(-1, audio.shieldsarelow, 0);
              pc->shieldsarelow= true;
              }        
           }

        if (pc->hp != 1) pc->shieldsarelow= false;
           
        if (pc->hp < 1) {
           Mix_PlayChannel(-1, audio.exp64, 0);     
           pc->hp= 0;
           dropclip(explosion64,clips,DOWN,pc->x,pc->y);
           dropclip(explosion64,clips,DOWNLEFT,pc->x,pc->y);
           dropclip(explosion64,clips,DOWNRIGHT,pc->x,pc->y);
           dropclip(explosion64,clips,LEFT,pc->x,pc->y);
           dropclip(explosion64,clips,UP,pc->x,pc->y);
           dropclip(explosion64,clips,UPLEFT,pc->x,pc->y);           
           dropclip(explosion64,clips,UPRIGHT,pc->x,pc->y);
           dropclip(explosion64,clips,RIGHT,pc->x,pc->y);
           pc->lives--;
           pc->y= 1000; pc->x= 2000;
           bg.speed=8;
           pc->weapon= LVL1BULLET;
           pc->animdelay=170;
           pc->speed= 10;
           if (pc->lives == 0) Mix_HaltMusic();
           if (pc->lives == 0) showbosshp=false;
           return;
           }        
                
        if (dir == UP   ) pc->y-=pc->speed;
        if (dir == DOWN ) pc->y+=pc->speed;
        if (dir == LEFT ) pc->x-=pc->speed;
        if (dir == RIGHT) pc->x+=pc->speed;
        if (dir == UPLEFT   ) { pc->y-=pc->speed; pc->x-=pc->speed; }
        if (dir == UPRIGHT  ) { pc->y-=pc->speed; pc->x+=pc->speed; }
        if (dir == DOWNLEFT ) { pc->y+=pc->speed; pc->x-=pc->speed; }
        if (dir == DOWNRIGHT) { pc->y+=pc->speed; pc->x+=pc->speed; }
//        if ((pc->speed < pc->maxspeed) && (pc->iaccel == pc->accel)) {
//            pc->speed+=1;
//            }
        if (pc->y > 536) pc->y= 536;
        if (pc->x > 736) pc->x= 736;
        if (pc->y < 0 ) pc->y= 0;
        if (pc->x < 0 ) pc->x= 0;
//        cout << "\nThe current time is: " << curtime;
//        pc->lastmove= curtime;
//        cout << "\n The last time was: " << pc->lastmove;
//        }
        }
    }


void drawpc (pcstruct *pc, SDL_Surface *screen) {
if (pc->hp != 0) {
    SDL_Rect dest;
    dest.x = pc->x; dest.y = pc->y;
    dest.w = 64;    dest.h = 64;

        if ((pc->dir == LEFT) || (pc->dir == UPLEFT) || (pc->dir == DOWNLEFT)) {
            SDL_BlitSurface(cast.pcbankleft[pc->curframe], NULL, screen, &dest);
            }
        if ((pc->dir == RIGHT) || (pc->dir == UPRIGHT) || (pc->dir == DOWNRIGHT)) {
            SDL_BlitSurface(cast.pcbankright[pc->curframe], NULL, screen, &dest);
            }
        if ((pc->dir == UP) || (pc->dir == DOWN) || (pc->dir == NOMOVEMENT)) {
            SDL_BlitSurface(cast.pclevel[pc->curframe], NULL, screen, &dest);
            }

    if( SDL_GetTicks() - pc->lastdrawn > pc->animdelay ) {
        pc->curframe++;
        pc->lastdrawn= SDL_GetTicks()-((SDL_GetTicks() - pc->lastdrawn)-pc->animdelay);
        }
    if( pc->curframe == 3 ) pc->curframe=0;
    }
}
    
void pcshoot (pcstruct *pc, bullet *bullets) {
if (pc->hp != 0) {
    SDL_Rect dest;
    dest.x = pc->x; dest.y = pc->y;
    dest.w = 64;    dest.h = 64;
    if (pc->weapon == LVL1BULLET) {
        dest.h= 16;  dest.w= 16;
        dest.x+=24; dest.y-=dest.h;
        shoot(level1bullet, bullets, UP, dest.x, dest.y);
        Mix_PlayChannel(1, audio.smlaser, 0);
       }
    if (pc->weapon == LVL2BULLET) {
        dest.h= 16;  dest.w= 16;
        dest.x+=24; dest.y-=dest.h;
        shoot(level2bullet, bullets, UP, dest.x, dest.y);
        Mix_PlayChannel(-1, audio.smlaser, 0);
       }
    if (pc->weapon == LVL3BULLET) {
        dest.h= 16;  dest.w= 16;
        dest.x+=24; dest.y-=dest.h;
        shoot(level3bullet, bullets, UP, dest.x, dest.y);
        Mix_PlayChannel(-1, audio.largebullet, 0);
       }
    if (pc->weapon == LVL4BULLET) {
        dest.h= 16;  dest.w= 16;
        dest.x+=24; dest.y-=dest.h;
        shoot(level4bullet, bullets, UP, dest.x, dest.y);
        Mix_PlayChannel(-1, audio.rocket, 0);
       }
    if (pc->weapon == LVL5BULLET) {
        dest.h= 16;  dest.w= 16;
        dest.x+=24; dest.y-=dest.h;
        shoot(level1bullet, bullets, UP, dest.x-8, dest.y);
        shoot(level4bullet, bullets, UP, dest.x, dest.y);
        shoot(level1bullet, bullets, UP, dest.x+8, dest.y);
        Mix_PlayChannel(-1, audio.rocket, 0);
       }       
    }
}    
    

    
