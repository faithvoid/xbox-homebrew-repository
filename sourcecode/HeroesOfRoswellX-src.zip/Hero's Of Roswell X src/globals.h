/*
    Hero's Of Roswell
    Copyright (C) 2003 Patrick Avella

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
SDL_Surface *app;

//background



//levels
Uint32 stageCount;
bool level1ison;
bool level1bossison;
bool level2ison;
bool level2bossison;
bool level3ison;
bool level3bossison;
bool level4ison;
bool level4bossison;
int lastlevelplayed;
bool continuelevel;
bool cheatson;


bool showbosshp;
int thebosshp;

//mypc

struct pcstruct {
    int x, y, oldx, oldy, curframe, dir, accel, h, w, hp, lives, weapon, maxspeed;
    int movedelay, breakdelay, offset, speed, animdelay, iaccel, deathcount; 
    int score, killcount;
    bool shieldsarelow;
    Uint32 lastmove, lastdrawn;
    };   
    
pcstruct pc;

//nmesprite

//runonce

//shoot

//titlescreen
