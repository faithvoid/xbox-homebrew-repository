/*
    Hero's Of Roswell
    Copyright (C) 2003 Patrick Avella

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
struct bullet {
    int x, y, h, w, type, frames, curframe;
    int movedelay, speed, animdelay, ai, sprite;
    Uint32 lastmove, lastdrawn;
    };
    
void initbullet (bullet *blt, int w, int h, int x, int y, int frames, int ai, int spd,
              int sprite, int ad) {

    blt->x=x; blt->y=y; blt->curframe=0;
    blt->movedelay= 16; blt->lastmove= 0; blt->speed=spd; blt->lastdrawn=0;
    blt->ai= ai;
    blt->h=h; blt->w=w; blt->frames=frames;
    blt->animdelay= ad; blt->sprite=sprite;
    }
    
void movebullets (bullet *blt) {
    for (int j=0; j < 32; j++) {
        if ( blt[j].ai != NOMOVEMENT ) {
                if (blt[j].ai == UP) {
                     blt[j].y-=blt[j].speed;
                     }
                if (blt[j].ai == DOWN) {
                     blt[j].y+=blt[j].speed;
                     }
                if (blt[j].ai == RIGHT) {
                     blt[j].x+=blt[j].speed;
                     }
                if (blt[j].ai == LEFT) {
                     blt[j].x-=blt[j].speed;
                     }
                if (blt[j].ai == DOWNLEFT) {
                     blt[j].x-=blt[j].speed;
                     blt[j].y+=blt[j].speed;
                     }          
                if (blt[j].ai == DOWNRIGHT) {
                     blt[j].x+=blt[j].speed;
                     blt[j].y+=blt[j].speed;
                     }                                                                         
                if (blt[j].y > 650) blt[j].ai= NOMOVEMENT;
                if (blt[j].x > 850) blt[j].ai= NOMOVEMENT;
                if (blt[j].y < -50-blt[j].h) blt[j].ai= NOMOVEMENT;
                if (blt[j].x < -50-blt[j].w) blt[j].ai= NOMOVEMENT;
                }
            
        }
    }    
    
void drawbullets (bullet *cur, SDL_Surface *app) {
    for (int j=0; j < 32; j++) {
        if ( cur[j].ai != NOMOVEMENT ) {
            SDL_Rect dest;
            dest.x= cur[j].x; dest.y= cur[j].y;
            dest.w= cur[j].w; dest.h= cur[j].h;
            SDL_Rect src;
            src.x= 0; src.y= 0;
            src.w= cur[j].w; src.h= cur[j].h;

            if (cur[j].sprite == LVL1BULLET) {
                SDL_BlitSurface(cast.lvl1bullet[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == LVL2BULLET) {
                SDL_BlitSurface(cast.lvl2bullet[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == LVL3BULLET) {
                SDL_BlitSurface(cast.lvl3bullet[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == LVL4BULLET) {
                SDL_BlitSurface(cast.lvl4bullet[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == NME1BULLET) {
                SDL_BlitSurface(cast.nme1bullet[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == NME2BULLET) {
                SDL_BlitSurface(cast.lvl3bullet[cur[j].curframe], &src, app, &dest);
                }

            if( SDL_GetTicks() - cur[j].lastdrawn > cur[j].animdelay) {
                cur[j].curframe++;
                cur[j].lastdrawn= SDL_GetTicks();
                }
            if( cur[j].curframe == cur[j].frames ) cur[j].curframe=0;
            }
        }
    }
    
void shoot (bullet sprite, bullet *cur, int ai, int sx, int sy) {
    for (int j= 0; j < 32; j++) {
        if ( cur[j].ai == NOMOVEMENT ) {
            cur[j]= sprite;
            cur[j].y= sy; cur[j].x= sx;
            cur[j].ai= ai;
            return;
            }
        }
    }


bullet bullets[32];
bullet level1bullet;
bullet level2bullet;
bullet level3bullet;
bullet level4bullet;
bullet level5bullet;
bullet nme1bullet;
bullet nme2bullet;


