/*
    Hero's Of Roswell
    Copyright (C) 2003 Patrick Avella

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
struct runonce {
    int x, y, curframe, h, w, frames, dir;
    int speed, animdelay, sprite, loop, toloop;
    Uint32 lastmove, lastdrawn;
    };
    
void initRunOnce (runonce *run, int h, int w, int frames,
    int speed, int animdelay, int sprite) {
    run->x=0; run->y=0; run->curframe=0; run->h= h; run->w= w;
    run->frames= frames; run->dir= NOMOVEMENT; run->speed=speed;
    run->animdelay= animdelay; run->sprite= sprite;
    run->lastmove=0; run->lastdrawn=0;
    }

void initRunOnce (runonce *run, int h, int w, int frames,
    int speed, int animdelay, int sprite, int toloop) {
    run->x=0; run->y=0; run->curframe=0; run->h= h; run->w= w;
    run->frames= frames; run->dir= NOMOVEMENT; run->speed=speed;
    run->animdelay= animdelay; run->sprite= sprite;
    run->toloop= toloop; run->loop=0;
    run->lastmove=0; run->lastdrawn=0;
    }
    
void moveclips (runonce *run) {
    for (int j=0; j < 32; j++) {
        if ( run[j].sprite != NOSPRITE ) {
                if (run[j].dir == DOWN) {
                     run[j].y+=run[j].speed;
                     }
                if (run[j].dir == UP) {
                     run[j].y-=run[j].speed;
                     }                     
                if (run[j].dir == LEFT) {
                     run[j].x-=run[j].speed;
                     }        
                if (run[j].dir == RIGHT) {
                     run[j].x+=run[j].speed;
                     }
                if (run[j].dir == UPRIGHT) {
                     run[j].x+=run[j].speed;
                     run[j].y-=run[j].speed;
                     }
                if (run[j].dir == DOWNRIGHT) {
                     run[j].x+=run[j].speed;
                     run[j].y+=run[j].speed;
                     }
                if (run[j].dir == DOWNLEFT) {
                     run[j].x-=run[j].speed;
                     run[j].y+=run[j].speed;
                     }        
                if (run[j].dir == UPLEFT) {
                     run[j].x-=run[j].speed;
                     run[j].y-=run[j].speed;
                     }                             

                if (run[j].sprite == ABSORB) {
                     run[j].x=pc.x; run[j].y=pc.y;
                     }                                                       
                if (run[j].y > 800) run[j].sprite= NOSPRITE;
                if (run[j].x > 1000) run[j].sprite= NOSPRITE;
                if (run[j].y < -200-run[j].h) run[j].sprite= NOSPRITE;
                if (run[j].x < -200-run[j].w) run[j].sprite= NOSPRITE;
                }
            
        }
    }


void drawclips (runonce *cur, SDL_Surface *app) {
    for (int j=0; j < 32; j++) {
        if ( cur[j].sprite != NOSPRITE ) {
            SDL_Rect dest;
            dest.x= cur[j].x; dest.y= cur[j].y;
            dest.w= cur[j].w; dest.h= cur[j].h;
            SDL_Rect src;
            src.x= 0; src.y= 0;
            src.w= cur[j].w; src.h= cur[j].h;

            if (cur[j].sprite == EXPLODE16) {
                SDL_BlitSurface(cast.explosion16[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == EXPLODE64) {
                SDL_BlitSurface(cast.explosion64[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == SHIELDSLOW) {
                SDL_BlitSurface(cast.shieldslow[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == GAMEOVER) {
                SDL_BlitSurface(cast.gameover[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == SPEEDUP) {
                SDL_BlitSurface(cast.speedup[cur[j].curframe], &src, app, &dest);
                }                
            if (cur[j].sprite == ABSORB) {
                SDL_BlitSurface(cast.absorb[cur[j].curframe], &src, app, &dest);
                }          
            if (cur[j].sprite == CLOUD) {
                SDL_BlitSurface(cast.cloud[cur[j].curframe], &src, app, &dest);
                }       
            if (cur[j].sprite == EARTH) {
                SDL_BlitSurface(cast.earth[cur[j].curframe], &src, app, &dest);
                }     
            if (cur[j].sprite == SUN) {
                SDL_BlitSurface(cast.sun[cur[j].curframe], &src, app, &dest);
                }     

            if( SDL_GetTicks() - cur[j].lastdrawn > cur[j].animdelay) {
                cur[j].curframe++;
                cur[j].lastdrawn= SDL_GetTicks();
                }
            if( cur[j].curframe == cur[j].frames ) { 
                        cur[j].curframe=0;
                        if (cur[j].loop <= cur[j].toloop) cur[j].loop++; 
                        if (cur[j].loop > cur[j].toloop) {
                            cur[j].loop=0; 
                            cur[j].sprite= NOSPRITE;
                            }
                        }
            }
        }
    }          


void dropclip (runonce sprite, runonce *cur, int ai,
                                         int sx, int sy) {
    for (int j= 0; j < 32; j++) {
        if ( cur[j].sprite == NOSPRITE ) {
            cur[j]= sprite;
            cur[j].y= sy; cur[j].x= sx;
            cur[j].dir= ai;
            
                      
            return;
            }
        }
    }


runonce explosion16;
runonce explosion64;
runonce shieldsarelow;
runonce gameover;
runonce speedup;
runonce absorb;
runonce cloud;
runonce fastcloud;
runonce sun;
runonce earth;
runonce clips[32];
runonce bottomclips[32];
    
