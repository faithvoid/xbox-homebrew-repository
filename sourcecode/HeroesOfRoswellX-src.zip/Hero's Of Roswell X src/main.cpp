/*
    Hero's Of Roswell
    Copyright (C) 2003 Patrick Avella

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
//#include <iostream>

#pragma comment(lib, "libSDLx.lib")

#include <stdlib.h>
#include "SDL.h"
#include "SDL_mixer.h"
#include "main.h"
#include "xtl.h"

void load_settings(void);

#define UP    0
#define DOWN  3
#define RIGHT 1
#define LEFT  4
#define UPLEFT    5
#define UPRIGHT   6
#define DOWNLEFT  7
#define DOWNRIGHT 8
#define NOMOVEMENT 9

#define AI_SHOOTATPC 40
#define AI_SWINGDOWN 41
#define AI_LVL1BOSS 42
#define AI_LVL2BOSS 43
#define AI_LVL3BOSS 44
#define AI_LVL4BOSS 45
#define AI_SWINGDOWNSHOOT 46

#define NME_NONE 0
#define NME_UFO 1
#define LVL1BOSS 2
#define NME_BIRDHEAD 3
#define NME_INTERCEPTOR 4
#define NME_SKEL 5
#define LVL2BOSS 6
#define LVL3BOSS 7
#define LVL4BOSS 8
#define NOSPRITE 96

#define EXPLODE16 10
#define EXPLODE64 11
#define NOTICE 20

#define SHIELDSLOW 21
#define GAMEOVER 22
#define SPEEDUP 23
#define ABSORB 24
#define CLOUD 25
#define SUN 26
#define EARTH 27
#define MARS 28

#define SPEEDICON 30
#define WEAPONICON 31
#define SHIELDICON 32
#define LIFEICON 33

#define NOWEAPON 0
#define LVL1BULLET 1
#define LVL2BULLET 2
#define LVL3BULLET 3
#define LVL4BULLET 4
#define LVL5BULLET 5

#define NME1BULLET 15
#define NME2BULLET 16

#define EASY 1
#define MEDIUM 2
#define HARD 3

int shot = 0;


extern "C" LPDIRECT3DDEVICE8 D3D_Device;
//using namespace std;

//XBOX GAMEPAD STUFF
SDL_Joystick *GAMEPAD;
Sint16 joyx, joyy; //axes
Sint16 blackbutton;
Sint16 abutton; //A button
Sint16 bbutton;
Sint16 xbutton;
Sint16 ybutton;
Sint16 backbutton; //BACK button
Sint16 startbutton; //START button
Sint16 rstick; 
Sint16 dpad; //dpad
Sint16 ltrigger, rtrigger; //Trigger buttons

LAUNCH_DATA LaunchData = { LDT_TITLE };

int flickerlevel;
int xpos;
int ypos;
int xstretch;
int ystretch;
FILE *conf;








int difficulty;
int score;
int kill4powerup;
struct spriteManager {
    SDL_Rect recta, rectb, rectfull;
    
    SDL_Surface *pclevel[3], *pcbankleft[3], *pcbankright[3];
    SDL_Surface *ufo[3], *mbullet;
    SDL_Surface *starbg, *lvl1bullet[1], *lvl2bullet[1], *nme1bullet[1];
    SDL_Surface *rural, *rural2, *lvl3bullet[3], *lvl4bullet[2];
    SDL_Surface *explosion16[4], *explosion64[5], *lvl1boss[3];
    SDL_Surface *shieldbar, *shields, *shieldsgreen, *shieldsred;
    SDL_Surface *shieldslow[2], *pcicon, *gameover[1], *speedicon[2];
    SDL_Surface *speedup[1], *absorb[5], *weaponicon[2];
    SDL_Surface *lvl1bossbg, *birdhead[3], *thebosshp;
    SDL_Surface *lifeicon[2], *shieldicon[2], *numbers;
    SDL_Surface *cloud[1], *sun[2], *earth[3];
    SDL_Surface *interceptor[3], *skel[1], *lvl2boss[1];
    SDL_Surface *lvl3boss[3], *lvl4boss[2], *water, *water2, *sand, *sand2;
    SDL_Surface *mars[1];
    } cast;

struct soundManager {
    Mix_Chunk *smlaser, *exp16, *exp64, *smallbullet, *beep, *shieldsarelow;
    Mix_Chunk *hpup, *speedup, *absorb, *bosscoming;
    Mix_Chunk *largebullet, *rocket;
    Mix_Music *lvl1mid, *titlemusic, *gameover, *lvl1boss,*story, *story2;
    Mix_Music *lvl2mid, *lvl3mid, *lvl4mid, *victorymid;
    } audio;

void initSoundManager(soundManager *sm) {
    sm->bosscoming= Mix_LoadWAV("d:\\wav\\bosscoming.wav");
    sm->absorb= Mix_LoadWAV("d:\\wav\\absorb.wav");
    sm->smlaser= Mix_LoadWAV("d:\\wav\\laser.wav");
    sm->hpup= Mix_LoadWAV("d:\\wav\\hpup.wav");
    sm->speedup= Mix_LoadWAV("d:\\wav\\speedup.wav");
    sm->shieldsarelow= Mix_LoadWAV("d:\\wav\\shieldsarelow.wav");
    sm->exp16= Mix_LoadWAV("d:\\wav\\exp16.wav");
    sm->exp64= Mix_LoadWAV("d:\\wav\\exp64.wav");
    sm->smallbullet = Mix_LoadWAV("d:\\wav\\smallbullet.wav");
    sm->largebullet = Mix_LoadWAV("d:\\wav\\largebullet.wav");
    sm->rocket = Mix_LoadWAV("d:\\wav\\rocket.wav");
    sm->beep = Mix_LoadWAV("d:\\wav\\beep.wav");
    sm->lvl1mid = Mix_LoadMUS("d:\\midi\\level1.ogg");
    sm->lvl2mid = Mix_LoadMUS("d:\\midi\\level2.ogg");    
    sm->lvl3mid = Mix_LoadMUS("d:\\midi\\level3.ogg"); 
    sm->lvl4mid = Mix_LoadMUS("d:\\midi\\level4.ogg"); 
    sm->victorymid = Mix_LoadMUS("d:\\midi\\victory.ogg"); 
    sm->titlemusic = Mix_LoadMUS("d:\\midi\\title.ogg");
    sm->gameover = Mix_LoadMUS("d:\\midi\\gameover.ogg");
    sm->lvl1boss = Mix_LoadMUS("d:\\midi\\lvl1boss.ogg");
    sm->story = Mix_LoadMUS("d:\\midi\\story.ogg");
    sm->story2 = Mix_LoadMUS("d:\\midi\\story2.ogg");
    }
    
void initSpriteManager(spriteManager *sm) {

    sm->starbg= SDL_LoadBMP("d:\\bmp\\openspace.bmp");
    sm->rural= SDL_LoadBMP("d:\\bmp\\rural.bmp");
    sm->rural2= SDL_LoadBMP("d:\\bmp\\rural2.bmp");
    sm->lvl1bossbg= SDL_LoadBMP("d:\\bmp\\lvl1bossbg.bmp");
    sm->water= SDL_LoadBMP("d:\\bmp\\water.bmp");
    sm->water2= SDL_LoadBMP("d:\\bmp\\water2.bmp");
    sm->sand= SDL_LoadBMP("d:\\bmp\\sand.bmp");
    sm->sand2= SDL_LoadBMP("d:\\bmp\\sand2.bmp");    
    sm->thebosshp= SDL_LoadBMP("d:\\bmp\\thebosshp.bmp");

    SDL_Surface *buf;
    buf= SDL_LoadBMP("d:\\bmp\\ship0.bmp");
    sm->pclevel[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->pclevel[0], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->pclevel[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    buf= SDL_LoadBMP("d:\\bmp\\ship1.bmp");
    sm->pclevel[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->pclevel[1], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->pclevel[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    buf= SDL_LoadBMP("d:\\bmp\\ship2.bmp");
    sm->pclevel[2]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->pclevel[2], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->pclevel[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    
    buf= SDL_LoadBMP("d:\\bmp\\shipl0.bmp");
    sm->pcbankleft[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->pcbankleft[0], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->pcbankleft[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    buf= SDL_LoadBMP("d:\\bmp\\shipl1.bmp");
    sm->pcbankleft[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->pcbankleft[1], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->pcbankleft[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    buf= SDL_LoadBMP("d:\\bmp\\shipl2.bmp");
    sm->pcbankleft[2]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->pcbankleft[2], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->pcbankleft[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
        
    buf= SDL_LoadBMP("d:\\bmp\\shipr0.bmp");
    sm->pcbankright[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->pcbankright[0], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->pcbankright[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    buf= SDL_LoadBMP("d:\\bmp\\shipr1.bmp");
    sm->pcbankright[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->pcbankright[1], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->pcbankright[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    buf= SDL_LoadBMP("d:\\bmp\\shipr2.bmp");
    sm->pcbankright[2]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->pcbankright[2], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->pcbankright[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

        
    buf= SDL_LoadBMP("d:\\bmp\\ufo0.bmp");
    sm->ufo[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->ufo[0], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->ufo[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    buf= SDL_LoadBMP("d:\\bmp\\ufo1.bmp");
    sm->ufo[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->ufo[1], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->ufo[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    buf= SDL_LoadBMP("d:\\bmp\\ufo2.bmp");
    sm->ufo[2]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->ufo[2], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->ufo[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

    buf= SDL_LoadBMP("d:\\bmp\\l1b.bmp");
    sm->lvl1bullet[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl1bullet[0], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->lvl1bullet[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

    buf= SDL_LoadBMP("d:\\bmp\\l2b.bmp");
    sm->lvl2bullet[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl2bullet[0], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->lvl2bullet[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

         buf= SDL_LoadBMP("d:\\bmp\\l3b0.bmp");
                    sm->lvl3bullet[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl3bullet[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl3bullet[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
         buf= SDL_LoadBMP("d:\\bmp\\l3b1.bmp");
                    sm->lvl3bullet[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl3bullet[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl3bullet[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
         buf= SDL_LoadBMP("d:\\bmp\\l3b2.bmp");
                    sm->lvl3bullet[2]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl3bullet[2], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl3bullet[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
         buf= SDL_LoadBMP("d:\\bmp\\l4b0.bmp");
                    sm->lvl4bullet[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl4bullet[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl4bullet[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);    
         buf= SDL_LoadBMP("d:\\bmp\\l4b1.bmp");
                    sm->lvl4bullet[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl4bullet[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl4bullet[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);    
    

    buf= SDL_LoadBMP("d:\\bmp\\nme1bullet.bmp");
    sm->nme1bullet[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->nme1bullet[0], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->nme1bullet[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

    buf= SDL_LoadBMP("d:\\bmp\\exp16-0.bmp");
    sm->explosion16[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->explosion16[0], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->explosion16[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    buf= SDL_LoadBMP("d:\\bmp\\exp16-1.bmp");
    sm->explosion16[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->explosion16[1], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->explosion16[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
        buf= SDL_LoadBMP("d:\\bmp\\exp16-2.bmp");
    sm->explosion16[2]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->explosion16[2], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->explosion16[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
        buf= SDL_LoadBMP("d:\\bmp\\exp16-3.bmp");
    sm->explosion16[3]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->explosion16[3], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->explosion16[3]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\exp64-0.bmp");
                    sm->explosion64[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->explosion64[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->explosion64[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\exp64-1.bmp");
                    sm->explosion64[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->explosion64[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->explosion64[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\exp64-2.bmp");
                    sm->explosion64[2]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->explosion64[2], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->explosion64[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\exp64-3.bmp");
                    sm->explosion64[3]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->explosion64[3], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->explosion64[3]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\exp64-4.bmp");
                    sm->explosion64[4]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->explosion64[4], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->explosion64[4]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\shields.bmp");
                    sm->shields= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->shields, SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->shields->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\shieldsred.bmp");
                    sm->shieldsred= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->shieldsred, SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->shieldsred->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\shieldsgreen.bmp");
                    sm->shieldsgreen= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->shieldsgreen, SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->shieldsgreen->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\shieldbar.bmp");
                    sm->shieldbar= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->shieldbar, SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->shieldbar->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\shieldslow0.bmp");
                    sm->shieldslow[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->shieldslow[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->shieldslow[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\shieldslow1.bmp");
                    sm->shieldslow[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->shieldslow[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->shieldslow[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\pcicon.bmp");
                    sm->pcicon= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->pcicon, SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->pcicon->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\gameover.bmp");
                    sm->gameover[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->gameover[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->gameover[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\speedicon0.bmp");
                    sm->speedicon[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->speedicon[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->speedicon[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\speedicon1.bmp");
                    sm->speedicon[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->speedicon[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->speedicon[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\weaponicon0.bmp");
                    sm->weaponicon[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->weaponicon[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->weaponicon[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\weaponicon1.bmp");
                    sm->weaponicon[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->weaponicon[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->weaponicon[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\speedup.bmp");
                    sm->speedup[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->speedup[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->speedup[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\absorb0.bmp");
                    sm->absorb[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->absorb[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->absorb[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\absorb1.bmp");
                    sm->absorb[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->absorb[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->absorb[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\absorb2.bmp");
                    sm->absorb[2]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->absorb[2], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->absorb[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\absorb3.bmp");
                    sm->absorb[3]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->absorb[3], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->absorb[3]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\absorb4.bmp");
                    sm->absorb[4]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->absorb[4], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->absorb[4]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

       buf= SDL_LoadBMP("d:\\bmp\\lvl1boss0.bmp");
                    sm->lvl1boss[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl1boss[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl1boss[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\lvl1boss1.bmp");
                    sm->lvl1boss[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl1boss[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl1boss[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);    
       buf= SDL_LoadBMP("d:\\bmp\\lvl1boss2.bmp");
                    sm->lvl1boss[2]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl1boss[2], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl1boss[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
//
       buf= SDL_LoadBMP("d:\\bmp\\lvl2boss0.bmp");
                    sm->lvl2boss[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl2boss[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl2boss[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
//
       buf= SDL_LoadBMP("d:\\bmp\\lvl3boss0.bmp");
                    sm->lvl3boss[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl3boss[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl3boss[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\lvl3boss1.bmp");
                    sm->lvl3boss[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl3boss[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl3boss[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);    
       buf= SDL_LoadBMP("d:\\bmp\\lvl3boss2.bmp");
                    sm->lvl3boss[2]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl3boss[2], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl3boss[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
//
       buf= SDL_LoadBMP("d:\\bmp\\lvl4boss0.bmp");
                    sm->lvl4boss[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl4boss[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl4boss[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\lvl4boss1.bmp");
                    sm->lvl4boss[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lvl4boss[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lvl4boss[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);    
//
       buf= SDL_LoadBMP("d:\\bmp\\birdhead0.bmp");
                    sm->birdhead[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->birdhead[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->birdhead[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
           buf= SDL_LoadBMP("d:\\bmp\\birdhead1.bmp");
                    sm->birdhead[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->birdhead[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->birdhead[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
           buf= SDL_LoadBMP("d:\\bmp\\birdhead2.bmp");
                    sm->birdhead[2]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->birdhead[2], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->birdhead[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
//
       buf= SDL_LoadBMP("d:\\bmp\\interceptor0.bmp");
                    sm->interceptor[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->interceptor[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->interceptor[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
       buf= SDL_LoadBMP("d:\\bmp\\interceptor1.bmp");
                    sm->interceptor[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->interceptor[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->interceptor[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);    
       buf= SDL_LoadBMP("d:\\bmp\\interceptor2.bmp");
                    sm->interceptor[2]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->interceptor[2], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->interceptor[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
//
       buf= SDL_LoadBMP("d:\\bmp\\skel.bmp");
                    sm->skel[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->skel[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->skel[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
//
           buf= SDL_LoadBMP("d:\\bmp\\shieldicon0.bmp");
                    sm->shieldicon[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->shieldicon[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->shieldicon[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
           buf= SDL_LoadBMP("d:\\bmp\\shieldicon1.bmp");
                    sm->shieldicon[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->shieldicon[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->shieldicon[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
           buf= SDL_LoadBMP("d:\\bmp\\lifeicon0.bmp");
                    sm->lifeicon[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lifeicon[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lifeicon[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
           buf= SDL_LoadBMP("d:\\bmp\\lifeicon1.bmp");
                    sm->lifeicon[1]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->lifeicon[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->lifeicon[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

/*           buf= SDL_LoadBMP("d:\\bmp\\cloud.bmp");
                    sm->cloud[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->cloud[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                    sm->cloud[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
*/
    buf= SDL_LoadBMP("d:\\bmp\\cloud.bmp");
//    SDL_SetAlpha(buf, SDL_SRCALPHA|SDL_RLEACCEL, 100);
    sm->cloud[0]= SDL_DisplayFormat(buf);
    SDL_SetColorKey(sm->cloud[0], SDL_SRCCOLORKEY, SDL_MapRGB(
        sm->cloud[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

    buf= SDL_LoadBMP("d:\\bmp\\sun0.bmp");
                      sm->sun[0]= SDL_DisplayFormat(buf);
      SDL_SetColorKey(sm->sun[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                      sm->sun[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    buf= SDL_LoadBMP("d:\\bmp\\sun1.bmp");
                      sm->sun[1]= SDL_DisplayFormat(buf);
      SDL_SetColorKey(sm->sun[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                      sm->sun[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    
    buf= SDL_LoadBMP("d:\\bmp\\earth0.bmp");
                      sm->earth[0]= SDL_DisplayFormat(buf);
      SDL_SetColorKey(sm->earth[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                      sm->earth[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
    buf= SDL_LoadBMP("d:\\bmp\\earth1.bmp");
                      sm->earth[1]= SDL_DisplayFormat(buf);
      SDL_SetColorKey(sm->earth[1], SDL_SRCCOLORKEY, SDL_MapRGB(
                      sm->earth[1]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);    
    buf= SDL_LoadBMP("d:\\bmp\\earth2.bmp");
                      sm->earth[2]= SDL_DisplayFormat(buf);
      SDL_SetColorKey(sm->earth[2], SDL_SRCCOLORKEY, SDL_MapRGB(
                      sm->earth[2]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
//
    buf= SDL_LoadBMP("d:\\bmp\\mars.bmp");
                      sm->mars[0]= SDL_DisplayFormat(buf);
      SDL_SetColorKey(sm->mars[0], SDL_SRCCOLORKEY, SDL_MapRGB(
                      sm->mars[0]->format, 0, 0, 0) );
    SDL_FreeSurface(buf);
//

    buf= SDL_LoadBMP("d:\\bmp\\numbers.bmp");
                      sm->numbers= SDL_DisplayFormat(buf);
      SDL_SetColorKey(sm->numbers, SDL_SRCCOLORKEY, SDL_MapRGB(
                      sm->numbers->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

    }    

SDL_Surface *getSprite (int sprite) {
    if (sprite == NME_UFO) return cast.ufo[0];
    if (sprite == SPEEDICON) return cast.speedicon[0];
    if (sprite == WEAPONICON) return cast.weaponicon[0];
    if (sprite == LVL1BOSS) return cast.lvl1boss[0];
    if (sprite == LVL2BOSS) return cast.lvl2boss[0];
    if (sprite == LVL3BOSS) return cast.lvl3boss[0];
    if (sprite == LVL4BOSS) return cast.lvl4boss[0];
    if (sprite == NME_BIRDHEAD) return cast.birdhead[0];
    if (sprite == NME_INTERCEPTOR) return cast.interceptor[0];
    if (sprite == NME_SKEL) return cast.skel[0];
    if (sprite == SHIELDICON) return cast.shieldicon[0];    
    if (sprite == LIFEICON) return cast.lifeicon[0];        
    if (sprite == MARS) return cast.mars[0]; 
    }

Uint32 getpixel(SDL_Surface *surface, int x, int y)
{
    SDL_LockSurface(surface);
    int bpp = surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to retrieve */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;
    SDL_UnlockSurface(surface);

    switch(bpp) {
    case 1:
        return *p;

    case 2:
        return *(Uint16 *)p;

    case 3:
        if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
            return p[0] << 16 | p[1] << 8 | p[2];
        else
            return p[0] | p[1] << 8 | p[2] << 16;

    case 4:
        return *(Uint32 *)p;

    default:
        return 0;       /* shouldn't happen, but avoids warnings */
    }
}

#include "globals.h"
#include "background.h"
#include "runonce.h"
#include "shoot.h"
#include "mypc.h"
#include "nmesprite.h"
#include "cutscenes.h"
#include "levels.h"
#include "titlescreen.h"

SDL_Rect numbersource;
SDL_Rect healthbar;
int pcscore1, pcscore2, pcscore3;
void drawgui(SDL_Surface *app) {
    SDL_Rect dest, dest2;
    dest.x=6; dest.y=530; dest.w=256; dest.h=64;
    dest2.x=6; dest2.y=563; dest2.w=((pc.hp*64)-64); dest2.h=32;
    if (dest2.w == 0) dest2.w= 10;
    if (((pc.hp*64)-64) < 0) dest2.w= 0;
    if (healthbar.w > dest2.w) {
        healthbar.w-=2;
        SDL_BlitSurface(cast.shieldsred, NULL, app, &dest);
        }
    if (healthbar.w < dest2.w) {
        healthbar.w+=2;
        SDL_BlitSurface(cast.shieldsgreen, NULL, app, &dest);
        }
    if (healthbar.w == dest2.w) {
        SDL_BlitSurface(cast.shields, NULL, app, &dest);
        }

    SDL_BlitSurface(cast.shieldbar, &healthbar, app, &dest2);
    dest.y=564; dest.w=16; dest.h=16;
    for (int ti=0; ti < pc.lives-1; ti++) {
        dest.x= (ti*16)+260;
        SDL_BlitSurface(cast.pcicon, NULL, app, &dest);
        }        
    if(showbosshp) {
        SDL_Rect srect;
        srect.x=0; srect.y=0; srect.h=16; srect.w=thebosshp;
        dest.x=0; dest.y=0; dest.h=16; dest.w=800;
        SDL_BlitSurface(cast.thebosshp, &srect, app, &dest);
        }
    if(pc.score>9){pc.score=0;pcscore1++;}
    if(pcscore1>9){pcscore1=0;pcscore2++;}
    if(pcscore2>9){pcscore2=0;pcscore3++;}
    if(pcscore3>9){pc.score=9;}
    dest.y=565; dest.x= 760; dest.w=16; dest.h=16;
    numbersource.x=pc.score*24;
    SDL_BlitSurface(cast.numbers, &numbersource, app, &dest);
    numbersource.x=pcscore1*24; dest.x-=24;
    SDL_BlitSurface(cast.numbers, &numbersource, app, &dest);
    numbersource.x=pcscore2*24; dest.x-=24;
    SDL_BlitSurface(cast.numbers, &numbersource, app, &dest);
    numbersource.x=pcscore3*24; dest.x-=24;
    SDL_BlitSurface(cast.numbers, &numbersource, app, &dest);
    }

int main(int argc, char *argv[])
{
    printf("Copyright 2003 Patrick Avella, All Rights Reserved\n");
    if(!cheatson){cheatson=false;}
    if(!lastlevelplayed){lastlevelplayed=1;}
    if(!continuelevel){continuelevel=false;}
  
  if (SDL_Init(SDL_INIT_AUDIO | SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) < 0) {
//    cout << "Unable to init audio or video... ;)\n";
    }

	if(Mix_OpenAudio(44100, AUDIO_S16SYS, 2, 2048) < 0) {
	    //no sound
	    }

  atexit(SDL_Quit);
  
  SDL_ShowCursor(0);
  GAMEPAD = SDL_JoystickOpen(0); //Open Pad 1
  SDL_JoystickEventState(SDL_ENABLE); //Enable event stuff for our pad

  app=  SDL_SetVideoMode(800,600,16, SDL_HWSURFACE|SDL_DOUBLEBUF|SDL_FULLSCREEN);// | SDL_DOUBLEBUF | SDL_FULLSCREEN); 
  load_settings();
  initSoundManager(&audio);
  titlescreen(app);
  

    level1ison = true;
    level1bossison = false;
    level2ison = false;
    level2bossison = false;
    level3ison = false;
    level3bossison = false;
    level4ison = false;
    level4bossison = false;

    if(continuelevel) {
    if(lastlevelplayed==1){}
    if(lastlevelplayed==2){level1ison=false;level2ison=true;}
    if(lastlevelplayed==3){level1ison=false;level3ison=true;}
    if(lastlevelplayed==4){level1ison=false;level4ison=true;}
    }
  thebosshp=800;

  SDL_Rect screenrect;
  screenrect.x=0; screenrect.y=0; screenrect.w=800; screenrect.h=600;  

 // cout << "SDL video and audio Initialized.... \n";
  healthbar.x=0; healthbar.y=0; healthbar.w=256; healthbar.h=32;
  numbersource.x=0; numbersource.y=0; numbersource.w=24; numbersource.h=24; 
  pcscore1=0; pcscore2=0; pcscore3=0;

  initSpriteManager(&cast);


 // cout << "sprites and sounds Loaded \n";

  initbottomlayer(&bg);

  if (difficulty == EASY) kill4powerup=20;
  if (difficulty == MEDIUM) kill4powerup=25;
  if (difficulty == HARD) kill4powerup=30;

  initpc(&pc);
  if (difficulty == EASY) pc.lives=5;
  int difmod= 0;
  if (difficulty == HARD) difmod=1;

  int bspeed;
  if (difficulty == EASY) bspeed=10;
  if (difficulty == MEDIUM) bspeed=12;
  if (difficulty == HARD) bspeed=14;
  initbullet(&level1bullet, 16, 16, 0,0, 1, NOMOVEMENT, 14, LVL1BULLET, 1);
  initbullet(&level2bullet, 16, 16, 0,0, 1, NOMOVEMENT, 16, LVL2BULLET, 1);
  initbullet(&level3bullet, 16, 16, 0,0, 3, NOMOVEMENT, 12, LVL3BULLET, 60);
  initbullet(&level4bullet, 16, 16, 0,0, 2, NOMOVEMENT, 10, LVL4BULLET, 1);
  initbullet(&nme1bullet, 16, 16, 0,0, 1, NOMOVEMENT, bspeed, NME1BULLET, 1);
  initbullet(&nme2bullet, 16, 16, 0,0, 3, NOMOVEMENT, bspeed+2, NME2BULLET, 60);

  if (difficulty == EASY) nme2bullet=nme1bullet;
  
  initnme(&speedicon,64,32,2,DOWN,4,10+difmod,0,300,SPEEDICON,AI_SWINGDOWN,1, 800);
  initnme(&weaponicon,64,32,2,DOWN,4,10+difmod,0,300,WEAPONICON,AI_SWINGDOWN,1, 800);
  initnme(&shieldicon,64,32,2,DOWN,4,10+difmod,0,300,SHIELDICON,AI_SWINGDOWN,1, 800);
  initnme(&lifeicon,64,32,2,DOWN,4,10+difmod,0,300,LIFEICON,AI_SWINGDOWN,1, 800);
  initnme(&marsicon,256,256,1,DOWN,1,30+difmod,0,300,MARS,NOMOVEMENT,1, 800);
  initnme(&dumbufo,64,64,3,DOWN,8,3+difmod,NME1BULLET,120,NME_UFO,AI_SHOOTATPC,2,15);
  initnme(&birdhead,128,128,3,DOWN,4,15+difmod,NME1BULLET,100,NME_BIRDHEAD,AI_SHOOTATPC,10,10);
  initnme(&skel,96,64,1,DOWN,10,15+difmod,NME2BULLET,100,NME_SKEL,AI_SHOOTATPC,5,10);
  initnme(&interceptor,128,128,3,DOWN,8,20+difmod,NME2BULLET,100,NME_INTERCEPTOR,AI_SWINGDOWNSHOOT,8,15);
  initnme(&lvl1boss,512,256,3,RIGHT,10,180,NOWEAPON,80,LVL1BOSS,AI_LVL1BOSS,99999,25);
  initnme(&lvl2boss,512,256,1,RIGHT,10,220,NOWEAPON,80,LVL2BOSS,AI_LVL2BOSS,99999,23);
  initnme(&lvl3boss,512,256,3,RIGHT,10,280,NOWEAPON,140,LVL3BOSS,AI_LVL3BOSS,99999,23);
  initnme(&lvl4boss,256,256,2,RIGHT,10,320,NOWEAPON,600,LVL4BOSS,AI_LVL4BOSS,99999,20);
  for (int j=0; j < 32; j++) {
     nmesprites[j].hp= 0; 
     }


  for (int j=0; j < 32; j++) {
     bullets[j].ai= NOMOVEMENT; 
     }

 initRunOnce(&explosion16, 16,16,4,0,60,EXPLODE16);
 initRunOnce(&explosion64, 64,64,5,4,60,EXPLODE64);
 initRunOnce(&shieldsarelow, 128,512,2,0,375,SHIELDSLOW, 2);
 initRunOnce(&gameover, 256,512,1,2,5000,GAMEOVER, 30);
 initRunOnce(&speedup, 128,512,1,24,5000,SPEEDUP, 30);
 initRunOnce(&absorb, 64,64,5,0,60,ABSORB, 2);

 initRunOnce(&cloud, 128,256,1,2,6000,CLOUD, 30);
 initRunOnce(&fastcloud, 128,256,1,6,6000,CLOUD, 30);
 initRunOnce(&sun, 256,256,2,1,1000,SUN, 9999);
 initRunOnce(&earth, 320,320,3,1,500,EARTH, 9999);
  for (int j=0; j < 32; j++) {
     clips[j].sprite= NOSPRITE; 
     }
  for (int j=0; j < 32; j++) {
     bottomclips[j].sprite= NOSPRITE; 
     }

 // cout << "everything Initialized.... \n";

 // cout << "Started Music.... \n";



 // cout << "Dropped the instructions.... \n";

  bool pcshooting= false;
  int pcshootdelay= 0;
  Uint32 oldtime, newtime, myfps;
  oldtime=0;
  int moving= NOMOVEMENT;
  bool finished= false;
  Uint32 lastframe= 0;
  stageCount=0;
  while (!finished) {
  theStage();
  if(pc.dir==NOMOVEMENT) moving=NOMOVEMENT;
    SDL_Event event;

	SDL_PumpEvents();
	SDL_JoystickUpdate(); //manual refresh of the gamepad(s)
	//parse all gamepads
	joyx = SDL_JoystickGetAxis(GAMEPAD, 0);
	joyy = SDL_JoystickGetAxis(GAMEPAD, 1);
	dpad = SDL_JoystickGetHat(GAMEPAD, 0);
	blackbutton = SDL_JoystickGetButton(GAMEPAD, 4); //Black Button
	abutton = SDL_JoystickGetButton(GAMEPAD, 0); //Get A-Button(0)
	bbutton = SDL_JoystickGetButton(GAMEPAD, 1);
	backbutton = SDL_JoystickGetButton(GAMEPAD, 9); //Get BACK-Button(9)
	rstick = SDL_JoystickGetButton(GAMEPAD,11);
	ltrigger = SDL_JoystickGetButton(GAMEPAD,6);
	rtrigger = SDL_JoystickGetButton(GAMEPAD,7);
	xbutton = SDL_JoystickGetButton(GAMEPAD,2);
	ybutton = SDL_JoystickGetButton(GAMEPAD,3);
	startbutton = SDL_JoystickGetButton(GAMEPAD,8);


	if(dpad == SDL_HAT_UP || joyy < -3200){
		if (( moving != NOMOVEMENT ) &&
            ( moving != RIGHT ) &&
            ( moving != LEFT ) ) { moving=UP; }
          if (moving == NOMOVEMENT) moving=UP;
          if (moving == RIGHT) { moving= UPRIGHT; }
          if (moving == LEFT ) { moving= UPLEFT;  }
		
	}else{
		if (moving == UP){
        moving=NOMOVEMENT;
		}
        if (moving == UPLEFT)  moving=LEFT;
        if (moving == UPRIGHT) moving=RIGHT;
	}





	if(dpad == SDL_HAT_DOWN || joyy > 3200){
		if (( moving != NOMOVEMENT ) &&
( moving != RIGHT ) &&
( moving != LEFT ) ) { moving=DOWN; }
if (moving == NOMOVEMENT) moving=DOWN;
if (moving == RIGHT) { moving= DOWNRIGHT; }
if (moving == LEFT ) { moving= DOWNLEFT;  }
	}else{
		if (moving == DOWN) {
         moving=NOMOVEMENT;
		}
        if (moving == DOWNLEFT)  moving=LEFT;
        if (moving == DOWNRIGHT) moving=RIGHT;
}

	

	if(dpad == SDL_HAT_RIGHT || joyx > 3200){
if (( moving != NOMOVEMENT ) &&
( moving != UP ) &&
( moving != DOWN ) ) { moving=RIGHT; }
if (moving == NOMOVEMENT) moving=RIGHT;
if (moving == UP   ) { moving= UPRIGHT;    }
if (moving == DOWN ) { moving= DOWNRIGHT;  }
	}else{
if (moving == RIGHT) {
moving=NOMOVEMENT;
}
if (moving == DOWNRIGHT)  moving=DOWN;
if (moving == UPRIGHT) moving=UP;
}







	if(dpad == SDL_HAT_LEFT || joyx < -3200){
	if (( moving != NOMOVEMENT ) &&
( moving != UP ) &&
( moving != DOWN ) ) { moving=LEFT; }
if (moving == NOMOVEMENT) moving=LEFT;
if (moving == UP   ) { moving= UPLEFT;    }
if (moving == DOWN ) { moving= DOWNLEFT;  }	
	}else{
if (moving == LEFT) {
moving=NOMOVEMENT;
}
if (moving == DOWNLEFT)  moving=DOWN;
if (moving == UPLEFT)    moving=UP;
}



	if(abutton && shot == 1){
		pcshooting= false;
        pcshootdelay=0;
	}

	if(abutton && shot == 0){
		pcshooting= true;
        pcshoot(&pc, bullets);
		shot = 1;
	}


	if(!abutton && shot == 1){
		shot = 0;
	}

	if(rstick){
		SDL_SaveBMP(app,"d:\\horx.bmp");
	}


	if(blackbutton){
		event.type = SDL_KEYDOWN;
		event.key.keysym.sym = SDLK_ESCAPE;
	}

	if(startbutton){
	pausegame(app);
	SDL_Delay(100);
	}



	//while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) { finished=true; }
            if (event.type == SDL_KEYDOWN) {
                if (event.key.keysym.sym == SDLK_ESCAPE) {
                    finished= true;
                    }
                if (event.key.keysym.sym == SDLK_q) {
                    dropnmesprite(dumbufo, nmesprites, RIGHT, -96, 25);
                    }                    
                if (event.key.keysym.sym == SDLK_r) {
                    if (cheatson) {if (pc.hp < 5) pc.hp++;}
                    }  
                if (event.key.keysym.sym == SDLK_a) {
                    if (cheatson) dropnmesprite(weaponicon, nmesprites, LEFT, 400, -32);
                    }       
                if (event.key.keysym.sym == SDLK_w) {
                    if (cheatson) dropnmesprite(speedicon, nmesprites, LEFT, 400, -32);
                    }          
                 }

    if(pcshooting && (difficulty == EASY)) {
        pcshootdelay++;
        if (pcshootdelay > 5) {
           pcshoot(&pc, bullets);
           pcshootdelay= 0;
           }
        }
    if(pcshooting && (difficulty == MEDIUM)) {
        pcshootdelay++;
        if (pcshootdelay > 7) {
           pcshoot(&pc, bullets);
           pcshootdelay= 0;
           }
        }
    if(pcshooting && (difficulty == HARD)) {
        pcshootdelay++;
        if (pcshootdelay > 10) {
           pcshoot(&pc, bullets);
           pcshootdelay= 0;
           }
        }

    pc.dir= moving;

    moveclips(bottomclips);   
    movepc(&pc);
    movenme(nmesprites, &pc, bullets);
    movebullets(bullets);
    moveclips(clips);

    drawbottom(app, &bg);    
    drawclips(bottomclips, app);
    drawpc(&pc, app);
    drawnmesprites(nmesprites, app);
    drawbullets(bullets, app);
    drawclips(clips, app);
    
    drawgui(app);

    SDL_Flip(app);
    


    while(SDL_GetTicks() < lastframe + 33 ) { }
    newtime= SDL_GetTicks();
    lastframe= newtime;
    if (newtime != oldtime+1000) {
      myfps= 1000 / (newtime - oldtime);
      oldtime= newtime;
//      cout << myfps << '\n';
      }
    }          
  
  

  return 0;
}


void load_settings(void)
{


//Open the config file.
conf=fopen("D:\\config.cfg", "r");
fread(&xpos, sizeof(int), 1,conf);
fread(&ypos, sizeof(int), 1, conf);
fread(&xstretch, sizeof(int), 1, conf);
fread(&ystretch, sizeof(int), 1, conf);
fread(&flickerlevel, sizeof(int), 1, conf);
fclose(conf);

//now do the stuff
D3D_Device->SetFlickerFilter(flickerlevel);
//now resize our screen
SDL_XBOX_SetScreenPosition(xpos,ypos);
SDL_XBOX_SetScreenStretch(xstretch,ystretch);
}

