/*
    Hero's Of Roswell
    Copyright (C) 2003 Patrick Avella

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
struct thepcsprite {
    int x, y, oldx, oldy, curframe, dir, accel, h, w, hp, lives, weapon;
    int movedelay, breakdelay, offset, speed, animdelay;
    Uint32 lastmove, lastdrawn;
    SDL_Surface *ani0, *ani1, *ani2;
    SDL_Surface *anil0, *anil1, *anil2;
    SDL_Surface *anir0, *anir1, *anir2;
    SDL_Surface *buf;
    };







void movepc (thepcsprite *pc, int dir) {
    Uint32 curtime= SDL_GetTicks();
    if(curtime - pc->lastmove > pc->movedelay) {
        if (dir == UP   ) pc->y-=pc->speed;
        if (dir == DOWN ) pc->y+=pc->speed;
        if (dir == LEFT ) pc->x-=pc->speed;
        if (dir == RIGHT) pc->x+=pc->speed;
        if (dir == UPLEFT   ) { pc->y-=pc->speed; pc->x-=pc->speed; }
        if (dir == UPRIGHT  ) { pc->y-=pc->speed; pc->x+=pc->speed; }
        if (dir == DOWNLEFT ) { pc->y+=pc->speed; pc->x-=pc->speed; }
        if (dir == DOWNRIGHT) { pc->y+=pc->speed; pc->x+=pc->speed; }
        if (pc->speed < 15) {
            pc->speed+=1;
            }
        if (pc->y > 536) pc->y= 536;
        if (pc->x > 536) pc->x= 536;
        if (pc->y < 0 ) pc->y= 0;
        if (pc->x < 0 ) pc->x= 0;
        pc->lastmove= curtime-((curtime - pc->lastmove) - pc->movedelay);
        }
    }

void initpc (thepcsprite *pc, SDL_Surface *screen) {

    pc->x=300; pc->y=500; pc->oldx=300; pc->oldy=500; pc->curframe=0; pc->dir=0;
    pc->movedelay= 16; pc->lastmove= 0; pc->speed=1; pc->accel=1; pc->lastdrawn=0;
    pc->hp= 5; pc->lives= 3; pc->weapon= 1;
    pc->h=64; pc->w=64;
    pc->animdelay= 100;
    SDL_Surface *tsurf;
    tsurf= SDL_LoadBMP("data/ship0.bmp");
    pc->ani0= SDL_ConvertSurface(tsurf, tsurf->format, SDL_HWSURFACE);
    SDL_SetColorKey(pc->ani0, SDL_SRCCOLORKEY, SDL_MapRGB(pc->ani0->format, 0,0,0));
    tsurf= SDL_LoadBMP("data/ship1.bmp");
    pc->ani1= SDL_ConvertSurface(tsurf, tsurf->format, SDL_HWSURFACE);
    SDL_SetColorKey(pc->ani1, SDL_SRCCOLORKEY, SDL_MapRGB(pc->ani1->format, 0,0,0));
    tsurf= SDL_LoadBMP("data/ship2.bmp");
    pc->ani2= SDL_ConvertSurface(tsurf, tsurf->format, SDL_HWSURFACE);
    SDL_SetColorKey(pc->ani2, SDL_SRCCOLORKEY, SDL_MapRGB(pc->ani2->format, 0,0,0));
    tsurf= SDL_LoadBMP("data/shipl0.bmp");
    pc->anil0= SDL_ConvertSurface(tsurf, tsurf->format, SDL_HWSURFACE);
    SDL_SetColorKey(pc->anil0, SDL_SRCCOLORKEY, SDL_MapRGB(pc->anil0->format, 0,0,0));
    tsurf= SDL_LoadBMP("data/shipl1.bmp");
    pc->anil1= SDL_ConvertSurface(tsurf, tsurf->format, SDL_HWSURFACE);
    SDL_SetColorKey(pc->anil1, SDL_SRCCOLORKEY, SDL_MapRGB(pc->anil1->format, 0,0,0));
    tsurf= SDL_LoadBMP("data/shipl2.bmp");
    pc->anil2= SDL_ConvertSurface(tsurf, tsurf->format, SDL_HWSURFACE);
    SDL_SetColorKey(pc->anil2, SDL_SRCCOLORKEY, SDL_MapRGB(pc->anil2->format, 0,0,0));
    tsurf= SDL_LoadBMP("data/shipr0.bmp");
    pc->anir0= SDL_ConvertSurface(tsurf, tsurf->format, SDL_HWSURFACE);
    SDL_SetColorKey(pc->anir0, SDL_SRCCOLORKEY, SDL_MapRGB(pc->anir0->format, 0,0,0));
    tsurf= SDL_LoadBMP("data/shipr1.bmp");
    pc->anir1= SDL_ConvertSurface(tsurf, tsurf->format, SDL_HWSURFACE);
    SDL_SetColorKey(pc->anir1, SDL_SRCCOLORKEY, SDL_MapRGB(pc->anir1->format, 0,0,0));
    tsurf= SDL_LoadBMP("data/shipr2.bmp");
    pc->anir2= SDL_ConvertSurface(tsurf, tsurf->format, SDL_HWSURFACE);
    SDL_SetColorKey(pc->anir2, SDL_SRCCOLORKEY, SDL_MapRGB(pc->anir2->format, 0,0,0));

    pc->buf = SDL_ConvertSurface(tsurf, tsurf->format, SDL_HWSURFACE | SDL_HWACCEL | SDL_HWPALETTE);
    SDL_Rect dest;
    dest.x= pc->x; dest.y= pc->y; dest.h= pc->h; dest.w= pc->w;
    SDL_BlitSurface(screen, &dest, pc->buf, NULL);
    SDL_FreeSurface(tsurf);
    }

void drawpc (thepcsprite *pc, SDL_Surface *screen, int dir = NOMOVEMENT) {
    SDL_Rect dest;
    dest.x = pc->x; dest.y = pc->y;
    dest.w = 64;    dest.h = 64;
//    if ((pc->x != pc->oldx) || (pc->y != pc->oldy)) {

//        }
    if( pc->curframe==0) {
        if ((pc->dir == LEFT) || (pc->dir == UPLEFT) || (pc->dir == DOWNLEFT)) {
            SDL_BlitSurface(pc->anil0, NULL, screen, &dest);
            }
        if ((pc->dir == RIGHT) || (pc->dir == UPRIGHT) || (pc->dir == DOWNRIGHT)) {
            SDL_BlitSurface(pc->anir0, NULL, screen, &dest);
            }
        if ((pc->dir == UP) || (pc->dir == DOWN) || (pc->dir == NOMOVEMENT)) {
            SDL_BlitSurface(pc->ani0, NULL, screen, &dest);
            }
        }
    if( pc->curframe==1) {
        if ((pc->dir == LEFT) || (pc->dir == UPLEFT) || (pc->dir == DOWNLEFT)) {
            SDL_BlitSurface(pc->anil1, NULL, screen, &dest);
            }
        if ((pc->dir == RIGHT) || (pc->dir == UPRIGHT) || (pc->dir == DOWNRIGHT)) {
            SDL_BlitSurface(pc->anir1, NULL, screen, &dest);
            }
        if ((pc->dir == UP) || (pc->dir == DOWN) || (pc->dir == NOMOVEMENT)) {
            SDL_BlitSurface(pc->ani1, NULL, screen, &dest);
            }
        }
    if( pc->curframe==2) {
        if ((pc->dir == LEFT) || (pc->dir == UPLEFT) || (pc->dir == DOWNLEFT)) {
            SDL_BlitSurface(pc->anil2, NULL, screen, &dest);
            }
        if ((pc->dir == RIGHT) || (pc->dir == UPRIGHT) || (pc->dir == DOWNRIGHT)) {
            SDL_BlitSurface(pc->anir2, NULL, screen, &dest);
            }
        if ((pc->dir == UP) || (pc->dir == DOWN) || (pc->dir == NOMOVEMENT)) {
            SDL_BlitSurface(pc->ani2, NULL, screen, &dest);
            }
        }
 /*
    if( pc->curframe==0) SDL_BlitSurface(pc->ani0, NULL, screen, &dest);
    if( pc->curframe==1) SDL_BlitSurface(pc->ani1, NULL, screen, &dest);
    if( pc->curframe==2) SDL_BlitSurface(pc->ani2, NULL, screen, &dest);
 */
    if( SDL_GetTicks() - pc->lastdrawn > pc->animdelay ) {
        pc->curframe++;
        pc->lastdrawn= SDL_GetTicks()-((SDL_GetTicks() - pc->lastdrawn)-pc->animdelay);
        }
    if( pc->curframe == 3 ) pc->curframe=0;
    }

void clearpc (thepcsprite *pc, SDL_Surface *screen) {
    SDL_Rect old;
//    if ( (pc->x != pc->oldx ) || ( pc->y != pc->oldy) ) {
        old.x= pc->oldx; old.y= pc->oldy; old.w= pc->w; old.h= pc->h;
        SDL_BlitSurface(pc->buf, NULL, screen, &old);
//       }
    }

void bufferpc (thepcsprite *pc, SDL_Surface *screen) {
    SDL_Rect old;
    old.x= pc->x; old.y= pc->y;
    SDL_BlitSurface(screen, &old, pc->buf, NULL);
    pc->oldx = pc->x; pc->oldy = pc->y;
    }

