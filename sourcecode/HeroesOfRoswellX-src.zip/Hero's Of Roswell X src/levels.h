/*
    Hero's Of Roswell
    Copyright (C) 2003 Patrick Avella

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
void droppowerup() {
    int seed= SDL_GetTicks() % 3;
    if(seed == 0) dropnmesprite(speedicon, nmesprites, LEFT, 400, -32);
    if(seed == 1) dropnmesprite(weaponicon, nmesprites, LEFT, 400, -32);
    if(seed == 2) dropnmesprite(shieldicon, nmesprites, LEFT, 400, -32);
    }    
void theStage () {
    if (pc.killcount>kill4powerup) {
        droppowerup();
        pc.killcount=0;
        }
if (level1ison) {
    stageCount++;
    if(stageCount == 1) {
      cutscene(app,0);
      Mix_PlayMusic(audio.lvl1mid, -1);
//         dropclip(notice,clips,DOWN,144,-512);    
       }

    if(stageCount == 50) {
       dropclip(cloud,bottomclips,DOWN,300,-150);
       }

    if(stageCount == 300) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, -256);
       dropnmesprite(dumbufo, nmesprites, LEFT, 910, 158);
       }       
    if(stageCount == 310) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       


    if(stageCount == 360) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 60);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 60);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 60);
       dropclip(fastcloud,clips,DOWN,200,-256);
       }              

    if(stageCount == 600) {
       dropnmesprite(dumbufo, nmesprites, DOWN, 100, -70);
       dropnmesprite(dumbufo, nmesprites, UP, 630, 666);
       dropclip(fastcloud,bottomclips,DOWN,300,-256);
       }              


    if(stageCount == 700) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 233);
       }       

    if(stageCount == 750) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, 200, -70);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 233);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       }       

    if(stageCount == 900) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       

    if(stageCount == 975) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 233);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 233);
       }       

    if(stageCount == 1050) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 50);
       dropclip(cloud,bottomclips,DOWN,400,-150);
       dropclip(fastcloud,clips,DOWN,15000,-256);
       }       

    if(stageCount == 1150) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 500);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 50);
       }       

    if(stageCount == 1050) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, UPRIGHT, -140, 700);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       

    if(stageCount == 1200) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 20);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 20);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 20);
       dropclip(cloud,bottomclips,DOWN,200,-150);
       dropclip(fastcloud,clips,DOWN,400,-256);
       }       

    if(stageCount == 1250) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       }

    if(stageCount == 1500) {
       dropnmesprite(birdhead, nmesprites, RIGHT, -70, 20);
       dropnmesprite(birdhead, nmesprites, RIGHT, -210, 20);
       }              

    if(stageCount == 1575) {
       dropnmesprite(birdhead, nmesprites, RIGHT, -210, 100);
       }              

    if(stageCount == 1700) {
       dropnmesprite(dumbufo, nmesprites, DOWNLEFT, 800, -128);
       }              

    if(stageCount == 1775) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       


    if(stageCount == 1950) {
       dropclip(fastcloud,bottomclips,DOWN,100,-256);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 510);
       }       

    if(stageCount == 2000) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 450);
       }       

    if(stageCount == 2150) {
       dropclip(cloud,bottomclips,DOWN,300,-128);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       }       

    if(stageCount == 2250) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 200);
       dropclip(fastcloud,clips,DOWN,100,-256);
       dropclip(cloud,bottomclips,DOWN,64,-150);
       }       

    if(stageCount == 2300) {
       dropclip(sun,clips,DOWN,550,-256);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 50);
       }       

    if(stageCount == 2400) {
       dropclip(fastcloud,bottomclips,DOWN,600,-256);
       dropnmesprite(birdhead, nmesprites, DOWNLEFT, 450, -128);
       dropclip(cloud,bottomclips,DOWN,128,-150);
       }

    if(stageCount == 2600) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 5);
       dropclip(fastcloud,bottomclips,DOWN,400,-256);
       }       
    if(stageCount == 2675) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 65);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 65);
       }              

    if(stageCount == 2750) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 120);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 120);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 120);
       dropclip(cloud,bottomclips,DOWN,300,-150);
       }       

    if(stageCount == 3000) {
       dropclip(cloud,bottomclips,DOWN,-50,-128);
       dropclip(cloud,bottomclips,DOWN,150,-128);       
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 50);
       }       

    if(stageCount == 3150) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 500);
       dropclip(fastcloud,bottomclips,DOWN,750,-256);
       }       

    if(stageCount == 3300) {
       dropclip(cloud,bottomclips,DOWN,200,-256);
       dropclip(fastcloud,clips,DOWN,550,-256);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 50);
       }       
       
    if(stageCount == 3400) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       }       

    if(stageCount == 3470) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 200);
       }       

    if(stageCount == 3540) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropclip(fastcloud,clips,DOWN,600,-256);
       }       

    if(stageCount == 3600) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 2);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 2);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 2);
       }       

    if(stageCount == 3700) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 25);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 25);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 25);
       dropclip(fastcloud,clips,DOWN,200,-600);
       }       

    if(stageCount == 3800) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 50);
       }       

    if(stageCount == 3900) {
       dropclip(cloud,bottomclips,DOWN,700,-128);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 100);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 500);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 100);
       dropclip(fastcloud,clips,DOWN,200,-256);
       }       

    if(stageCount == 4000) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, -20);
       dropclip(cloud,clips,DOWN,590,-256);
       }
       
    if(stageCount == 4200) {
       dropnmesprite(birdhead, nmesprites, DOWNLEFT, 450, -128);
       dropclip(fastcloud,clips,DOWN,300,-128);
       }

    if(stageCount == 4400) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 5);
       }       
    if(stageCount == 4475) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 65);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 65);
       }                     
    if(stageCount == 4575) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 128);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 128);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 128);
       }                     
    if(stageCount == 4675) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 256);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 256);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 256);
       dropclip(fastcloud,bottomclips,DOWN,600,-256);
       dropclip(fastcloud,clips,DOWN,200,-128);
       }                     
    if(stageCount == 4775) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 200);
       }                     
    if(stageCount == 5000) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 40);
       }
    if(stageCount == 5100) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 80);
       }
    if(stageCount == 5300) {
       dropnmesprite(birdhead, nmesprites, RIGHT, -128, 0);
       }
    if(stageCount == 5400) {
       dropclip(fastcloud,bottomclips,DOWN,400,-256);
       dropclip(fastcloud,clips,DOWN,200,-128);
       }       
    if(stageCount == 5500) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 80);
       }       
    if(stageCount == 5600) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 100);
       }
    if(stageCount == 5700) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 0);
       }
       
    if(stageCount == 6000) {
       stageCount=205;
       level1ison= false;
       level1bossison= true;
       Mix_HaltMusic();
       Mix_PlayChannel(-1, audio.shieldsarelow, 0);
       Mix_PlayMusic(audio.lvl1boss, 0);
       }
    }
if (level1bossison) {
    stageCount++;
    if(stageCount == 5) {
       dropnmesprite(lifeicon, nmesprites, RIGHT, -64, 50);
       }
    if(stageCount == 200) {
       level2ison=true;
       level1bossison=false;    
       showbosshp=false;  
       stageCount=0;
       } 
          
    if(stageCount == 206) {
       dropnmesprite(shieldicon, nmesprites, RIGHT, -64, 50);
       }
       
    if(stageCount == 600) {
       dropnmesprite(lvl1boss, nmesprites, NOMOVEMENT, -512, -256);
       showbosshp=true;
       }

    }

if (level2ison) {
    stageCount++;
    if(stageCount == 1) {
      cutscene(app,1);
      Mix_PlayMusic(audio.lvl2mid, -1);
//         dropclip(notice,clips,DOWN,144,-512);    
       dropclip(earth,bottomclips,DOWN,200,-256);
       }

    if(stageCount == 50) {
       // dropclip(cloud,bottomclips,DOWN,300,-150);
       }

    if(stageCount == 300) {
       // dropclip(cloud,bottomclips,DOWN,100,-128);
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 74);
       dropnmesprite(dumbufo, nmesprites, LEFT, 910, 158);
       }       
    if(stageCount == 310) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       


    if(stageCount == 360) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 60);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 60);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 60);
       }              

    if(stageCount == 600) {
       dropnmesprite(dumbufo, nmesprites, DOWNLEFT, 600, -66);
       dropnmesprite(dumbufo, nmesprites, DOWN, 100, -70);
       dropnmesprite(dumbufo, nmesprites, UP, 630, 666);
       dropnmesprite(birdhead, nmesprites, RIGHT, -128, 200);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       }              


    if(stageCount == 700) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, -70);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 233);
       dropnmesprite(dumbufo, nmesprites, UPLEFT, 800, 666);
       }       

    if(stageCount == 750) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, -70);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 233);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       }       

    if(stageCount == 900) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       

    if(stageCount == 975) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, -70);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 233);
       dropnmesprite(dumbufo, nmesprites, UPLEFT, 800, 666);
       dropnmesprite(birdhead, nmesprites, RIGHT, -128, 200);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);

       }       

    if(stageCount == 1050) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       

    if(stageCount == 1150) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 500);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 50);
       }       

    if(stageCount == 1050) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, UPRIGHT, -140, 700);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       

    if(stageCount == 1200) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 20);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 20);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 20);
       }       

    if(stageCount == 1250) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       }

    if(stageCount == 1250) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, 50);
       }

    if(stageCount == 1500) {
       dropnmesprite(birdhead, nmesprites, RIGHT, -70, 20);
       dropnmesprite(birdhead, nmesprites, RIGHT, -210, 20);
       }              

    if(stageCount == 1575) {
       dropnmesprite(birdhead, nmesprites, DOWN, 600, -128);
       dropnmesprite(birdhead, nmesprites, UP, 100, 728);
       }              

    if(stageCount == 1700) {
       dropnmesprite(birdhead, nmesprites, DOWNLEFT, 800, -128);
       }              

    if(stageCount == 1775) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       

    if(stageCount == 1850) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 60);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 60);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 60);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 510);
       }       

    if(stageCount == 1950) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 510);
       }       

    if(stageCount == 2000) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 450);
       }       

    if(stageCount == 2150) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       

    if(stageCount == 2250) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 200);
       }       

    if(stageCount == 2300) {

       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 50);
       }       

    if(stageCount == 2400) {
       dropnmesprite(birdhead, nmesprites, DOWNLEFT, 450, -128);
       }

    if(stageCount == 2600) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 5);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 50);

       }       
    if(stageCount == 2675) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 65);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 65);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 65);
       dropnmesprite(marsicon, nmesprites, DOWN, 10, -256);
       }              

    if(stageCount == 2750) {
       dropnmesprite(birdhead, nmesprites, RIGHT, -128, 200);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 120);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 120);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 120);
       }       

    if(stageCount == 3000) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, UPRIGHT, -140, 700);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 500);
       }       

    if(stageCount == 3150) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, UPRIGHT, -140, 700);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 500);
       }       

    if(stageCount == 3300) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, UPRIGHT, -140, 700);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 500);
       }       
       
    if(stageCount == 3400) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -74, 150);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -144, 150);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -214, 150);
       }       

    if(stageCount == 3470) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 200);
       }       

    if(stageCount == 3540) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 50);
       }       

    if(stageCount == 3600) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 2);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 2);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 2);
       dropnmesprite(birdhead, nmesprites, RIGHT, -128, 200);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);

       }       

    if(stageCount == 3700) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 25);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 25);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 25);
       }       

    if(stageCount == 3800) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 50);
       }       

    if(stageCount == 3900) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 100);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 500);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 100);
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 5);
       }       

    if(stageCount == 4000) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, -20);
       }
    if(stageCount == 4100) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, -70, -64);
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, 100, -64);
       }
    if(stageCount == 4000) {
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, 200, -64);
       dropnmesprite(dumbufo, nmesprites, DOWNRIGHT, 120, -64);
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 5);

       }
       
    if(stageCount == 4200) {
       dropnmesprite(birdhead, nmesprites, DOWNLEFT, 450, -128);
       }

    if(stageCount == 4400) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 5);
       }       
    if(stageCount == 4475) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 65);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 65);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 65);
       }                     
    if(stageCount == 4575) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 128);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 128);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 128);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 50);       
       }                     
    if(stageCount == 4675) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 256);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 256);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 256);
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 5);

       }                     
    if(stageCount == 4775) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 200);
       }                     
    if(stageCount == 5000) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 40);
       }
    if(stageCount == 5100) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 80);
       }
    if(stageCount == 5200) {
       dropnmesprite(birdhead, nmesprites, DOWNLEFT, 450, -128);
       }
    if(stageCount == 5300) {
       dropnmesprite(birdhead, nmesprites, RIGHT, -128, 200);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 50);
       }
    if(stageCount == 5400) {
       dropnmesprite(birdhead, nmesprites, UPRIGHT, -128, 500);
       }       
    if(stageCount == 5500) {
       dropnmesprite(birdhead, nmesprites, DOWNLEFT, 800, -128);
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 80);
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 870, 5);
       dropnmesprite(dumbufo, nmesprites, LEFT, 940, 5);

       }       
    if(stageCount == 5600) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 100);
       }
    if(stageCount == 5700) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 0);
       dropnmesprite(birdhead, nmesprites, UPRIGHT, -128, 600);
       }
       
    if(stageCount == 6000) {
       stageCount=205;
       level2ison= false;
       level2bossison= true;
       Mix_HaltMusic();
       Mix_PlayChannel(-1, audio.shieldsarelow, 0);
       Mix_PlayMusic(audio.lvl1boss, 0);
       }
    }
if (level2bossison) {
    stageCount++;
    if(stageCount == 5) {
       dropnmesprite(lifeicon, nmesprites, RIGHT, -64, 50);
       }
    if(stageCount == 200) {
       level3ison=true;
       level2bossison=false;    
       showbosshp=false;  
       stageCount=0;
       } 
          
    if(stageCount == 206) {
       dropnmesprite(shieldicon, nmesprites, RIGHT, -64, 50);
       }
       
    if(stageCount == 600) {
       dropnmesprite(lvl2boss, nmesprites, NOMOVEMENT, 800, -256);
       showbosshp=true;
       }

    }

if (level3ison) {
    stageCount++;
    if(stageCount == 1) {
      cutscene(app,2);
      Mix_PlayMusic(audio.lvl3mid, -1);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,-300,-256);
      }
    if(stageCount == 300) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 74);
       dropnmesprite(dumbufo, nmesprites, LEFT, 910, 158);
       }       
    if(stageCount == 310) {
      dropclip(fastcloud,clips,DOWNRIGHT,400,-150);
      dropclip(fastcloud,clips,DOWNRIGHT,300,-150);
      dropclip(fastcloud,clips,DOWNRIGHT,200,-150);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       
    if(stageCount == 370) {
       }

    if(stageCount == 410) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,-300,-256);
       }

    if(stageCount == 500) {
      dropclip(fastcloud,bottomclips,DOWNRIGHT,-150,-256);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,-300,256);
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 74);
       dropnmesprite(dumbufo, nmesprites, LEFT, 910, 158); 
       }

    if(stageCount == 570) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(skel, nmesprites, LEFT, 800, 5);
       }

    if(stageCount == 700) {
       dropnmesprite(interceptor, nmesprites, RIGHT, -128, -128);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,-300,256);
       }

    if(stageCount == 770) {
       dropnmesprite(skel, nmesprites, RIGHT, -96, 30);
       }
    if(stageCount == 820) {
      dropclip(fastcloud,bottomclips,DOWNRIGHT,-300,0);
       dropnmesprite(skel, nmesprites, LEFT, 800, 128);
       dropnmesprite(skel, nmesprites, RIGHT, -96, 30);
       }
    if(stageCount == 820) {
       dropnmesprite(skel, nmesprites, DOWNLEFT, 400, -128);
       dropnmesprite(skel, nmesprites, DOWNRIGHT, 400, -128);
       dropnmesprite(skel, nmesprites, DOWN, 400, -128);
       }
    if(stageCount == 900) {
       dropnmesprite(skel, nmesprites, DOWNLEFT, 400, -128);
       dropnmesprite(skel, nmesprites, DOWNRIGHT, 400, -128);
       dropnmesprite(skel, nmesprites, DOWN, 400, -128);
      dropclip(fastcloud,clips,DOWNRIGHT,-300,400);
      dropclip(fastcloud,clips,DOWNRIGHT,-300,200);
      dropclip(fastcloud,clips,DOWNRIGHT,-300,0);
       }
    if(stageCount == 1000) {
       dropnmesprite(skel, nmesprites, DOWNLEFT, 400, -128);
       }
    if(stageCount == 1100) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 74);
       dropnmesprite(dumbufo, nmesprites, LEFT, 910, 158); 
       }
    if(stageCount == 1250) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50); 
      dropclip(fastcloud,clips,DOWNRIGHT,400,-150);
      dropclip(fastcloud,clips,DOWNRIGHT,300,-150);
      dropclip(fastcloud,clips,DOWNRIGHT,200,-150);
       }
    if(stageCount == 1350) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }
    if(stageCount == 1450) {
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, 200);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 60);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 60);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 60);
       }
    if(stageCount == 1550) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 100);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 100);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 100);
       }
    if(stageCount == 1700) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
      dropclip(fastcloud,clips,DOWNRIGHT,400,-150);
      dropclip(fastcloud,clips,DOWNRIGHT,300,-150);
      dropclip(fastcloud,clips,DOWNRIGHT,200,-150);
       }
    if(stageCount == 1750) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 500);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 500);
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, 200);
       }
    if(stageCount == 1875) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(skel, nmesprites, LEFT, 800, 5);
       }
    if(stageCount == 1975) {
       dropnmesprite(skel, nmesprites, LEFT, 800, 200);
       }
    if(stageCount == 2100) {
       dropnmesprite(skel, nmesprites, LEFT, 800, 200);
       }
    if(stageCount == 2300) {
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, 200);
      dropclip(fastcloud,clips,DOWNRIGHT,400,-150);
      dropclip(fastcloud,clips,DOWNRIGHT,300,-150);
      dropclip(fastcloud,clips,DOWNRIGHT,200,-150);
       }
    if(stageCount == 2350) {
       dropnmesprite(skel, nmesprites, DOWNLEFT, 600, -96);
       }

    if(stageCount == 2500) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       
    if(stageCount == 2500) {
       }

    if(stageCount == 2650) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }

    if(stageCount == 2800) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 74);
       dropnmesprite(dumbufo, nmesprites, LEFT, 910, 158); 
       }

    if(stageCount == 3000) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(skel, nmesprites, LEFT, 800, 5);
       }

    if(stageCount == 3150) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50); 
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-400);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-300);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-200);
       }
    if(stageCount == 3250) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, -200);
       }
    if(stageCount == 3350) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 60);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 60);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 60);
       }
    if(stageCount == 3500) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 100);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 100);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 100);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-400);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-300);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-200);
       }
    if(stageCount == 3550) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }
    if(stageCount == 3700) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 500);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 500);
       }
    if(stageCount == 3900) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(skel, nmesprites, LEFT, 800, 5);
       }
    if(stageCount == 4100) {
       dropnmesprite(skel, nmesprites, LEFT, 800, 200);
       }
    if(stageCount == 4200) {
       dropnmesprite(skel, nmesprites, LEFT, 800, 200);
       }
    if(stageCount == 4300) {
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, 200);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-400);
       }
    if(stageCount == 4600) {
       dropnmesprite(skel, nmesprites, DOWNLEFT, 600, -96);
       }

    if(stageCount == 4700) {
       dropnmesprite(skel, nmesprites, DOWN, 200, -128);
       }
    if(stageCount == 4750) {
       dropnmesprite(skel, nmesprites, DOWN, 300, -128);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-400);
       }
    if(stageCount == 4800) {
       dropnmesprite(skel, nmesprites, DOWN, 600, -128);
       }
    if(stageCount == 4850) {
       dropnmesprite(skel, nmesprites, DOWN, 500, -128);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-200);
       }
    if(stageCount == 4950) {
       dropnmesprite(skel, nmesprites, DOWN, 0, -128);
       }
    if(stageCount == 5100) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 0);
       dropnmesprite(birdhead, nmesprites, UPRIGHT, -128, 600);
       }

    if(stageCount == 5400) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 0);
       dropnmesprite(dumbufo, nmesprites, UPRIGHT, -128, 600);
       }
    if(stageCount == 5500) {
       dropnmesprite(dumbufo, nmesprites, DOWNLEFT, 800, 0);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -128, 200);
       }
    if(stageCount == 5600) {
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-400);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-300);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-200);
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 0);
       dropnmesprite(dumbufo, nmesprites, UPRIGHT, -128, 600);
       }
    if(stageCount == 5700) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 0);
       dropnmesprite(birdhead, nmesprites, UPRIGHT, -128, 600);
       }
    if(stageCount == 6000) {
       stageCount=205;
       level3ison= false;
       level3bossison= true;
       Mix_HaltMusic();
       Mix_PlayChannel(-1, audio.shieldsarelow, 0);
       Mix_PlayMusic(audio.lvl1boss, 0);
       }
    }
if (level3bossison) {
    stageCount++;
    if(stageCount == 5) {
       dropnmesprite(lifeicon, nmesprites, RIGHT, -64, 50);
       }
    if(stageCount == 200) {
       level4ison=true;
       level3bossison=false;    
       showbosshp=false;  
       stageCount=0;
       } 
          
    if(stageCount == 206) {
       dropnmesprite(shieldicon, nmesprites, RIGHT, -64, 50);
       }
       
    if(stageCount == 600) {
       dropnmesprite(lvl3boss, nmesprites, NOMOVEMENT, 800, -256);
       showbosshp=true;
       }
    }
    
if (level4ison) {
    stageCount++;
    if(stageCount == 1) {
      cutscene(app,3);
      Mix_PlayMusic(audio.lvl4mid, -1);
      }
    if(stageCount == 300) {
       dropclip(sun,clips,DOWN,550,-256);
       dropnmesprite(skel, nmesprites, LEFT, 800, 74);
       dropnmesprite(skel, nmesprites, LEFT, 910, 158);
       }       
    if(stageCount == 310) {
       dropclip(sun,clips,DOWN,100,-256);
       dropnmesprite(skel, nmesprites, RIGHT, -70, 20);
       dropnmesprite(skel, nmesprites, RIGHT, -140, 20);
       dropnmesprite(skel, nmesprites, RIGHT, -210, 20);
       }       
    if(stageCount == 410) {
       dropclip(sun,bottomclips,DOWN,200,-256);
       dropnmesprite(skel, nmesprites, RIGHT, -70, 20);
       dropnmesprite(skel, nmesprites, RIGHT, -140, 20);
       dropnmesprite(skel, nmesprites, RIGHT, -210, 20);
       }              
    if(stageCount == 510) {
       dropclip(fastcloud,bottomclips,DOWN,200,-256);
       dropnmesprite(skel, nmesprites, DOWNRIGHT, 400, -64);
       dropnmesprite(skel, nmesprites, DOWNLEFT, 400, -64);
       }              
    if(stageCount == 560) {
       dropclip(sun,bottomclips,DOWN,700,-256);
       dropnmesprite(skel, nmesprites, UP, 400, -64);
       }              
    if(stageCount == 600) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 0);
       dropnmesprite(birdhead, nmesprites, UPRIGHT, -128, 600);
       }
    if(stageCount == 700) {
       dropclip(fastcloud,bottomclips,DOWN,200,-256);
       dropnmesprite(birdhead, nmesprites, DOWNRIGHT, 400, -128);
       dropnmesprite(birdhead, nmesprites, DOWNLEFT, 400, -128);
       }              
    if(stageCount == 750) {
       dropclip(sun,clips,UP,350,600);
       dropnmesprite(skel, nmesprites, UP, 400, -64);
       }              
   if(stageCount == 850) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50); 
       }
    if(stageCount == 950) {
       dropnmesprite(skel, nmesprites, RIGHT, -70, 20);
       dropnmesprite(skel, nmesprites, RIGHT, -140, 20);
       dropnmesprite(skel, nmesprites, RIGHT, -210, 20);
       }              
    if(stageCount == 1050) {
       dropclip(cloud,clips,DOWN,500,-256);
       dropnmesprite(skel, nmesprites, RIGHT, -70, 150);
       dropnmesprite(skel, nmesprites, RIGHT, -140, 150);
       dropnmesprite(skel, nmesprites, RIGHT, -210, 150);
       }              
    if(stageCount == 1150) {
       dropclip(cloud,clips,DOWN,500,-256);
       dropnmesprite(skel, nmesprites, LEFT, 870, 450);
       dropnmesprite(skel, nmesprites, LEFT, 940, 450);
       dropnmesprite(skel, nmesprites, LEFT, 800, 450);
       }              
    if(stageCount == 1250) {
       dropclip(cloud,clips,DOWN,130,-256);
       dropnmesprite(skel, nmesprites, LEFT, 870, 5);
       dropnmesprite(skel, nmesprites, LEFT, 940, 10);
       dropnmesprite(skel, nmesprites, LEFT, 800, 15);
       }              
    if(stageCount == 1400) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 0);
       dropnmesprite(birdhead, nmesprites, DOWN, 680, -128);       
       }              
    if(stageCount == 1550) {
       dropnmesprite(birdhead, nmesprites, RIGHT, -128, 20);
       dropnmesprite(birdhead, nmesprites, UP, 0, 600);       
       }
    if(stageCount == 1575) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 0);
       dropnmesprite(birdhead, nmesprites, UPRIGHT, -128, 600);
       }
    if(stageCount == 1600) {
       dropclip(fastcloud,bottomclips,DOWN,200,-256);
       dropnmesprite(birdhead, nmesprites, DOWNRIGHT, 400, -128);
       dropnmesprite(birdhead, nmesprites, DOWNLEFT, 400, -128);
       }              
    if(stageCount == 1650) {
       dropclip(sun,clips,UP,350,600);
       dropnmesprite(skel, nmesprites, UP, 400, -64);
       }              
   if(stageCount == 1700) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50); 
       }
    if(stageCount == 1800) {
       dropnmesprite(skel, nmesprites, RIGHT, -70, 20);
       dropnmesprite(skel, nmesprites, RIGHT, -140, 20);
       dropnmesprite(skel, nmesprites, RIGHT, -210, 20);
       }              
    if(stageCount == 1850) {
       dropclip(cloud,clips,DOWN,500,-256);
       dropnmesprite(skel, nmesprites, RIGHT, -70, 150);
       dropnmesprite(skel, nmesprites, RIGHT, -140, 150);
       dropnmesprite(skel, nmesprites, RIGHT, -210, 150);
       }              
    if(stageCount == 1900) {
       dropclip(cloud,clips,DOWN,500,-256);
       dropnmesprite(skel, nmesprites, LEFT, 870, 450);
       dropnmesprite(skel, nmesprites, LEFT, 940, 450);
       dropnmesprite(skel, nmesprites, LEFT, 800, 450);
       }              
    if(stageCount == 1925) {
       dropclip(cloud,clips,DOWN,130,-256);
       dropnmesprite(skel, nmesprites, LEFT, 870, 5);
       dropnmesprite(skel, nmesprites, LEFT, 940, 10);
       dropnmesprite(skel, nmesprites, LEFT, 800, 15);
       }              
    if(stageCount == 1975) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 0);
       dropnmesprite(birdhead, nmesprites, DOWN, 680, -128);       
       }              
    if(stageCount == 2100) {
       dropnmesprite(birdhead, nmesprites, RIGHT, -128, 20);
       dropnmesprite(birdhead, nmesprites, UP, 0, 600);       
       }
    if(stageCount == 2150) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }

    if(stageCount == 2250) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 74);
       dropnmesprite(dumbufo, nmesprites, LEFT, 910, 158); 
       }

    if(stageCount == 2300) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(skel, nmesprites, LEFT, 800, 5);
       }

    if(stageCount == 2450) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 50);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 50); 
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-400);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-300);
      dropclip(fastcloud,bottomclips,DOWNRIGHT,0,-200);
       }
    if(stageCount == 2550) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, -200);
       }
    if(stageCount == 2650) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, -200);
       }       

    if(stageCount == 2750) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, -200);
       }

    if(stageCount == 2850) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, -200);
       }


    if(stageCount == 2950) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, -200);
       }

    if(stageCount == 3050) {
       dropnmesprite(skel, nmesprites, RIGHT, -70, 20);
       dropnmesprite(skel, nmesprites, RIGHT, -140, 20);
       dropnmesprite(skel, nmesprites, RIGHT, -210, 20);
       }              
    if(stageCount == 3150) {
       dropclip(cloud,clips,DOWN,500,-256);
       dropnmesprite(skel, nmesprites, RIGHT, -70, 150);
       dropnmesprite(skel, nmesprites, RIGHT, -140, 150);
       dropnmesprite(skel, nmesprites, RIGHT, -210, 150);
       }              
    if(stageCount == 3250) {
       dropclip(cloud,clips,DOWN,500,-256);
       dropnmesprite(skel, nmesprites, LEFT, 870, 450);
       dropnmesprite(skel, nmesprites, LEFT, 940, 450);
       dropnmesprite(skel, nmesprites, LEFT, 800, 450);
       }              
    if(stageCount == 3350) {
       dropclip(cloud,clips,DOWN,130,-256);
       dropnmesprite(skel, nmesprites, LEFT, 870, 5);
       dropnmesprite(skel, nmesprites, LEFT, 940, 10);
       dropnmesprite(skel, nmesprites, LEFT, 800, 15);
       }              
    if(stageCount == 3500) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 0);
       dropnmesprite(birdhead, nmesprites, DOWN, 680, -128);       
       }              
    if(stageCount == 3600) {
       dropnmesprite(birdhead, nmesprites, RIGHT, -128, 20);
       dropnmesprite(birdhead, nmesprites, UP, 0, 600);       
       }
    if(stageCount == 3700) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 0);
       dropnmesprite(birdhead, nmesprites, UPRIGHT, -128, 600);
       }
    if(stageCount == 3750) {
       dropclip(fastcloud,bottomclips,DOWN,200,-256);
       dropnmesprite(birdhead, nmesprites, DOWNRIGHT, 400, -128);
       dropnmesprite(birdhead, nmesprites, DOWNLEFT, 400, -128);
       }              
    if(stageCount == 3900) {
       dropclip(sun,clips,UP,350,600);
       dropnmesprite(skel, nmesprites, UP, 400, -64);
       }

    if(stageCount == 4000) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 74);
       dropnmesprite(dumbufo, nmesprites, LEFT, 910, 158);
       }       
    if(stageCount == 4100) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       
    if(stageCount == 4250) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }

    if(stageCount == 4300) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 74);
       dropnmesprite(dumbufo, nmesprites, LEFT, 910, 158); 
       }

    if(stageCount == 4400) {
       dropnmesprite(interceptor, nmesprites, LEFT, 800, -128);
       dropnmesprite(skel, nmesprites, LEFT, 800, 5);
       }

    if(stageCount == 4500) {
       dropnmesprite(interceptor, nmesprites, RIGHT, -128, -128);
       dropnmesprite(skel, nmesprites, UP, 100, 800);
       }

    if(stageCount == 4550) {
       dropnmesprite(skel, nmesprites, RIGHT, -96, 30);
       dropnmesprite(skel, nmesprites, UP, 400, 800);
       }
    if(stageCount == 4600) {
      dropclip(fastcloud,bottomclips,DOWN,300,-128);
       dropnmesprite(skel, nmesprites, LEFT, 800, 128);
       dropnmesprite(skel, nmesprites, RIGHT, -96, 30);
       }
    if(stageCount == 4700) {
       dropnmesprite(skel, nmesprites, DOWNLEFT, 400, -128);
       dropnmesprite(skel, nmesprites, DOWNRIGHT, 400, -128);
       dropnmesprite(skel, nmesprites, DOWN, 400, -128);
       }
    if(stageCount == 4800) {
       dropnmesprite(skel, nmesprites, DOWNLEFT, 400, -128);
       dropnmesprite(skel, nmesprites, DOWNRIGHT, 400, -128);
       dropnmesprite(skel, nmesprites, DOWN, 400, -128);
      dropclip(sun,clips,DOWN,400,-300);
      dropclip(sun,clips,DOWN,600,-300);
       }
    if(stageCount == 4900) {
       dropnmesprite(skel, nmesprites, DOWNLEFT, 400, -128);
       }
    if(stageCount == 5000) {
       dropnmesprite(dumbufo, nmesprites, LEFT, 800, 74);
       dropnmesprite(dumbufo, nmesprites, LEFT, 910, 158); 
       }
    if(stageCount == 5050) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, -200);
       }

    if(stageCount == 5100) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, -200);
       }


    if(stageCount == 5150) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       dropnmesprite(skel, nmesprites, DOWNLEFT, 800, -200);
       }

    if(stageCount == 5175) {
       dropnmesprite(skel, nmesprites, RIGHT, -70, 20);
       dropnmesprite(skel, nmesprites, RIGHT, -140, 20);
       dropnmesprite(skel, nmesprites, RIGHT, -210, 20);
       }              
    if(stageCount == 5200) {
       dropclip(sun,clips,DOWN,500,-256);
       dropnmesprite(skel, nmesprites, RIGHT, -70, 150);
       dropnmesprite(skel, nmesprites, RIGHT, -140, 150);
       dropnmesprite(skel, nmesprites, RIGHT, -210, 150);
       }              
    if(stageCount == 5300) {
       dropclip(cloud,clips,DOWN,500,-256);
       dropnmesprite(skel, nmesprites, LEFT, 870, 450);
       dropnmesprite(skel, nmesprites, LEFT, 940, 450);
       dropnmesprite(skel, nmesprites, LEFT, 800, 450);
       }              
    if(stageCount == 5350) {
       dropclip(cloud,clips,DOWN,130,-256);
       dropnmesprite(skel, nmesprites, LEFT, 870, 5);
       dropnmesprite(skel, nmesprites, LEFT, 940, 10);
       dropnmesprite(skel, nmesprites, LEFT, 800, 15);
       }  
    if(stageCount == 5450) {
       dropclip(cloud,clips,DOWN,500,-256);
       dropnmesprite(skel, nmesprites, LEFT, 870, 450);
       dropnmesprite(skel, nmesprites, LEFT, 940, 450);
       dropnmesprite(skel, nmesprites, LEFT, 800, 450);
       }              
    if(stageCount == 5550) {
       dropclip(cloud,clips,DOWN,130,-256);
       dropnmesprite(skel, nmesprites, LEFT, 870, 5);
       dropnmesprite(skel, nmesprites, LEFT, 940, 10);
       dropnmesprite(skel, nmesprites, LEFT, 800, 15);
       } 
    if(stageCount == 5650) {
       dropnmesprite(dumbufo, nmesprites, RIGHT, -70, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -140, 20);
       dropnmesprite(dumbufo, nmesprites, RIGHT, -210, 20);
       }       
    if(stageCount == 5700) {
       dropnmesprite(birdhead, nmesprites, LEFT, 800, 0);
       dropnmesprite(birdhead, nmesprites, UPRIGHT, -128, 600);
       }
    if(stageCount == 6000) {
       stageCount=205;
       level4ison= false;
       level4bossison= true;
       Mix_HaltMusic();
       Mix_PlayChannel(-1, audio.shieldsarelow, 0);
       Mix_PlayMusic(audio.lvl1boss, 0);
       }
    }

if (level4bossison) {
    stageCount++;
    if(stageCount == 5) {
       dropnmesprite(lifeicon, nmesprites, RIGHT, -64, 50);
       }
    if(stageCount == 200) {
       level1ison=true;
       level4bossison=false;    
       showbosshp=false;  
       stageCount=0;
       cutscene(app,4);
       } 
          
    if(stageCount == 206) {
       dropnmesprite(shieldicon, nmesprites, RIGHT, -64, 50);
       }

    if(stageCount == 600) {
       dropnmesprite(lvl4boss, nmesprites, NOMOVEMENT, 800, -256);
       showbosshp=true;
       }
    if(stageCount % 300 == 0) {
       dropnmesprite(birdhead, nmesprites, DOWN, 50, -64);
       }

    }
}
