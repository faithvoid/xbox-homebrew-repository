/*
    Hero's Of Roswell
    Copyright (C) 2003 Patrick Avella

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
struct nmesprite {
    int x, y, curframe, dir, h, w, hp, weapon, frames, shootdelay, shootcount;
    int movedelay, speed, animdelay, ai, sprite, brain, ammo;
    Uint32 lastmove, lastdrawn;
    };
    
void initnme (nmesprite *nme, int w, int h, int frames, int ai, int spd,
              int hp, int weapon, int anidelay,int sprite, int brain,
              int ammo, int shootdelay) {

    nme->x=0; nme->y=0; nme->curframe=0; nme->dir=0;
    nme->movedelay= 16; nme->lastmove= 0; nme->speed=spd; nme->lastdrawn=0;
    nme->hp= hp; nme->weapon= weapon; nme->ai= ai;
    nme->h=h; nme->w=w; nme->frames=frames;
    nme->animdelay= anidelay; nme->sprite=sprite; nme->brain= brain;
    nme->ammo=ammo; nme->shootdelay=shootdelay; nme->shootcount= 0;
    SDL_Rect dest;
    dest.x= nme->x; dest.y= nme->y; dest.h= nme->h; dest.w= nme->w;
    }    
   


void nmeshoot (nmesprite *nme, bullet *bullets) {
    SDL_Rect dest;
    dest.x = nme->x; dest.y = nme->y;
    int centernmex;
    int centernmey;
    int go= NOMOVEMENT;
    if (nme->brain == AI_SHOOTATPC || nme->brain == AI_SWINGDOWNSHOOT) {
        if(( (nme->x > (pc.x-nme->w)) && (nme->x < pc.x+pc.w) ) && (nme->y < pc.y) ) {
                go= DOWN; 
                centernmex= ( (nme->w/2) + nme->x );
                }
        if(( (nme->x > (pc.x-nme->w)) && (nme->x < pc.x+pc.w) ) && (nme->y > pc.y) ) {
                go= UP; 
                centernmex= ( (nme->w/2) + nme->x );
                }
        if(( (nme->y > (pc.y-nme->h)) && (nme->y < pc.y+pc.h) ) && (nme->x > pc.x)
                ) {
                go= LEFT; 
                centernmey= ( (nme->h/2) + nme->y );
                }                
        if(( (nme->y > (pc.y-nme->h)) && (nme->y < pc.y+pc.h) ) && (nme->x < pc.x)
                ) {
                go= RIGHT; 
                centernmey= ( (nme->h/2) + nme->y );
                }     
        }

    if (nme->brain == AI_LVL1BOSS) {
        dest.h= nme1bullet.h;  dest.w= nme1bullet.w;    
        centernmex= ( (nme->w/2) + nme->x );
        dest.x=centernmex-(nme1bullet.w/2); dest.y+= nme->h;
        shoot(nme1bullet, bullets, DOWN, dest.x, dest.y);
        shoot(nme1bullet, bullets, DOWNRIGHT, dest.x, dest.y);
        shoot(nme1bullet, bullets, DOWNLEFT, dest.x, dest.y);
        Mix_PlayChannel(-1, audio.smallbullet, 0);
        }
    if (nme->brain == AI_LVL2BOSS) {
        dest.h= nme1bullet.h;  dest.w= nme1bullet.w;    
        centernmex= ( (nme->w/2) + nme->x );
        dest.x=nme->x; dest.y= nme->y;
        shoot(nme1bullet, bullets, DOWN, dest.x+55, dest.y+125);
        shoot(nme1bullet, bullets, DOWN, dest.x+250, dest.y+125);
        shoot(nme1bullet, bullets, DOWNRIGHT, dest.x+150, dest.y+60);
        shoot(nme1bullet, bullets, DOWNLEFT, dest.x+150, dest.y+60);
        shoot(nme2bullet, bullets, DOWN, dest.x+150, dest.y+60);
        Mix_PlayChannel(-1, audio.largebullet, 0);
        }
    if (nme->brain == AI_LVL3BOSS) {
        dest.h= nme1bullet.h;  dest.w= nme1bullet.w;    
        centernmex= ( (nme->w/2) + nme->x );
        dest.x=nme->x; dest.y= nme->y;
        shoot(nme1bullet, bullets, DOWN, dest.x+248, dest.y);
        shoot(nme2bullet, bullets, DOWNRIGHT, dest.x-16, dest.y+256);
        shoot(nme2bullet, bullets, DOWNLEFT, dest.x+512, dest.y+256);
        Mix_PlayChannel(-1, audio.largebullet, 0);
        }
    if (nme->brain == AI_LVL4BOSS) {
        dest.h= nme1bullet.h;  dest.w= nme1bullet.w;    
        centernmex= ( (nme->w/2) + nme->x );
        dest.x=centernmex-(nme1bullet.w/2); dest.y+= nme->h;
        shoot(nme2bullet, bullets, DOWN, dest.x, dest.y);
        shoot(nme2bullet, bullets, DOWNRIGHT, dest.x, dest.y);
        shoot(nme2bullet, bullets, DOWNLEFT, dest.x, dest.y);
        Mix_PlayChannel(-1, audio.rocket, 0);
        }
    if (nme->weapon == NME1BULLET) {
        dest.h= nme1bullet.h;  dest.w= nme1bullet.w;
        if (go == DOWN) {
                dest.x=centernmex-(nme1bullet.w/2); dest.y+= nme->h;
                }
        if (go == UP) {
                dest.x=centernmex-(nme1bullet.w/2); dest.y-= nme1bullet.h;
                }                
        if (go == LEFT) {
                dest.y=centernmey-(nme1bullet.h/2); dest.x-= nme1bullet.w;
                }   
        if (go == RIGHT) {
                dest.y=centernmey-(nme1bullet.h/2); dest.x+= nme->w;
                }   
        shoot(nme1bullet, bullets, go, dest.x, dest.y);
        Mix_PlayChannel(-1, audio.smallbullet, 0);
       }
    if (nme->weapon == NME2BULLET) {
        dest.h= nme2bullet.h;  dest.w= nme2bullet.w;
        if (go == DOWN) {
                dest.x=centernmex-(nme2bullet.w/2); dest.y+= nme->h;
                }
        if (go == UP) {
                dest.x=centernmex-(nme2bullet.w/2); dest.y-= nme2bullet.h;
                }
        if (go == LEFT) {
                dest.y=centernmey-(nme2bullet.h/2); dest.x-= nme2bullet.w;
                }   
        if (go == RIGHT) {
                dest.y=centernmey-(nme2bullet.h/2); dest.x+= nme->w;
                }   
        shoot(nme2bullet, bullets, go, dest.x, dest.y);
        Mix_PlayChannel(-1, audio.largebullet, 0);
       }
    }


void movenme (nmesprite *nme, pcstruct *pc, bullet *blt) {
    for (int j=0; j < 32; j++) {
        if ( nme[j].hp !=0 ) {
                for (int i=0; i < 32; i++) {
                    if ((blt[i].x > nme[j].x - blt[i].w) 
                     && (blt[i].x < nme[j].x + nme[j].w) 
                     && (blt[i].y > nme[j].y - blt[j].h) 
                     && (blt[i].y < nme[j].y + nme[j].h)
                     && blt[i].ai != NOMOVEMENT ) {
                       Uint8 r,g,b,r2,g2,b2;
                       int x1a,x2a;
                       SDL_Surface *spritebuf;
                       spritebuf= getSprite(nme[j].sprite);
                       x1a= blt[i].x - nme[j].x;
                       x2a= (blt[i].x+blt[i].w)-nme[j].x;
                       if ( (x1a > -1) || (x2a > -1) ) {
                       Uint32 pix1= getpixel(spritebuf, x1a, (blt[i].y+(blt[i].h/2))-nme[j].y);
                       Uint32 pix2= getpixel(spritebuf, x2a, (blt[i].y+(blt[i].h/2))-nme[j].y);
                       SDL_GetRGB(pix1,spritebuf->format, &r,&g,&b);
                       SDL_GetRGB(pix2,spritebuf->format, &r2,&g2,&b2);
                       if( !(((r==0)&&(g==0)&&(b==0)) || ((r2==0)&&(g2==0)&&(b2==0))) ) {
                          if(blt[i].sprite == LVL1BULLET) {
                             nme[j].hp-=1;
                             dropclip(explosion16,clips,NOMOVEMENT,blt[i].x,blt[i].y);
                             Mix_PlayChannel(-1, audio.exp16, 0);
                             blt[i].ai= NOMOVEMENT;
                             }
                          if(blt[i].sprite == LVL2BULLET) {
                             nme[j].hp-=2;
                             dropclip(explosion16,clips,NOMOVEMENT,blt[i].x-8,blt[i].y);
                             dropclip(explosion16,clips,NOMOVEMENT,blt[i].x+8,blt[i].y);
                             Mix_PlayChannel(-1, audio.exp16, 0);
                             blt[i].ai= NOMOVEMENT;
                             }
                          if(blt[i].sprite == LVL3BULLET) {
                             nme[j].hp-=3;
                             dropclip(explosion16,clips,NOMOVEMENT,blt[i].x,blt[i].y);
                             Mix_PlayChannel(-1, audio.exp16, 0);
                             blt[i].ai= NOMOVEMENT;
                             }
                          if(blt[i].sprite == LVL4BULLET) {
                             nme[j].hp-=5;
                             dropclip(explosion64,clips,UP,blt[i].x-8,blt[i].y);
                             dropclip(explosion64,clips,UP,blt[i].x+8,blt[i].y);
                             Mix_PlayChannel(-1, audio.exp16, 0);
                             blt[i].ai= NOMOVEMENT;
                             }
                         }
                       }
                       }  
                     }
                if (nme[j].ai == DOWN) {
                     nme[j].y+=nme[j].speed;
                     }
                if (nme[j].ai == UP) {
                     nme[j].y-=nme[j].speed;
                     }
                if (nme[j].ai == LEFT) {
                     nme[j].x-=nme[j].speed;
                     }
                if (nme[j].ai == RIGHT) {
                     nme[j].x+=nme[j].speed;
                     }
                if (nme[j].ai == UPRIGHT) {
                     nme[j].x+=nme[j].speed;
                     nme[j].y-=nme[j].speed;
                     }                     
                if (nme[j].ai == DOWNRIGHT) {
                     nme[j].x+=nme[j].speed;
                     nme[j].y+=nme[j].speed;
                     }
                if (nme[j].ai == UPLEFT) {
                     nme[j].x-=nme[j].speed;
                     nme[j].y-=nme[j].speed;
                     }
                if (nme[j].ai == DOWNLEFT) {
                     nme[j].x-=nme[j].speed;
                     nme[j].y+=nme[j].speed;
                     }
                if ((nme[j].hp < 1) && (nme[j].sprite == NME_UFO)) {
                                nme[j].hp= 0;
                                dropclip(explosion64,clips,DOWN,nme[j].x,nme[j].y);
                                pc->killcount++;
                                pc->score++;
                                Mix_PlayChannel(-1, audio.exp64, 0);
                                }
                if ((nme[j].hp < 1) && (nme[j].sprite == NME_SKEL)) {
                                nme[j].hp= 0;
                                dropclip(explosion64,clips,DOWN,nme[j].x,nme[j].y);
                                dropclip(explosion64,clips,DOWN,nme[j].x+32,nme[j].y);
                                pc->killcount+=5;
                                pc->score++;
                                Mix_PlayChannel(-1, audio.exp64, 0);
                                }
                if ((nme[j].hp < 1) && (nme[j].sprite == NME_BIRDHEAD)) {
                                nme[j].hp= 0;
                                dropclip(explosion64,clips,DOWN,nme[j].x,nme[j].y);
                                dropclip(explosion64,clips,DOWN,nme[j].x+64,nme[j].y);
                                pc->killcount+=2;
                                pc->score++;
                                Mix_PlayChannel(-1, audio.exp64, 0);
                                }
                if ((nme[j].hp < 1) && (nme[j].sprite == NME_INTERCEPTOR)) {
                                nme[j].hp= 0;
                                dropclip(explosion64,clips,DOWN,nme[j].x,nme[j].y);
                                dropclip(explosion64,clips,UP,nme[j].x+32,nme[j].y);
                                dropclip(explosion64,clips,DOWN,nme[j].x+64,nme[j].y);
                                pc->killcount+=3;
                                pc->score++;
                                Mix_PlayChannel(-1, audio.exp64, 0);
                                }                                
                if ((nme[j].hp < 1) && (nme[j].sprite == SPEEDICON)) {
                                nme[j].hp= 0;
                                if(pc->speed < pc->maxspeed) {                               
                                   bg.speed+=4;
                                   pc->speed+=4;
                                   pc->animdelay-=15;
                                   Mix_PlayChannel(-1, audio.speedup, 0);
                                   dropclip(explosion64,clips,DOWN,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,LEFT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,RIGHT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,UP,nme[j].x,nme[j].y);
                                   dropclip(speedup,clips,RIGHT,-512,200);
                                   dropclip(absorb,clips,NOMOVEMENT,pc->x,pc->y);
                                   }
                                }
                if ((nme[j].hp < 1) && ((nme[j].sprite == WEAPONICON)||(nme[j].sprite == MARS))) {
                                nme[j].hp= 0;
                                if(pc->weapon == LVL4BULLET) {                               
                                   pc->weapon= LVL5BULLET;
                                   Mix_PlayChannel(-1, audio.absorb, 0);
                                   dropclip(explosion64,clips,DOWN,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,LEFT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,RIGHT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,UP,nme[j].x,nme[j].y);
                                   dropclip(absorb,clips,NOMOVEMENT,pc->x,pc->y);
                                   }
                                if(pc->weapon == LVL3BULLET) {                               
                                   pc->weapon= LVL4BULLET;
                                   Mix_PlayChannel(-1, audio.absorb, 0);
                                   dropclip(explosion64,clips,DOWN,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,LEFT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,RIGHT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,UP,nme[j].x,nme[j].y);
                                   dropclip(absorb,clips,NOMOVEMENT,pc->x,pc->y);
                                   }
                                if(pc->weapon == LVL2BULLET) {                               
                                   pc->weapon= LVL3BULLET;
                                   Mix_PlayChannel(-1, audio.absorb, 0);
                                   dropclip(explosion64,clips,DOWN,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,LEFT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,RIGHT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,UP,nme[j].x,nme[j].y);
                                   dropclip(absorb,clips,NOMOVEMENT,pc->x,pc->y);
                                   }
                                if(pc->weapon == LVL1BULLET) {                               
                                   pc->weapon= LVL2BULLET;
                                   Mix_PlayChannel(-1, audio.absorb, 0);
                                   dropclip(explosion64,clips,DOWN,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,LEFT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,RIGHT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,UP,nme[j].x,nme[j].y);
                                   dropclip(absorb,clips,NOMOVEMENT,pc->x,pc->y);
                                   }
                                }
                if ((nme[j].hp < 1) && (nme[j].sprite == LIFEICON)) {
                                nme[j].hp= 0;
                                   pc->lives++;
                                   Mix_PlayChannel(-1, audio.absorb, 0);
                                   dropclip(explosion64,clips,DOWN,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,LEFT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,RIGHT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,UP,nme[j].x,nme[j].y);
                                   dropclip(absorb,clips,NOMOVEMENT,pc->x,pc->y);
                                
                                }
                if ((nme[j].hp < 1) && (nme[j].sprite == SHIELDICON)) {
                                nme[j].hp= 0;
                                if (pc->hp < 5) {
                                   pc->hp=5;
                                   Mix_PlayChannel(-1, audio.hpup, 0);
                                   dropclip(explosion64,clips,DOWN,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,LEFT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,RIGHT,nme[j].x,nme[j].y);
                                   dropclip(explosion64,clips,UP,nme[j].x,nme[j].y);
                                   dropclip(absorb,clips,NOMOVEMENT,pc->x,pc->y);
                                   }
                                }
                if ((nme[j].hp < 1) && (nme[j].sprite == LVL1BOSS)) {
                                nme[j].hp= 0;
                                dropclip(explosion64,clips,DOWN,nme[j].x+100,nme[j].y+240);
                                dropclip(explosion64,clips,DOWN,nme[j].x+400,nme[j].y+180);
                                dropclip(explosion64,clips,RIGHT,nme[j].x+260,nme[j].y+200);
                                dropclip(explosion64,clips,DOWN,nme[j].x+300,nme[j].y+230);
                                dropclip(explosion64,clips,DOWN,nme[j].x+50,nme[j].y+50);
                                dropclip(explosion64,clips,LEFT,nme[j].x+250,nme[j].y+290);
                                stageCount=0;
                                pc->score++;
                                Mix_HaltMusic();
                                Mix_PlayChannel(-1, audio.exp64, 0);
                                }
                if ((nme[j].hp < 1) && (nme[j].sprite == LVL2BOSS)) {
                                nme[j].hp= 0;
                                dropclip(explosion64,clips,DOWN,nme[j].x+100,nme[j].y+240);
                                dropclip(explosion64,clips,DOWN,nme[j].x+400,nme[j].y+180);
                                dropclip(explosion64,clips,RIGHT,nme[j].x+260,nme[j].y+200);
                                dropclip(explosion64,clips,DOWN,nme[j].x+300,nme[j].y+230);
                                dropclip(explosion64,clips,DOWN,nme[j].x+50,nme[j].y+50);
                                dropclip(explosion64,clips,LEFT,nme[j].x+250,nme[j].y+290);
                                stageCount=0;
                                pc->score++;
                                Mix_HaltMusic();
                                Mix_PlayChannel(-1, audio.exp64, 0);
                                }
                if ((nme[j].hp < 1) && (nme[j].sprite == LVL3BOSS)) {
                                nme[j].hp= 0;
                                dropclip(explosion64,clips,DOWN,nme[j].x+100,nme[j].y+240);
                                dropclip(explosion64,clips,DOWN,nme[j].x+400,nme[j].y+180);
                                dropclip(explosion64,clips,RIGHT,nme[j].x+260,nme[j].y+200);
                                dropclip(explosion64,clips,DOWN,nme[j].x+300,nme[j].y+230);
                                dropclip(explosion64,clips,DOWN,nme[j].x+50,nme[j].y+50);
                                dropclip(explosion64,clips,LEFT,nme[j].x+250,nme[j].y+290);
                                stageCount=0;
                                pc->score++;
                                Mix_HaltMusic();
                                Mix_PlayChannel(-1, audio.exp64, 0);
                                }
                if ((nme[j].hp < 1) && (nme[j].sprite == LVL4BOSS)) {
                                nme[j].hp= 0;
                                dropclip(explosion64,clips,DOWN,nme[j].x+100,nme[j].y+240);
                                dropclip(explosion64,clips,DOWN,nme[j].x+400,nme[j].y+180);
                                dropclip(explosion64,clips,RIGHT,nme[j].x+260,nme[j].y+200);
                                dropclip(explosion64,clips,DOWN,nme[j].x+300,nme[j].y+230);
                                dropclip(explosion64,clips,DOWN,nme[j].x+50,nme[j].y+50);
                                dropclip(explosion64,clips,LEFT,nme[j].x+250,nme[j].y+290);
                                stageCount=0;
                                Mix_HaltMusic();
                                Mix_PlayChannel(-1, audio.exp64, 0);
                                }                                
                if (nme[j].y > 1000) nme[j].hp= 0;
                if (nme[j].x > 1000) nme[j].hp= 0;
                if (nme[j].y < -600-nme[j].h) nme[j].hp= 0;
                if (nme[j].x < -600-nme[j].w) nme[j].hp= 0;
                
                if( (nme[j].brain==AI_SHOOTATPC) &&
                   (nme[j].x > (pc->x-nme[j].w)) && (nme[j].x < pc->x+pc->w) ) {
                     if(nme[j].ammo > 0 && nme[j].shootdelay==nme[j].shootcount) {
                           nmeshoot(&nme[j], bullets);
                           nme[j].ammo--;
                           }
                     }
                if( (nme[j].brain==AI_SHOOTATPC) &&
                   (nme[j].y > (pc->y-nme[j].h)) && (nme[j].y < pc->y+pc->h) ) {
                     if(nme[j].ammo > 0 && nme[j].shootdelay==nme[j].shootcount) {
                           nmeshoot(&nme[j], bullets);
                           nme[j].ammo--;
                           }
                     }

                if( (nme[j].brain==AI_LVL1BOSS) ) {
                     if(pc->hp>0){
                         if ((nme[j].y+nme[j].h)>pc->y-96) nme[j].y-=8;
                         if ((nme[j].y+nme[j].h)<pc->y-96) nme[j].y+=2;                             
                         if ((nme[j].x+(nme[j].w/2))<pc->x+(pc->w/2)) nme[j].x+=8;
                         if ((nme[j].x+(nme[j].w/2))>pc->x+(pc->w/2)) nme[j].x-=8;
                         if(nme[j].shootdelay==nme[j].shootcount) {
                            nmeshoot(&nme[j], bullets);
                            nme[j].ammo--;
                            }
                         thebosshp= nme[j].hp;
                         }
                     if(pc->hp<1){
                         if (nme[j].y > 0) nme[j].y-=8;
                         if (nme[j].x<128) nme[j].x+=2;
                         if (nme[j].x>128) nme[j].x-=2;
                         }
                     }
                if( (nme[j].brain==AI_LVL2BOSS) ) {
                     if(pc->hp>0){
                         if ((nme[j].y+nme[j].h)>pc->y-96) nme[j].y-=6;
                         if ((nme[j].y+nme[j].h)<pc->y-96) nme[j].y+=6;                             
                         if ((nme[j].x+155)<pc->x+(pc->w/2)) nme[j].x+=4;
                         if ((nme[j].x+155)>pc->x+(pc->w/2)) nme[j].x-=4;
                         if(nme[j].shootdelay==nme[j].shootcount) {
                            nmeshoot(&nme[j], bullets);
                            }
                         thebosshp= nme[j].hp;
                         }
                     if(pc->hp<1){
                         if (nme[j].y > 0) nme[j].y-=8;
                         if (nme[j].x<128) nme[j].x+=2;
                         if (nme[j].x>128) nme[j].x-=2;
                         }
                     }
                if( (nme[j].brain==AI_LVL3BOSS) ) {
                     if(pc->hp>0){
                         if ((nme[j].y+nme[j].h)>pc->y-128) nme[j].y-=6;
                         if ((nme[j].y+nme[j].h)<pc->y-128) nme[j].y+=6;                             
                         if ((nme[j].x+(nme[j].w/2))<pc->x+(pc->w/2)) nme[j].x+=6;
                         if ((nme[j].x+(nme[j].w/2))>pc->x+(pc->w/2)) nme[j].x-=6;
                         if(nme[j].shootdelay==nme[j].shootcount) {
                            nmeshoot(&nme[j], bullets);
                            }
                         thebosshp= nme[j].hp;
                         }
                     if(pc->hp<1){
                         if (nme[j].y > -10) nme[j].y-=16;
                         if (nme[j].x<128) nme[j].x+=2;
                         if (nme[j].x>128) nme[j].x-=2;
                         }
                     }                     
                if( (nme[j].brain==AI_LVL4BOSS) ) {
                     if(pc->hp>0){
                         if ((nme[j].y+nme[j].h)>pc->y-96) nme[j].y-=10;
                         if ((nme[j].y+nme[j].h)<pc->y-96) nme[j].y+=10;                             
                         if ((nme[j].x+(nme[j].w/2))<pc->x+(pc->w/2)) nme[j].x+=10;
                         if ((nme[j].x+(nme[j].w/2))>pc->x+(pc->w/2)) nme[j].x-=10;
                         if(nme[j].shootdelay==nme[j].shootcount) {
                            nmeshoot(&nme[j], bullets);
                            }
                         thebosshp= nme[j].hp;
                         }
                     if(pc->hp<1){
                         if (nme[j].y > 0) nme[j].y-=8;
                         if (nme[j].x<128) nme[j].x+=2;
                         if (nme[j].x>128) nme[j].x-=2;
                         }
                     }
                         
                if( (nme[j].brain==AI_SWINGDOWN) ) {
                     if(nme[j].ai == RIGHT) {
                         nme[j].y+=1;
                         if(nme[j].x > 700) nme[j].ai= LEFT;
                         }
                     if(nme[j].ai == LEFT) {
                         nme[j].y+=1;
                         if(nme[j].x < 100) nme[j].ai= RIGHT;
                         }
                     }
                if( (nme[j].brain==AI_SWINGDOWNSHOOT) ) {
                     if(nme[j].ai == RIGHT) {
                         nme[j].y+=1;
                         if(nme[j].x > 672) nme[j].ai= LEFT;
                         }
                     if(nme[j].ai == LEFT) {
                         nme[j].y+=1;
                         if(nme[j].x < 10) nme[j].ai= RIGHT;
                         }
                     if((nme[j].shootdelay==nme[j].shootcount) && (nme[j].ammo > 0)
                     && (nme[j].x > (pc->x-nme[j].w)) && (nme[j].x < pc->x+pc->w) ) {
                         nmeshoot(&nme[j], bullets);
                         nme[j].ammo--;
                         }
                     }
                     
                nme[j].shootcount++;
                if (nme[j].shootcount > nme[j].shootdelay) { nme[j].shootcount=0; }
            }
        }
    }
     
      
       
        
         
          
void drawnmesprites (nmesprite *cur, SDL_Surface *app) {
    for (int j=0; j < 32; j++) {
        if ( cur[j].hp > 0 ) {
            SDL_Rect dest;
            dest.x= cur[j].x; dest.y= cur[j].y;
            dest.w= cur[j].w; dest.h= cur[j].h;
            SDL_Rect src;
            src.x= 0; src.y= 0;
            src.w= cur[j].w; src.h= cur[j].h;

            if (cur[j].sprite == NME_UFO) {
                SDL_BlitSurface(cast.ufo[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == NME_BIRDHEAD) {
                SDL_BlitSurface(cast.birdhead[cur[j].curframe], &src, app, &dest);
                }      
            if (cur[j].sprite == NME_INTERCEPTOR) {
                SDL_BlitSurface(cast.interceptor[cur[j].curframe], &src, app, &dest);
                }                      
            if (cur[j].sprite == NME_SKEL) {
                SDL_BlitSurface(cast.skel[cur[j].curframe], &src, app, &dest);
                }      
            if (cur[j].sprite == SPEEDICON) {
                SDL_BlitSurface(cast.speedicon[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == WEAPONICON) {
                SDL_BlitSurface(cast.weaponicon[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == SHIELDICON) {
                SDL_BlitSurface(cast.shieldicon[cur[j].curframe], &src, app, &dest);
                }
            if (cur[j].sprite == LIFEICON) {
                SDL_BlitSurface(cast.lifeicon[cur[j].curframe], &src, app, &dest);
                }                
            if (cur[j].sprite == MARS) {
                SDL_BlitSurface(cast.mars[cur[j].curframe], &src, app, &dest);
                }
                
            if (cur[j].sprite == LVL1BOSS) {
                SDL_BlitSurface(cast.lvl1boss[cur[j].curframe], &src, app, &dest);
                }                
            if (cur[j].sprite == LVL2BOSS) {
                SDL_BlitSurface(cast.lvl2boss[cur[j].curframe], &src, app, &dest);
                }    
            if (cur[j].sprite == LVL3BOSS) {
                SDL_BlitSurface(cast.lvl3boss[cur[j].curframe], &src, app, &dest);
                }    
            if (cur[j].sprite == LVL4BOSS) {
                SDL_BlitSurface(cast.lvl4boss[cur[j].curframe], &src, app, &dest);
                }    

            if( SDL_GetTicks() - cur[j].lastdrawn > cur[j].animdelay) {
                cur[j].curframe++;
                cur[j].lastdrawn= SDL_GetTicks();
                }
            if( cur[j].curframe == cur[j].frames ) cur[j].curframe=0;
            }
        }
    }           
            
void dropnmesprite (nmesprite sprite, nmesprite *cur, int ai,
                                         int sx, int sy) {
    for (int j= 0; j < 32; j++) {
        if ( cur[j].hp == 0 ) {
            cur[j]= sprite;
            cur[j].y= sy; cur[j].x= sx;
            cur[j].ai= ai;
            cur[j].lastdrawn= SDL_GetTicks();
            return;
            }
        }
    }



nmesprite dumbufo;
nmesprite birdhead;
nmesprite interceptor;
nmesprite skel;
nmesprite lvl1boss;
nmesprite lvl2boss;
nmesprite lvl3boss;
nmesprite lvl4boss;
nmesprite speedicon;
nmesprite lifeicon;
nmesprite shieldicon;
nmesprite weaponicon;
nmesprite marsicon;
nmesprite nmesprites[32];
             
               
