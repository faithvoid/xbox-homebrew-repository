/*
    Hero's Of Roswell
    Copyright (C) 2003 Patrick Avella

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

extern SDL_Joystick *GAMEPAD;
extern Sint16 joyx, joyy; //axes
extern Sint16 blackbutton;
extern Sint16 abutton; //A button
extern Sint16 bbutton;
extern Sint16 xbutton;
extern Sint16 ybutton;
extern Sint16 backbutton; //BACK button
extern Sint16 startbutton; //START button
extern Sint16 rstick; 
extern Sint16 dpad; //dpad
extern Sint16 ltrigger, rtrigger; //Trigger buttons









void titlescreen(SDL_Surface *app) {
    bool running= true;
    
    SDL_Surface *titlescreen= SDL_LoadBMP("d:\\bmp\\titlescreen.bmp");
    SDL_Surface *buf, *cursor;
    
    buf= SDL_LoadBMP("d:\\bmp\\cursor.bmp");
    cursor= SDL_DisplayFormat(buf);
    SDL_SetColorKey(cursor, SDL_SRCCOLORKEY, SDL_MapRGB(
        cursor->format, 0, 0, 0) );
    SDL_FreeSurface(buf);

    SDL_Surface *easy= SDL_LoadBMP("d:\\bmp\\easy.bmp");
    SDL_Surface *medium= SDL_LoadBMP("d:\\bmp\\normal.bmp");
    SDL_Surface *hard= SDL_LoadBMP("d:\\bmp\\hard.bmp");

    SDL_Rect difpos;
    difpos.x=685; difpos.y=444; difpos.h=47; difpos.w=88;
    difficulty= MEDIUM;
    
    SDL_Rect curpos;
    curpos.x= 525-64; curpos.w= 64;
    curpos.y= 325; curpos.h= 64;
    int curdest= 302;

    Mix_PlayMusic(audio.titlemusic, -1);
    
    while (running) {
         SDL_Event event;
		 SDL_PumpEvents();
	SDL_JoystickUpdate(); //manual refresh of the gamepad(s)
	//parse all gamepads
	joyx = SDL_JoystickGetAxis(GAMEPAD, 0);
	joyy = SDL_JoystickGetAxis(GAMEPAD, 1);
	dpad = SDL_JoystickGetHat(GAMEPAD, 0);
	blackbutton = SDL_JoystickGetButton(GAMEPAD, 4); //Black Button
	abutton = SDL_JoystickGetButton(GAMEPAD, 0); //Get A-Button(0)
	bbutton = SDL_JoystickGetButton(GAMEPAD, 1);
	backbutton = SDL_JoystickGetButton(GAMEPAD, 9); //Get BACK-Button(9)
	rstick = SDL_JoystickGetButton(GAMEPAD,11);
	ltrigger = SDL_JoystickGetButton(GAMEPAD,6);
	rtrigger = SDL_JoystickGetButton(GAMEPAD,7);
	xbutton = SDL_JoystickGetButton(GAMEPAD,2);
	ybutton = SDL_JoystickGetButton(GAMEPAD,3);
	startbutton = SDL_JoystickGetButton(GAMEPAD,8);


	event.type = SDL_KEYUP;


	if(dpad == SDL_HAT_DOWN || joyy > 3200){
		event.type = SDL_KEYDOWN;
		event.key.keysym.sym = SDLK_DOWN;
	}

	if(dpad == SDL_HAT_UP || joyy < -3200){
		event.type = SDL_KEYDOWN;
		event.key.keysym.sym = SDLK_UP;
	}

	if(abutton){
		event.type = SDL_KEYDOWN;
		event.key.keysym.sym = SDLK_LCTRL;
	}

	if(blackbutton){
		event.type = SDL_QUIT;
	}

	SDL_Delay(100);





		 //while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) { XLaunchNewImage(NULL, (LAUNCH_DATA*)&LaunchData ); }
            if (event.type == SDL_KEYDOWN) {
                if (event.key.keysym.sym == SDLK_UP) {
                    if(curdest==367) { 
                       curdest=302;
                       Mix_PlayChannel(-1, audio.beep, 0);
                       }
                    if(curdest==435) { 
                       curdest=367;
                       Mix_PlayChannel(-1, audio.beep, 0);
                       }
                    if(curdest==498) { 
                       curdest=435;
                       Mix_PlayChannel(-1, audio.beep, 0);
                       }

                    }
                if (event.key.keysym.sym == SDLK_DOWN) {
                    if(curdest==435) { 
                       curdest=498;
                       Mix_PlayChannel(-1, audio.beep, 0);
                       }
                    if(curdest==367) { 
                       curdest=435;
                       Mix_PlayChannel(-1, audio.beep, 0);
                       }
                    if(curdest==302) { 
                       curdest=367;
                       Mix_PlayChannel(-1, audio.beep, 0);
                       }
                       
                    }
                if (event.key.keysym.sym == SDLK_LCTRL) {
                    if(curdest==302) running=false;
                    if(curdest==367) {running=false;continuelevel=true;}
                    if(curdest==498) XLaunchNewImage(NULL, (LAUNCH_DATA*)&LaunchData );
                    if(curdest==435) {
                           if(difficulty<4) { difficulty++; }
                           if(difficulty>3) { difficulty=1; }
                           Mix_PlayChannel(-1, audio.beep, 0);
                           }
                    }

                }
            //}       
         if (curpos.y < curdest || curpos.y > curdest) { curpos.y=curdest; }

         SDL_BlitSurface(titlescreen,NULL,app,NULL);
         SDL_BlitSurface(cursor, NULL, app, &curpos);

         if(difficulty==MEDIUM) { SDL_BlitSurface(medium, NULL, app, &difpos); }
         if(difficulty==EASY) { SDL_BlitSurface(easy, NULL, app, &difpos); }
         if(difficulty==HARD) { SDL_BlitSurface(hard, NULL, app, &difpos); }

         SDL_Flip(app);
         }

       SDL_FreeSurface(cursor);
       SDL_FreeSurface(titlescreen);
       return;
       }  

                                                               
