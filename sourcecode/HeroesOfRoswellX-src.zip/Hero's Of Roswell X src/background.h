/*
    Hero's Of Roswell
    Copyright (C) 2003 Patrick Avella

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
struct bottomlayer {
    int delay;
    int offset;
    int speed;
    Uint32 lastdrawn;
    };


void initbottomlayer (bottomlayer *bg) {
    bg->delay= 32;
    bg->offset= 0;
    bg->speed=  8;
    bg->lastdrawn= 0;
    }
    
    
void drawbottom(SDL_Surface *app, bottomlayer *bottom) {
//  tt= SDL_LoadBMP(tile);
    SDL_Rect td;
    td.w=256; td.h=256;


    for (int i=0; i < 4; i++) {
        for (int j=0; j < 7; j++) {
            td.x= 256*j; td.y= ((256*i)-256)+bottom->offset;
            if (level1ison) SDL_BlitSurface(cast.rural, NULL, app, &td);
            if (level1bossison) SDL_BlitSurface(cast.rural2, NULL, app, &td);
            if (level2ison) SDL_BlitSurface(cast.starbg, NULL, app, &td);
            if (level2bossison) SDL_BlitSurface(cast.lvl1bossbg, NULL, app, &td);
            if (level3ison) SDL_BlitSurface(cast.water, NULL, app, &td);
            if (level3bossison) SDL_BlitSurface(cast.water2, NULL, app, &td);
            if (level4ison) SDL_BlitSurface(cast.sand, NULL, app, &td);
            if (level4bossison) SDL_BlitSurface(cast.sand2, NULL, app, &td);
            }
        }

        bottom->offset= bottom->offset + bottom->speed;
        if(bottom->offset >= 256) { bottom->offset-=256; }
        
    }
    
bottomlayer bg;
  
