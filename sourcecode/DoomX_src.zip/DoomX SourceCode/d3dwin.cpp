// Standard Xbox headers
#include <xtl.h>
#include <XGraphics.h>

#define GAME_START  0
#define GAME_SPLASH 1
#define GAME_MENU   2
#define GAME_PLAY   3
#define GAME_EXIT   4
#define GAME_QUIT   5
#define GAME_LIMBO  6
#define GAME_PAUSE  7

extern "C" 
{
	#include "Windoom.h"
	#include "d3dWin.h"
	#include "doomdef.h"
	#include "doomstat.h"
	#include "d_event.h"
	#include "d_main.h"
	#include "m_argv.h"
	#include "g_game.h"
	#include "i_system.h"
}


extern int verbose;

extern LPDIRECT3DDEVICE8 g_pd3dDevice;

static LPDIRECT3DTEXTURE8	Texture;
static LPD3DXSPRITE			Sprite;
static byte*				g_pBlitBuff = NULL;
extern "C" int GameMode;
extern "C" byte *screens[5];
extern "C" void WriteDebug(const char *name);

int init_texture(int Width, int Height)
{
	if (Texture) 
	{ 
		Texture->Release();
		Texture = NULL;
	}
	
	// Create the texture
	D3DXCreateTexture(g_pd3dDevice, Width, Height, 0, 0, D3DFMT_X8R8G8B8, D3DPOOL_DEFAULT, &Texture);
	
	D3DSURFACE_DESC desc;
    Texture->GetLevelDesc(0, &desc);

	if (g_pBlitBuff != NULL)
	{
		delete [] g_pBlitBuff;
		g_pBlitBuff = NULL;
	}
	
	// Allocate a buffer to blit our frames to
	g_pBlitBuff = new byte[desc.Size];

	D3DXCreateSprite(g_pd3dDevice, &Sprite);

	return 0;
}

void shutdown_texture(void)
{		
	if (Texture != NULL)
	{
		Texture->Release();
		Texture = NULL;
	}

	if (Sprite != NULL)
	{
		Sprite->Release();
		Sprite = NULL;
	}

	// Delete our blit buffer
	if (g_pBlitBuff != NULL)
	{
		delete [] g_pBlitBuff;
		g_pBlitBuff = NULL;
	}
	
}

void RenderD3D()
{	
	static int    i, j, x, y, dwsw, pad;
     
    byte *Buff = NULL, *Scrn = NULL;

	RECT srcRect;
	
	srcRect.top = 0;
	srcRect.left = 0;
	srcRect.right = SCREENWIDTH;
	srcRect.bottom = SCREENHEIGHT;

   if (GameMode != GAME_PLAY)
		return;

	Scrn = (byte*)screens[0];
    

	D3DSURFACE_DESC desc;
    Texture->GetLevelDesc(0, &desc);

	// Lock the rect in our texture
	
	D3DLOCKED_RECT d3dlr;

	Texture->LockRect(0, &d3dlr, &srcRect, 0);


	DWORD pixelcolor = 0;
	unsigned char pixel[4] ;
	DWORD red, green, blue;
	byte *bitptr = NULL;
	bitptr = g_pBlitBuff;

	for( int y = 0 ; y < SCREENHEIGHT ; y++ )
	{
		bitptr = ((byte*)g_pBlitBuff) + ( y*(d3dlr.Pitch) ) ;

		for( int x = 0 ; x < SCREENWIDTH ; x++ )
		{
			pixelcolor = colors[*Scrn++];
			red = ( pixelcolor & 0x00FF0000 ) >> 16 ;
			green = ( pixelcolor & 0x0000FF00 ) >> 8 ;
			blue = ( pixelcolor & 0x000000FF ) ;
			pixel[3] = 0 ;
			pixel[2] = ( red & 0xFF ) ;
			pixel[1] = ( green & 0xFF ) ;
			pixel[0] = ( blue & 0xFF ) ;
			memcpy( bitptr, pixel, 4 ) ;
			bitptr += 4 ;
		}
	}


	XGSwizzleRect(g_pBlitBuff, 0, NULL, d3dlr.pBits, desc.Width, desc.Height, NULL, sizeof(DWORD));

	// Unlock our texture 
	Texture->UnlockRect(0);
 
	g_pd3dDevice->Clear(0L, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0), 1.0f, 0L);
	 
	D3DXCOLOR colour(1.0, 1.0, 1.0, 1.0);
	

	if (SCREENWIDTH == 320 && SCREENHEIGHT == 240)
	{

		// Hardcode scaling for now..change later if we want to support HDTV

		D3DXVECTOR2 vecScaleHighRes((float)1.95,(float)1.95);
		D3DXVECTOR2 vecTranslateHighRes(1,1);
		Sprite->Draw(Texture, &srcRect, &vecScaleHighRes, NULL, 0, &vecTranslateHighRes, colour);
	}
	else
	{
		D3DXVECTOR2 vecScaleHighRes((float)0.95,(float)0.95);
		D3DXVECTOR2 vecTranslateHighRes(1,1);
		Sprite->Draw(Texture, &srcRect, &vecScaleHighRes, NULL, 0, &vecTranslateHighRes, colour);
	}
		
	 

	g_pd3dDevice->Present(NULL, NULL, NULL, NULL); 

}

DWORD BuildColorTable(unsigned char red, unsigned char green, unsigned char blue)
{
	return D3DCOLOR_XRGB(red, green ,blue);

}

