
#ifndef __WIN32_D3D__
#define __WIN32_D3D__

#include "Windoom.h"

//============================================================
//	PROTOTYPES
//============================================================

int init_texture(int Width, int Height);
void shutdown_texture(void);
void RenderD3D();
DWORD BuildColorTable(unsigned char red, unsigned char green, unsigned char blue);
//int win_d3d_draw(struct mame_bitmap *bitmap, int update);
unsigned long colors[256];
#endif