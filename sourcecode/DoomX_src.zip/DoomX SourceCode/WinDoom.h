#if !defined(DOOMX_H_INCLUDED)
#define DOOMX_H_INCLUDED

#include <xtl.h>
#include <Xgraphics.h>
#include <stdio.h>
#include <stdlib.h>
#include <dsound.h>
 
#pragma warning(disable:4244)		// "possible loss of data"
 
int init_texture(int Width, int Height);
void shutdown_texture(void);
HRESULT InitDirect3D(void);

#endif