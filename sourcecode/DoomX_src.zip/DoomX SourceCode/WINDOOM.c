// Copyright � 1998, Bruce A. Lewis
// This code may not be re-used in a commercial product
// of any kind without express written consent from
// the author, Bruce A. Lewis.
//
/////////////////////////////////////////////////////////////////////////////////////
// Windows Includes...
/////////////////////////////////////////////////////////////////////////////////////

#include <io.h>
#include <fcntl.h>

/////////////////////////////////////////////////////////////////////////////////////
// DirectX Includes...
/////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <direct.h>
//#include <ddraw.h>
//#include <dinput.h>

//#include <dplay.h>

/////////////////////////////////////////////////////////////////////////////////////
// Application Includes...
/////////////////////////////////////////////////////////////////////////////////////
//#include "resource.h"  // Required for Win32 Resources

/////////////////////////////////////////////////////////////////////////////////////
// "WinDoom" Includes...
/////////////////////////////////////////////////////////////////////////////////////
#include "doomdef.h"
#include "doomstat.h"
#include "d_event.h"
#include "d_main.h"
#include "m_argv.h"
#include "g_game.h"
#include "i_system.h"
#include "m_music.h"
  //#include "i_cd.h"
  //#include "i_midi.h"
#include "dxerr.h"

#include "d_console.h"

#include "WinDoom.h"
#include "d3dWin.h"
#include "DoomGamePad.h"
 
/////////////////////////////////////////////////////////////////////////////////////
// DirectX Defines and Data
/////////////////////////////////////////////////////////////////////////////////////
 
//#define SAFE_RELEASE(x) if (x != NULL) {x->Release(); x = NULL;}

/////////////////////////////////////////////////////////////////////////////////////
// Direct Sound
/////////////////////////////////////////////////////////////////////////////////////

#define SB_SIZE       20480
#define NUM_DSBUFFERS 256

BOOL SetupDirectSound();
void ShutdownDirectSound(void);

/////////////////////////////////////////////////////////////////////////////////////
// Direct Input
/////////////////////////////////////////////////////////////////////////////////////

void HandleKeyStrokes(void);
void KeyboardHandler(void);
BOOL InitDirectInput(void);
void ShutdownDirectInput(void);
 
/*
LPDIRECTINPUT        lpDirectInput = 0;
LPDIRECTINPUTDEVICE  lpMouse       = 0;
LPDIRECTINPUTDEVICE2 lpJoystick    = 0;
LPDIRECTINPUTDEVICE  lpKeyboard    = 0;
*/

static LPDIRECT3DTEXTURE8	Texture;
static LPD3DXSPRITE			Sprite;
static byte*				g_pBlitBuff = NULL;

BOOL          bDILive = FALSE;
char          szMouseBuf[1024];
unsigned char diKeyState[256];

extern int    always_run;
extern int    mvert;
extern int    keylink;

extern int    joyb1;
extern int    joyb2;
extern int    joyb3;
extern int    joyb4;
extern int    mouseb1;
extern int    mouseb2;
extern int    mouseb3;


extern char m_ipaddr[30] ;
extern char m_ipNet;


void RenderScene(void);
void InitGlobals(void);
BOOL SetupDirectDraw();
void ShutdownDirectDraw(void);



//LPDIRECTDRAWPALETTE  lpPalette = NULL; // Palette
PALETTEENTRY         rPal[768];        // Temp palette used later on

// this structure holds a RGB triple in three unsigned bytes
typedef struct RGB_color_typ
   {
    unsigned char red;      // red   component of color 0-63
    unsigned char green;    // green component of color 0-63
    unsigned char blue;     // blue  component of color 0-63
   }xRGB_color, *xRGB_color_ptr;

// this structure holds an entire color palette
typedef struct xRGB_palette_typ
   {
    int start_reg;          // index of the starting register that is save
    int end_reg;            // index of the ending registe that is saved
    xRGB_color colors[256];  // the storage area for the palette
   }xRGB_palette, *xRGB_palette_ptr;

xRGB_palette xpal;

BOOL CheckSurfaces(void);

/////////////////////////////////////////////////////////////////////////////////////
// Application Defines and Data
/////////////////////////////////////////////////////////////////////////////////////

#define MUSIC_NONE      0
#define MUSIC_CDAUDIO   1
#define MUSIC_MIDI      2

#define RENDER_GL       0
#define RENDER_D3D      1

#define KS_KEYUP        0
#define KS_KEYDOWN    128

/////////////////////////////////////////////////////////////////////////////////////
// Game states -- these are the modes in which the outer game loop can be
/////////////////////////////////////////////////////////////////////////////////////
#define GAME_START  0
#define GAME_SPLASH 1
#define GAME_MENU   2
#define GAME_PLAY   3
#define GAME_EXIT   4
#define GAME_QUIT   5
#define GAME_LIMBO  6
#define GAME_PAUSE  7

int     GameMode = GAME_START;

extern byte *screens[5];

extern int usemouse;
extern int usejoystick;

short     si_Kbd[256];

char      szMsgText[256];

DWORD     dwCurrWidth, dwCurrHeight, dwCurrBPP;

//extern    CD_Data_t   CDData;
//extern    MIDI_Data_t MidiData;

char        szMidiFile[] = "doomsong.mid";

int         MusicType = MUSIC_MIDI;
int         RenderType = RENDER_D3D;
BOOL        bQuit = FALSE;

void  GetWindowsVersion(void);

int   WinDoomAC;
char *WinDoomAV[256];

char *YesNo[] = { "No", "Yes" };

void  ParseCommand(PSTR szCmdLine);

void  GameLoop(void);

void  D_DoomMain(void);
void *W_CacheLumpName(char *, int);
void  I_SetPalette(byte *);
void  MY_DoomSetup(void);
void  MY_DoomLoop(void);
void  WinDoomExit(void);
void  HandleKeyboard(void);

extern LPDIRECT3DDEVICE8    g_pd3dDevice;
LPDIRECTSOUND8        lpDS;
LPDIRECTSOUNDBUFFER8  lpDSPrimary;
LPDIRECTSOUNDBUFFER8  lpDSBuffer[NUM_DSBUFFERS];

extern void WriteDebug(const char *name);
extern void DrawText(const char* Text);

/////////////////////////////////////////////////////////////////////////////////////
// Windows Defines and Data
/////////////////////////////////////////////////////////////////////////////////////
//LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
char      szAppName[] = "WinDoom";
char      szDbgName[] = "WinDoom.dbg";
char      szCfgName[] = "WinDoom.cfg";
//HINSTANCE hInst;
//HWND      hMainWnd;
//HACCEL    ghAccel; 

/*int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
   {
    MSG         msg;
    WNDCLASSEX  wndclass;
    FILE       *fn;
    HWND        hwnd;
    HDC         hDCDesk;
    HWND        hDesktop;
    HACCEL      hAccel;
    int         i, k;
    int         p;

    hInst = hInstance;

    fn = fopen(szDbgName, "w");
    fclose(fn);

    // We get the current video setup here. Really don't need to do this. The data isn't used.
    dwCurrWidth = GetSystemMetrics(SM_CXSCREEN);
    dwCurrHeight = GetSystemMetrics(SM_CYSCREEN);
    hDesktop = GetDesktopWindow();
	hDCDesk  = GetDC(hDesktop);
	dwCurrBPP = GetDeviceCaps(hDCDesk,BITSPIXEL);
	ReleaseDC(hDesktop,hDCDesk);

    wndclass.cbSize        = sizeof(wndclass);
    wndclass.style         = CS_HREDRAW | CS_VREDRAW;
    wndclass.lpfnWndProc   = WndProc;
    wndclass.cbClsExtra    = 0;
    wndclass.cbWndExtra    = 0;
    wndclass.hInstance     = hInstance;
    wndclass.hIcon         = LoadIcon(NULL, IDI_WINLOGO);
    wndclass.hCursor       = LoadCursor(NULL, IDC_WAIT);
    wndclass.hbrBackground =(HBRUSH) GetStockObject(BLACK_BRUSH);
    wndclass.lpszMenuName  = NULL;
    wndclass.lpszClassName = szAppName;
    wndclass.hIconSm       = LoadIcon(NULL, IDI_WINLOGO);

    RegisterClassEx(&wndclass);

    CDData.CDStatus = cd_empty;
    CDData.CDMedia = FALSE;
    CDData.CDPosition = 0;
    CDData.CDCode[0] = '\0';

    hwnd = CreateWindow(szAppName,            // window class name
	                    "WinDoom",              // window caption
                        WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,  // window style
                        0,0,                  // initial x & y position
                        dwCurrWidth, dwCurrHeight,
                        NULL,                  // parent window handle
                        NULL,                  // window menu handle
                        hInstance,             // program instance handle
                        NULL);		          // creation parameters
/*
SystemParametersInfo()
*/

  /*  hMainWnd = hwnd;
    SetupDirectSound();
    // Make the window visible & update its client area
    ShowWindow(hwnd, iCmdShow);// Show the window
    UpdateWindow(hwnd);        // Sends WM_PAINT message

    // This is used to determine what OS we're on (Windows9X or Windows NT)
    GetWindowsVersion();

    ParseCommand(szCmdLine);

    p = M_CheckParm("-width");
    if (p && p < myargc-1)
        SCREENWIDTH = atoi(myargv[p+1]);
    else
        SCREENWIDTH = 320;

    p = M_CheckParm("-height");
    if (p && p < myargc-1)
        SCREENHEIGHT = atoi(myargv[p+1]);
    else
        SCREENHEIGHT = 200;

    sprintf(szMsgText, "Resolution: %d x %d\n",SCREENWIDTH,SCREENHEIGHT);
    WriteDebug(szMsgText);

    // This sets the video mode to video mode described in the default video mode
    InitGlobals();
    if (!SetupDirectDraw(hwnd))
       {
        ShutdownDirectSound();
        exit(0);
       }

    MoveWindow(hwnd, 0,0, Mode[CurrMode].w, Mode[CurrMode].h, TRUE);

    hAccel = LoadAccelerators(hInstance,"AppAccel");
    ghAccel = hAccel;

    bDILive = InitDirectInput();

    for (k = 0; k < 256; k++)
        si_Kbd[k] = KS_KEYUP;

    PlayMidiFile(szMidiFile);

    bQuit = FALSE;

    sprintf(szMsgText, "WinDoom Version %2d.%02d\n", CONSVERS/100, CONSVERS%100);
    WriteDebug(szMsgText);

    D_DoomMain();
    MY_DoomSetup();
    GameMode = GAME_PLAY;

    ShowCursor(FALSE);

    while (!bQuit)
	   {
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		   {
            if (msg.message == WM_QUIT)
			   {
				bQuit = TRUE;
                break;
               }
            if (!TranslateAccelerator(msg.hwnd, hAccel, &msg))
			   {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
               }
           }
        if (GameMode == GAME_PLAY)
           GameLoop();
        if (GameMode == GAME_QUIT)
           I_Quit();
       }
    ShowCursor(TRUE);
    for (i = 4; i >= 0; i--)
        free(screens[i]);
    for (i = (WinDoomAC-1); i > 0; i--)
        free(WinDoomAV[i]);
    return msg.wParam;
   } */

void ParseCommand(PSTR szCmdLine)
   {
    char *s;

    WinDoomAC = 1;
    s = strtok(szCmdLine, " ");
    while (s != NULL)
       {
        WinDoomAV[WinDoomAC] = (char *)malloc(strlen(s)+1);
        strcpy(WinDoomAV[WinDoomAC], s);
        WinDoomAC++;
        s = strtok(NULL, " ");
       }
    
    myargc = WinDoomAC;
    myargv = WinDoomAV;
   }

void GameLoop()
   {
//    DIMOUSESTATE         diMouseState;          /* DirectInput mouse state structure */
//    static DIMOUSESTATE  diHoldMouse;           /* DirectInput mouse state structure */
//    DIJOYSTATE           diJoyState;            /* DirectInput joystick state structure */
//    static DIJOYSTATE    diHoldJoy;             /* DirectInput joystick state structure */
//   HRESULT          hresult;
   


  /*  if (usemouse == TRUE)
       {
    RetryMouse:;
        hresult = lpMouse->lpVtbl->GetDeviceState(lpMouse, sizeof(DIMOUSESTATE), &diMouseState);
        if (hresult == DIERR_INPUTLOST)
           {
            hresult = lpMouse->lpVtbl->Acquire(lpMouse);
            if (SUCCEEDED(hresult))
                goto RetryMouse;
           }
        else
        if (hresult != DI_OK)
           {
            DI_Error(hresult, "GetDeviceState (mouse)");
           }

        if (SUCCEEDED(hresult))
           {
            if ((diMouseState.lX != diHoldMouse.lX) ||
                (diMouseState.lY != diHoldMouse.lY) ||
                (diMouseState.lZ != diHoldMouse.lZ) ||
                (diMouseState.rgbButtons[0] != diHoldMouse.rgbButtons[0]) ||
                (diMouseState.rgbButtons[1] != diHoldMouse.rgbButtons[1]) ||
                (diMouseState.rgbButtons[2] != diHoldMouse.rgbButtons[2]) ||
                (diMouseState.rgbButtons[3] != diHoldMouse.rgbButtons[3]))
               {
                event.type = ev_mouse;
                event.data1 = 0;
                if (mouseb1 == 0)
                    event.data1 |= ((diMouseState.rgbButtons[0] & 0x80) >> 7);
                else
                   {
                    if ((diHoldMouse.rgbButtons[0] & 0x80) != (diMouseState.rgbButtons[0] & 0x80))
                       {
                        if ((diMouseState.rgbButtons[0] & 0x80) == 0x80)
                           {
                            mbevent.type = ev_keydown;
                           }
                        else
                           {
                            mbevent.type = ev_keyup;
                           }
                        mbevent.data1 = mouseb1;
                        D_PostEvent(&mbevent);
                       }
                   }
                if (mouseb2 == 0)
                    event.data1 |= ((diMouseState.rgbButtons[1] & 0x80) >> 6);
                else
                   {
                    if ((diHoldMouse.rgbButtons[1] & 0x80) != (diMouseState.rgbButtons[1] & 0x80))
                       {
                        if ((diMouseState.rgbButtons[1] & 0x80) == 0x80)
                           {
                            mbevent.type = ev_keydown;
                           }
                        else
                           {
                            mbevent.type = ev_keyup;
                           }
                        mbevent.data1 = mouseb2;
                        D_PostEvent(&mbevent);
                       }
                   }
                if (mouseb3 == 0)
                    event.data1 |= ((diMouseState.rgbButtons[2] & 0x80) >> 5);
                else
                   {
                    if ((diHoldMouse.rgbButtons[2] & 0x80) != (diMouseState.rgbButtons[2] & 0x80))
                       {
                        if ((diMouseState.rgbButtons[2] & 0x80) == 0x80)
                           {
                            mbevent.type = ev_keydown;
                           }
                        else
                           {
                            mbevent.type = ev_keyup;
                           }
                        mbevent.data1 = mouseb3;
                        D_PostEvent(&mbevent);
                       }
                   }
                event.data2 = diMouseState.lX*4;
                if (mvert == TRUE)
                   {
                    event.data3 = (diMouseState.lY * -4);
                   }
                else
                   {
                    event.data3 = 0;
                   }
                D_PostEvent(&event);
                diHoldMouse.lX = diMouseState.lX;
                diHoldMouse.lY = diMouseState.lY;
                diHoldMouse.lZ = diMouseState.lZ;
                diHoldMouse.rgbButtons[0] = diMouseState.rgbButtons[0];
                diHoldMouse.rgbButtons[1] = diMouseState.rgbButtons[1];
                diHoldMouse.rgbButtons[2] = diMouseState.rgbButtons[2];
                diHoldMouse.rgbButtons[3] = diMouseState.rgbButtons[3];
               }
           }
       }

    if (usejoystick == TRUE)
       {
    RetryJoy:;
    if (lpJoystick != 0)
       {
        hresult = lpJoystick->lpVtbl->Poll(lpJoystick);

        hresult = lpJoystick->lpVtbl->GetDeviceState(lpJoystick, sizeof(DIJOYSTATE), &diJoyState);
        if (hresult == DIERR_INPUTLOST)
           {
            hresult = lpJoystick->lpVtbl->Acquire(lpJoystick);
            if (SUCCEEDED(hresult))
                goto RetryJoy;
           }
        else
        if (hresult != DI_OK)
           {
            DI_Error(hresult, "GetDeviceState (joystick)");
           }

        if (SUCCEEDED(hresult))
           {
            if ((diJoyState.lX != diHoldJoy.lX) ||
                (diJoyState.lY != diHoldJoy.lY) ||
                (diJoyState.rgbButtons[0] != diHoldJoy.rgbButtons[0]) ||
                (diJoyState.rgbButtons[1] != diHoldJoy.rgbButtons[1]) ||
                (diJoyState.rgbButtons[2] != diHoldJoy.rgbButtons[2]) ||
                (diJoyState.rgbButtons[3] != diHoldJoy.rgbButtons[3]))
               {
                event.type = ev_joystick;
                event.data1 = 0;
                if (joyb1 == 0)
                    event.data1 |= ((diJoyState.rgbButtons[0] & 0x80) >> 7);
                else
                   {
                    if ((diHoldJoy.rgbButtons[0] & 0x80) != (diJoyState.rgbButtons[0] & 0x80))
                       {
                        if ((diJoyState.rgbButtons[0] & 0x80) == 0x80)
                           {
                            jbevent.type = ev_keydown;
                           }
                        else
                           {
                            jbevent.type = ev_keyup;
                           }
                        jbevent.data1 = joyb1;
                        D_PostEvent(&jbevent);
                       }
                   }
                if (joyb2 == 0)
                    event.data1 |= ((diJoyState.rgbButtons[1] & 0x80) >> 6);
                else
                   {
                    if ((diHoldJoy.rgbButtons[1] & 0x80) != (diJoyState.rgbButtons[1] & 0x80))
                       {
                        if ((diJoyState.rgbButtons[1] & 0x80) == 0x80)
                           {
                            jbevent.type = ev_keydown;
                           }
                        else
                           {
                            jbevent.type = ev_keyup;
                           }
                        jbevent.data1 = joyb2;
                        D_PostEvent(&jbevent);
                       }
                   }
                if (joyb3 == 0)
                    event.data1 |= ((diJoyState.rgbButtons[2] & 0x80) >> 5);
                else
                   {
                    if ((diHoldJoy.rgbButtons[2] & 0x80) != (diJoyState.rgbButtons[2] & 0x80))
                       {
                        if ((diJoyState.rgbButtons[2] & 0x80) == 0x80)
                           {
                            jbevent.type = ev_keydown;
                           }
                        else
                           {
                            jbevent.type = ev_keyup;
                           }
                        jbevent.data1 = joyb3;
                        D_PostEvent(&jbevent);
                       }
                   }
                if (joyb4 == 0)
                    event.data1 |= ((diJoyState.rgbButtons[3] & 0x80) >> 4);
                else
                   {
                    if ((diHoldJoy.rgbButtons[3] & 0x80) != (diJoyState.rgbButtons[3] & 0x80))
                       {
                        if ((diJoyState.rgbButtons[2] & 0x80) == 0x80)
                           {
                            jbevent.type = ev_keydown;
                           }
                        else
                           {
                            jbevent.type = ev_keyup;
                           }
                        jbevent.data1 = joyb4;
                        D_PostEvent(&jbevent);
                       }
                   }
                event.data2 = diJoyState.lX;
                event.data3 = diJoyState.lY;
                D_PostEvent(&event);
                diHoldJoy.lX = diJoyState.lX;
                diHoldJoy.lY = diJoyState.lY;
                diHoldJoy.rgbButtons[0] = diJoyState.rgbButtons[0];
                diHoldJoy.rgbButtons[1] = diJoyState.rgbButtons[1];
                diHoldJoy.rgbButtons[2] = diJoyState.rgbButtons[2];
                diHoldJoy.rgbButtons[3] = diJoyState.rgbButtons[3];
               }
           }
       }
       }

    HandleKeyboard(); */
	
	ProcessGamepads();
    MY_DoomLoop();
   }

void HandleKeyboard()
   {
 
   }

void HandleKeyStrokes()
   {
/*
    static  event_t  event;
    int     i;

    if ((keylink == TRUE) && (diKeyState[DIK_LMENU] == KS_KEYDOWN))
        diKeyState[DIK_RMENU] = KS_KEYDOWN;
    if ((keylink == TRUE) && (diKeyState[DIK_RMENU] == KS_KEYDOWN) && (diKeyState[DIK_LMENU] == KS_KEYUP))
        diKeyState[DIK_LMENU] = KS_KEYDOWN;

    if ((keylink == TRUE) && (diKeyState[DIK_LSHIFT] == KS_KEYDOWN))
        diKeyState[DIK_RSHIFT] = KS_KEYDOWN;
    if ((keylink == TRUE) && (diKeyState[DIK_RSHIFT] == KS_KEYDOWN) && (diKeyState[DIK_LSHIFT] == KS_KEYUP))
        diKeyState[DIK_LSHIFT] = KS_KEYDOWN;

    if ((keylink == TRUE) && (diKeyState[DIK_LCONTROL] == KS_KEYDOWN))
        diKeyState[DIK_RCONTROL] = KS_KEYDOWN;
    if ((keylink == TRUE) && (diKeyState[DIK_RCONTROL] == KS_KEYDOWN) && (diKeyState[DIK_LCONTROL] == KS_KEYUP))
        diKeyState[DIK_LCONTROL] = KS_KEYDOWN;

    // Can this be limited to a smaller range? What about international keyboards?
    for (i = 1; i < 256; i++)
       {
        if (((diKeyState[i] & 0x80) == 0) && (si_Kbd[i] == KS_KEYDOWN))
           {
            event.type = ev_keyup;
            event.data1 = i;
            D_PostEvent(&event);
            si_Kbd[i] = KS_KEYUP;
           }

        if ((diKeyState[i] & 0x80) && (si_Kbd[i] == KS_KEYUP))
           {
            if ((i != DIK_TAB) || ((diKeyState[DIK_LMENU] == KS_KEYUP) && (diKeyState[DIK_RMENU] == KS_KEYUP)))
               {
                event.type = ev_keydown;
                event.data1 = i;
                D_PostEvent(&event);
                si_Kbd[i] = KS_KEYDOWN;
              }
           }
       } */
   }

void WinDoomExit()
   {
   if (demorecording)
       {
        if (demotype == DEMO_I)
           G_EndDemo();
        else
           G_EndDemo_II();
       }
    StopMusic();
   // 

	GameMode = GAME_QUIT;
   
   }

/*LRESULT CALLBACK WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
   {
    static HDC         hDC;
    static PAINTSTRUCT ps;
    static event_t     event;
    static unsigned char KeyPress;
    static int         scancode;

    switch(iMsg)
       {
        case WM_CREATE:
             GetCDInfo(hwnd);
             break;

        case MM_MCINOTIFY:
             if (wParam == MCI_NOTIFY_SUCCESSFUL)
                {
                 if (MidiData.MidiStatus == midi_play)
                    MidiReplay(hwnd, &MidiData);
                 if (CDData.CDStatus == cd_play)
                    CDTrackPlay(hwnd, &CDData);
                }
             if (wParam == MCI_NOTIFY_FAILURE)
                {
                 if (CDData.CDStatus == cd_play)
                    {
                     MidiPlay(hwnd, &MidiData);
                     CDData.CDStatus == cd_stop;
                    }
                }
             break;

       case WM_KEYDOWN:
            if ((lParam & 0x40000000) != 0)  // This "debounces" the keys so that we only process
               break;                        // the message when the key is first pressed and not after.

            switch(wParam)
               {
                case VK_PAUSE:
                     event.type = ev_keydown;
                     event.data1 = KEY_PAUSE;
                     D_PostEvent(&event);
                     break;
                case VK_SHIFT:
                     if (keylink == TRUE)
                        {
                         event.type = ev_keydown;
                         event.data1 = DIK_RSHIFT;
                         D_PostEvent(&event);
                        }
                     break;
                case VK_CONTROL:
                     if (keylink == TRUE)
                        {
                         event.type = ev_keydown;
                         event.data1 = DIK_RCONTROL;
                         D_PostEvent(&event);
                        }
                     break;
               }
            break;

       case WM_ACTIVATE:
            if (LOWORD(wParam) != WA_INACTIVE)
               {
                GameMode = GAME_PLAY;
               }
            else
               {
                GameMode = GAME_PAUSE;
               }
            break;

       case WM_KEYUP:
            switch(wParam)
               {
                case VK_PAUSE:
                     event.type = ev_keyup;	
                     event.data1 = KEY_PAUSE;
                     D_PostEvent(&event);
                     break;
                case VK_SHIFT:
                     if (keylink == TRUE)
                        {
                         event.type = ev_keyup;
                         event.data1 = DIK_RSHIFT;
                         D_PostEvent(&event);
                        }
                     break;
                case VK_CONTROL:
                     if (keylink == TRUE)
                        {
                         event.type = ev_keyup;
                         event.data1 = DIK_RCONTROL;
                         D_PostEvent(&event);
                        }
                     break;
               }
            break;

        case WM_DESTROY:
             PostQuitMessage(0);
             return 0;
       }
    return DefWindowProc(hwnd, iMsg, wParam, lParam);
   } */


 

/////////////////////////////////////////////////////////////////////////////////////
// DIRECTX
/////////////////////////////////////////////////////////////////////////////////////
// The next section of code deals with Microsoft's DirectX.
/////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////
// DIRECTSOUND - Sound effects
/////////////////////////////////////////////////////////////////////////////////////

BOOL SetupDirectSound()
   {
    HRESULT        hresult;
    int            buff;
    DSBUFFERDESC   dsbdesc;
    WAVEFORMATEX   wfx;

    // Create an instance of DirectSound
 
    hresult = DirectSoundCreate(NULL, &lpDS, NULL);
    if (hresult != DS_OK)
       {
        DS_Error(hresult, "DirectSoundCreate");
        for (buff = 0; buff < NUM_DSBUFFERS; buff++)
           lpDSBuffer[buff] = 0;
        return FALSE;
       }
    
    
    // Set up wave format structure.
    memset( &wfx, 0, sizeof(WAVEFORMATEX));
    wfx.wFormatTag         = WAVE_FORMAT_PCM;      
    wfx.nChannels          = 2;
    wfx.nSamplesPerSec     = 44100;
    wfx.nAvgBytesPerSec    = 44100*2*1;
    wfx.nBlockAlign        = 2; // ?
    wfx.wBitsPerSample     = (WORD)8;
    wfx.cbSize             = 0;


/*	DSMIXBINVOLUMEPAIR dsmbvp[8] = {
	{DSMIXBIN_FRONT_LEFT, DSBVOLUME_MAX},   // left channel
	{DSMIXBIN_FRONT_RIGHT, DSBVOLUME_MAX},  // right channel
	{DSMIXBIN_FRONT_CENTER, DSBVOLUME_MAX}, // left channel
	{DSMIXBIN_FRONT_CENTER, DSBVOLUME_MAX}, // right channel
	{DSMIXBIN_BACK_LEFT, DSBVOLUME_MAX},    // left channel
	{DSMIXBIN_BACK_RIGHT, DSBVOLUME_MAX},   // right channel
	{DSMIXBIN_LOW_FREQUENCY, DSBVOLUME_MAX},    // left channel
	{DSMIXBIN_LOW_FREQUENCY, DSBVOLUME_MAX}};   // right channel
	
	DSMIXBINS dsmb;
	dsmb.dwMixBinCount = 8;
	dsmb.lpMixBinVolumePairs = dsmbvp; */


	// Set up DSBUFFERDESC structure.
    memset(&dsbdesc, 0, sizeof(DSBUFFERDESC));  // Zero it out.
    dsbdesc.dwSize              = sizeof(DSBUFFERDESC);
    dsbdesc.dwFlags             = 0;
    dsbdesc.dwBufferBytes       = 0;
    dsbdesc.lpwfxFormat         = &wfx;
	//dsbdesc.lpMixBins		    = &dsmb;

   /* hresult = IDirectSoundBuffer_SetFormat(lpDSPrimary,&wfx);
    if (hresult != DS_OK)
       {
        DS_Error(hresult, "DirectSound.SetFormat - Primary");
       } */

     
    return(TRUE);
   }

void DSCreateSoundBuffer(int Channel, int length, unsigned char *data)
   {
    HRESULT        hresult;
    //int            buff;
    DSBUFFERDESC   dsbdesc;
    WAVEFORMATEX  pcmwf;
    void          *buffer, *buff2;
    DWORD          size1, size2;

    if (Channel > NUM_DSBUFFERS)
       {
        WriteDebug("Invalid sound effect...\n");
        return;
       }

    // Set up wave format structure.
    memset( &pcmwf, 0, sizeof(WAVEFORMATEX) );
    pcmwf.wFormatTag         = WAVE_FORMAT_PCM;      
    pcmwf.nChannels          = 1;
    pcmwf.nSamplesPerSec     = 11025;
    pcmwf.nBlockAlign        = 1; // ?
    pcmwf.nAvgBytesPerSec    = 11025*1*1;
    pcmwf.wBitsPerSample        = (WORD)8;

    // Set up DSBUFFERDESC structure.
    memset(&dsbdesc, 0, sizeof(DSBUFFERDESC));  // Zero it out.
    dsbdesc.dwSize              = sizeof(DSBUFFERDESC);
    dsbdesc.dwFlags             = 0;
    dsbdesc.dwBufferBytes       = length;
    dsbdesc.lpwfxFormat         = (LPWAVEFORMATEX)&pcmwf;

    if ((hresult = IDirectSound_CreateSoundBuffer(lpDS,&dsbdesc, &lpDSBuffer[Channel], NULL)) != DS_OK)
       {
        DS_Error(hresult, "DirectSound.CreateSoundBuffer");
        return;
       }

	if (length > 0)
	{
		hresult = IDirectSoundBuffer_Lock(lpDSBuffer[Channel],0,length,&buffer,&size1,&buff2,&size2,DSBLOCK_ENTIREBUFFER );
	  
		if (hresult == DS_OK)
		{
			memcpy(buffer, data, length);
		}
		else
		{
			DS_Error(hresult, "lpDSBuffer.Lock");
		}
   }
}

void ShutdownDirectSound()
   {
    int buff;

    DWORD BufferStatus;


    for (buff = 0; buff < NUM_DSBUFFERS; buff++)
       {
        if (lpDSBuffer[buff] != 0)
           {
            BufferStatus = DSBSTATUS_PLAYING;
            while (BufferStatus == DSBSTATUS_PLAYING)
                IDirectSoundBuffer_GetStatus(lpDSBuffer[buff],&BufferStatus);
				IDirectSoundBuffer_Release(lpDSBuffer[buff]);
           }
       }

   // IDirectSoundBuffer_Release(lpDSPrimary);
    IDirectSound_Release(lpDS);

   }
 

DWORD FrameCount, FrameCount0, FrameTime, FrameTime0, FrameRate;


#define PU_CACHE 101

void RenderScene()
{

	// Render to the XBOX framebuffer

	RenderD3D();
  
}


 

void InitDoomX(int nHeight, int nWidth)
{

	// This is the entry point for the Xbox version - Lantus

	char szNetCmdLine[40];
	int i = 0;
	int     numwadfiles;

	SCREENWIDTH = nHeight;
	SCREENHEIGHT = nWidth;
	bQuit = FALSE;
 
	SetupDirectSound();

	if (strcmp(m_ipaddr,"0.0.0.0") != 0)
	{
		sprintf(szNetCmdLine,"-net %c .%s -deathmatch -nomonsters",m_ipNet, m_ipaddr);
		ParseCommand(szNetCmdLine);
	}
	
	D_DoomMain();
	MY_DoomSetup();

	
	if (GameMode != GAME_QUIT)
	{
		init_texture(SCREENWIDTH,SCREENHEIGHT);
		GameMode = GAME_PLAY;
	}
	
    while (bQuit == FALSE)
	{
        if (GameMode == GAME_PLAY)
           GameLoop();

        if (GameMode == GAME_QUIT)
		{ 
		   bQuit = TRUE;
		}

    }

	ShutdownDirectSound();

	if (screens)
		for (i = 4; i >= 0; i--)
			free(screens[i]);
	
	if (WinDoomAC)
		for (i = (WinDoomAC-1); i > 0; i--)
			free(WinDoomAV[i]);
 	
	shutdown_texture();

}


