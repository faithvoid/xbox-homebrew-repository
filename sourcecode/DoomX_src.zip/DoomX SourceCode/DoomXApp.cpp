//////////////////////////////////////////////////////////////////////
//
//
// DoomXApp.cpp
//
//  
//
//////////////////////////////////////////////////////////////////////

#include "DoomXApp.h"
#include <XBInput.h>
#include <XBFont.h>
#include <wchar.h>
#include <algorithm>
#include <XBStopWatch.h>
#include <stdlib.h>

#include "doomdef.h"
#include "xbnet.h"


//#include "m_argv.h"
//#include "d_main.h"

#define ROM_NAME_LEN 23
#define cGREEN_DIM 0xFF539704
#define cGREEN_BRIGHT 0xFFc3d10c
#define cWHITE_DIM 0x40ffffff
#define cWHITE_DIM_DIM 0xff808080
#define cWHITE_BRIGHT 0xffffffff
#define cWHITE 0x50ffffff
#define cSELECTED 0xFFFFd10c

#define	FILE_SYSTEM_CACHE	262144			//256k file cache

//============================================================
//	GLOBAL VARIABLES
//============================================================
 
CXBFont* pXBFont;
LPDIRECT3DVERTEXBUFFER8 pVB;

long nYPos = 24;
long nXPos = 30;
bool bLoadingGame = false;

char strOutput[856];

struct VERTEX { D3DXVECTOR4 p; D3DCOLOR vbColor; FLOAT tu, tv; };
static float rot_triangle=0; //Tracks rotation for our triangle
static float rot_square=0;   //Tracks rotation for our square


//============================================================
//	Function Prototypes
//============================================================

extern "C"
{
	LPDIRECT3DSURFACE8 pFrontBuffer;
	LPDIRECT3DTEXTURE8	pBackgroundTexture;
	void ClearScreen();
	void DrawText(const char* Text);
	void LoadingRomMsg(const char *name);
	int nPause =0;
	void SetupDirectSound();
	BOOL ShutdownDirectSound();
	void WriteDebug(const char *Message);
	void InitDoomX(int nHeight, int nWidth);
	char m_ipaddr[30] ;
	char m_ipNet;
}


 
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDoomXApp::CDoomXApp()
{
	nPause = 0;

//	m_d3dpp.EnableAutoDepthStencil = FALSE;
	m_pd3dDevice      = NULL;
    m_pVB             = NULL;

	cFLASHER = cSELECTED;
	flashDir = 0;

		//check for pal60 mode
/*	if(XGetVideoStandard() == XC_VIDEO_STANDARD_PAL_I)
	{
		//get supported video flags
		DWORD videoFlags = XGetVideoFlags();
		
		//set pal60 if available.
		if(videoFlags & XC_VIDEO_FLAGS_PAL_60Hz)
			m_d3dpp.FullScreen_RefreshRateInHz = 60;
		else
			m_d3dpp.FullScreen_RefreshRateInHz = 50;
	} */
	
	//set frame time
	m_fFrameTime = 1.0f / m_d3dpp.FullScreen_RefreshRateInHz;

	strcpy( m_ipaddr, "0.0.0.0" ) ;
	m_ipNet = '1';

	XBNet_Init( XNET_STARTUP_BYPASS_SECURITY );

	memset(&strOutput,0x00,856);

}

CDoomXApp::~CDoomXApp()
{
	
}
 
HRESULT CDoomXApp::Initialize()
{
 
	if(FAILED(m_Font.Create(m_pd3dDevice, "Font.xpr")))
        return XBAPPERR_MEDIANOTFOUND;

	if( FAILED( m_xprResource.Create( m_pd3dDevice, "background.xpr", 1 ) ) )
        return E_FAIL;

	m_pBackgroundTexture = m_xprResource.GetTexture( 0UL );



	m_pd3dDevice->CreateVertexBuffer( 4*(6*sizeof(FLOAT) + sizeof(DWORD)), D3DUSAGE_WRITEONLY, 
                                      0L, D3DPOOL_DEFAULT, &m_pVB );
    
    VERTEX* v;
    m_pVB->Lock( 0, 0, (BYTE**)&v, 0L );
    v[0].p = D3DXVECTOR4(   0 - 0.5f,   0 - 0.5f, 0, 0 ); v[0].vbColor = 0xAAAAAAAA; v[0].tu =   0; v[0].tv =   0;
    v[1].p = D3DXVECTOR4( 640 - 0.5f,   0 - 0.5f, 0, 0 ); v[1].vbColor = 0xAAAAAAAA; v[1].tu = 640; v[1].tv =   0;
    v[2].p = D3DXVECTOR4( 640 - 0.5f, 480 - 0.5f, 0, 0 ); v[2].vbColor = 0xAAAAAAAA; v[2].tu = 640; v[2].tv = 480;
    v[3].p = D3DXVECTOR4(   0 - 0.5f, 480 - 0.5f, 0, 0 ); v[3].vbColor = 0xAAAAAAAA; v[3].tu =   0; v[3].tv = 480;
    m_pVB->Unlock();

	init_matrices();

	// Store our pointers
	pXBFont = &m_Font;
	pBackgroundTexture = m_pBackgroundTexture;
	pVB = m_pVB;
 	
	// start at start of list (TODO PLONK: for now, store last game selected on HD / Memunit for later)
	fGameSelect = 0.0f;
	iGameSelect = 0;
	fCursorPos = 0.0f;
	iCursorPos = 0;
	fMaxCount = 0.0f;
	
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, TRUE);

	
	// Count all our game drivers
 
	iNumGames = m_vecAvailRoms.size();

	if (iNumGames < GAMESEL_MaxWindowList)
	{
		m_iMaxWindowList = iNumGames;
		m_iWindowMiddle  = iNumGames/2;
	}
	else
	{
		m_iMaxWindowList = GAMESEL_MaxWindowList;
		m_iWindowMiddle  = GAMESEL_WindowMiddle;
	}

	
	return S_OK;
}

 

// release buffers to enable back buffer to be changed.
HRESULT CDoomXApp::Cleanup()
{
 
	m_Font.Destroy();
	SAFE_RELEASE( m_pVB );


    return S_OK;
}

HRESULT CDoomXApp::FrameMove()
{

	// check for cursor select movement and move
	MoveCursor();
	 
	// check for selection of game and do something (anything!)
	if(m_DefaultGamepad.bAnalogButtons[XINPUT_GAMEPAD_A])
	{
		InitDoomX(640,480);
	}
	else if(m_DefaultGamepad.bAnalogButtons[XINPUT_GAMEPAD_X])
	{
		InitDoomX(320,240);
	

	}
	else if(m_DefaultGamepad.bAnalogButtons[XINPUT_GAMEPAD_Y])
	{
			doJoinGame() ;
	}
	else if (m_DefaultGamepad.bAnalogButtons[XINPUT_GAMEPAD_BLACK] > 0)
	{
		// back to dashboard for Evo-X freaks
		LD_LAUNCH_DASHBOARD LaunchData = { XLD_LAUNCH_DASHBOARD_MAIN_MENU };
		XLaunchNewImage( NULL, (LAUNCH_DATA*)&LaunchData );
	}
	else if(!nPause && m_DefaultGamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT)
	{
	}
	else if(!nPause && m_DefaultGamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT)
	{
 
	}

	return S_OK;
}

HRESULT CDoomXApp::Render()
{

	D3DXMATRIX world_matrix;
	D3DXMATRIX rot_matrix;     //Our rotation matrix
	D3DXMATRIX trans_matrix;   //Our translation matrix
	
    rot_square+=0.007f;

    // Clear the zbuffer
    m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL,
	0x00000000, 1.0f, 0L );
	
    LPDIRECT3DSURFACE8 pFrontBuffer;
    m_pd3dDevice->GetBackBuffer(-1, D3DBACKBUFFER_TYPE_MONO, &pFrontBuffer);

	// render a pretty background

	 
	m_pd3dDevice->SetTexture( 0, m_pBackgroundTexture );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_DISABLE );
    m_pd3dDevice->SetTextureStageState( 1, D3DTSS_ALPHAOP,   D3DTOP_DISABLE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ADDRESSU,  D3DTADDRESS_CLAMP );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ADDRESSV,  D3DTADDRESS_CLAMP );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,      TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_FOGENABLE,    FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_FOGTABLEMODE, D3DFOG_NONE );
    m_pd3dDevice->SetRenderState( D3DRS_FILLMODE,     D3DFILL_SOLID );
    m_pd3dDevice->SetRenderState( D3DRS_CULLMODE,     D3DCULL_CCW );
    m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
    m_pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
    m_pd3dDevice->SetVertexShader( D3DFVF_XYZRHW|D3DFVF_TEX1|D3DFVF_DIFFUSE  );
    m_pd3dDevice->SetStreamSource( 0, m_pVB, 6*sizeof(FLOAT) + sizeof(DWORD) );

	//Set up the rotation matrix for the square
    D3DXMatrixRotationY(&rot_matrix,rot_square);
      //Set up the World Matrix for the square
    D3DXMatrixTranslation(&trans_matrix,1.0,0.0f,0.0f);
      //Combine the 2 matrices to get our final World Matrix
    D3DXMatrixMultiply(&world_matrix,&rot_matrix,&trans_matrix);

	m_pd3dDevice->SetTransform( D3DTS_WORLD, &world_matrix );

    m_pd3dDevice->DrawPrimitive( D3DPT_QUADLIST, 0, 1 );
	

    m_Font.Begin();
	m_Font.DrawText(68, 32, 0xffEEEEEE, L"DoomX - Alpha 0.16");
	m_Font.DrawText(68, 62, 0xffEEEEEE, L"Ported by Lantus, Network UI code by SunTzu7, Graphics by ExitWound");
	m_Font.DrawText(168, 182, 0xffFFFFFF, L"A - Run Doom in 640x480 Mode (Recommended)");
	m_Font.DrawText(168, 202, 0xffFFFFFF, L"X - Run Doom in 320x200 Mode");
	m_Font.DrawText(168, 222, 0xffFFFFFF, L"Y - Setup Network Game");
	m_Font.DrawText(168, 242, 0xffFFFFFF, L"Black - Back to Dashboard");
	
 
    m_Font.End();


	m_pd3dDevice->Present(0, 0, 0, 0);
	
	// release front buffer
    pFrontBuffer->Release();
	
	// return success
    return S_OK;
}


// check for move cursor and move accordingly (with clamp etc)
void CDoomXApp::MoveCursor()
{
	
	// get right trigger state (convert to float & scale to 0.0f - 1.0f)
	float fWindowVelocity = (float)(m_DefaultGamepad.bAnalogButtons[XINPUT_GAMEPAD_RIGHT_TRIGGER])/256.0f;
	
	// subract in left trigger state (convert to float)
	fWindowVelocity -= (float)(m_DefaultGamepad.bAnalogButtons[XINPUT_GAMEPAD_LEFT_TRIGGER])/256.0f;

	//setup static locals
	static float fFastestThresh = m_d3dpp.FullScreen_RefreshRateInHz*GAMESEL_cfSpeedBandFastest;
	static float fMediumThresh = m_d3dpp.FullScreen_RefreshRateInHz*GAMESEL_cfSpeedBandMedium;
	static float fLowestThresh = m_d3dpp.FullScreen_RefreshRateInHz*GAMESEL_cfSpeedBandLowest;

	// do dead zone and gamma curve
	if(( fWindowVelocity  > -GAMESEL_cfDeadZone ) && ( fWindowVelocity < GAMESEL_cfDeadZone ))
	{
		// zero dead zone (for spring slack & noise)
		fWindowVelocity = 0.0f;
		fMaxCount = 0.0f;
	}
	else
	{
		//start at 0.0f after deadzone
		if( fWindowVelocity < 0.0f )
			//adjust for deadzone
			fWindowVelocity += GAMESEL_cfDeadZone;
		else
			//adjust for deadzone
			fWindowVelocity -= GAMESEL_cfDeadZone;

		//rescale to correct range
		fWindowVelocity *= GAMESEL_cfRectifyScale;

		//increase max held count (for speed up bands)
		if( fabs(fWindowVelocity) > GAMESEL_cfMaxThresh )
		{
			//increase count by frame time and clamp count (if necc.)
			if(fMaxCount += m_fFrameTime)
				fMaxCount = fFastestThresh;
		}

		//check for speed scale banding
		if( fMaxCount > fFastestThresh)
			fWindowVelocity *= GAMESEL_cfFastestScrollMult;
		else if( fMaxCount > fMediumThresh)
			fWindowVelocity *= GAMESEL_cfMediumScrollMult;
		else if( fMaxCount > fLowestThresh)
			fWindowVelocity *= GAMESEL_cfLowestScrollMult;
	}
	
	// default don`t clamp cursor
	bool bClampCursor = FALSE;
	
	// check if triggers pressed and move window
	fCursorPos += fWindowVelocity;
	if( fWindowVelocity > 0.0f )
	{
		if( fCursorPos > m_iWindowMiddle )
		{
			// clamp cursor position
			bClampCursor = TRUE;
			
			// advance gameselect
			fGameSelect += fWindowVelocity;
			
			// clamp game window range (high)
			if((fGameSelect + m_iMaxWindowList) > iNumGames)
			{
				// clamp to end
				fGameSelect = iNumGames - m_iMaxWindowList;
				
				// advance cursor pos after all!
				bClampCursor = FALSE;
				
				// clamp cursor to end
				fCursorPos = m_iMaxWindowList-1;
			}
 
		}
	}
	else if( fWindowVelocity < 0.0f )	// ok to do this! because of deadzone clamp
	{
		if( fCursorPos < m_iWindowMiddle )
		{
			// clamp cursor position
			bClampCursor = TRUE;
			
			// backup window pos
			fGameSelect += fWindowVelocity;
			
			// clamp game window range (low)
			if(fGameSelect < 0)
			{
				// clamp to start
				fGameSelect = 0;
				
				// backup cursor pos after all!
				bClampCursor = FALSE;
				
				// clamp cursor to end
				if( fCursorPos < 0 )
					fCursorPos = 0;
			}
		}
	}

	// check for cursor clamp
	if( bClampCursor )
		fCursorPos = m_iWindowMiddle;	

}

//-----------------------------------------------------------------------------
// Name: main()
// Desc: Entry point to the program.
//-----------------------------------------------------------------------------
VOID __cdecl main()
{
	// Initialize mame (reads the mame.ini file)
	//frontend_init();
	
	CDoomXApp theApp;
	if (FAILED(theApp.Create()))
	{
		return;
	}
	
	theApp.Run();
}

 
// Utility function mostly used for internal debugging
void DrawText(const char* Text)
{
	WCHAR* wcBuff = new WCHAR[strlen(Text)];
	mbsrtowcs(wcBuff, &Text, strlen(Text), NULL);
	
	ClearScreen();
	
	pXBFont->DrawText(40,  20, 0xff808080, wcBuff, XBFONT_LEFT);
	
	// Present the scene
    g_pd3dDevice->Present( NULL, NULL, NULL, NULL );
	
	// release front buffer
	pFrontBuffer->Release();

	delete [] wcBuff;
}


void ClearScreen()
{
    // Clear the zbuffer
    g_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL,
		0x00000000, 1.0f, 0L );
	
    g_pd3dDevice->GetBackBuffer(-1, D3DBACKBUFFER_TYPE_MONO, &pFrontBuffer);
}


 

void WriteDebug(const char *Message)
{
	
	if (lstrlen(strOutput) >= 800 )
		memset(&strOutput,0x00,856);

	strcat(strOutput,Message);

    WCHAR* wcBuff = new WCHAR[856];
	const char *tempMsg = strOutput;
	mbsrtowcs(wcBuff, &tempMsg, 856, NULL);
	
//	ClearScreen();

	 g_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL,
		0x00000000, 1.0f, 0L );


	if (pBackgroundTexture)
	{
		g_pd3dDevice->SetTexture( 0, pBackgroundTexture );
		g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
		g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
		g_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
		g_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
		g_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
		g_pd3dDevice->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_DISABLE );
		g_pd3dDevice->SetTextureStageState( 1, D3DTSS_ALPHAOP,   D3DTOP_DISABLE );
		g_pd3dDevice->SetTextureStageState( 0, D3DTSS_ADDRESSU,  D3DTADDRESS_CLAMP );
		g_pd3dDevice->SetTextureStageState( 0, D3DTSS_ADDRESSV,  D3DTADDRESS_CLAMP );
		g_pd3dDevice->SetRenderState( D3DRS_ZENABLE,      FALSE );
		g_pd3dDevice->SetRenderState( D3DRS_FOGENABLE,    FALSE );
		g_pd3dDevice->SetRenderState( D3DRS_FOGTABLEMODE, D3DFOG_NONE );
		g_pd3dDevice->SetRenderState( D3DRS_FILLMODE,     D3DFILL_SOLID );
		g_pd3dDevice->SetRenderState( D3DRS_CULLMODE,     D3DCULL_CCW );
		g_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
		g_pd3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
		g_pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
		g_pd3dDevice->SetVertexShader( D3DFVF_XYZRHW|D3DFVF_TEX1|D3DFVF_DIFFUSE  );
		g_pd3dDevice->SetStreamSource( 0, pVB, 6*sizeof(FLOAT) + sizeof(DWORD) );
		g_pd3dDevice->DrawPrimitive( D3DPT_QUADLIST, 0, 1 );
	}
	
	pXBFont->Begin();
	pXBFont->DrawText(nXPos, nYPos , 0xffEEEEEE, wcBuff, XBFONT_LEFT);
	pXBFont->End();
	
	// Present the scene
    g_pd3dDevice->Present( NULL, NULL, NULL, NULL );
	
	// release front buffer
//	pFrontBuffer->Release();

	delete [] wcBuff; 	

}


void CDoomXApp::doJoinGame()
{
	char ipaddr[30] ;
	char ipaddrconv[30] ;
	char *fpos, *epos ;
	int curr_pos ;
	int val1, val2 ;
	int ip1, ip2, ip3, ip4 ;
	int nKey = 1;
 
	m_nXOffset = 128;

	curr_pos = 0 ;

	fpos = m_ipaddr ;
	epos = strchr( fpos, '.' ) ;
	*epos = 0 ;
	epos++ ;
	ip1 = atoi( fpos ) ;

	fpos = epos ;
	epos = strchr( fpos, '.' ) ;
	*epos = 0 ;
	epos++ ;
	ip2 = atoi( fpos ) ;

	fpos = epos ;
	epos = strchr( fpos, '.' ) ;
	*epos = 0 ;
	epos++ ;
	ip3 = atoi( fpos ) ;
	ip4 = atoi( epos ) ;

	sprintf( ipaddr, "%03.3u.%03.3u.%03.3u.%03.3u  %01u", ip1, ip2, ip3, ip4, nKey ) ;
 

 
	while ( 1 )
	{

		ClearScreen();

		if (m_pBackgroundTexture)
		{
			m_pd3dDevice->SetTexture( 0, m_pBackgroundTexture );
			m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
			m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
			m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
			m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
			m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
			m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
			m_pd3dDevice->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_DISABLE );
			m_pd3dDevice->SetTextureStageState( 1, D3DTSS_ALPHAOP,   D3DTOP_DISABLE );
			m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ADDRESSU,  D3DTADDRESS_CLAMP );
			m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ADDRESSV,  D3DTADDRESS_CLAMP );
			m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,      TRUE );
			m_pd3dDevice->SetRenderState( D3DRS_FOGENABLE,    FALSE );
			m_pd3dDevice->SetRenderState( D3DRS_FOGTABLEMODE, D3DFOG_NONE );
			m_pd3dDevice->SetRenderState( D3DRS_FILLMODE,     D3DFILL_SOLID );
			m_pd3dDevice->SetRenderState( D3DRS_CULLMODE,     D3DCULL_CCW );
			m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
			m_pd3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
			m_pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
			m_pd3dDevice->SetVertexShader( D3DFVF_XYZRHW|D3DFVF_TEX1|D3DFVF_DIFFUSE  );
			m_pd3dDevice->SetStreamSource( 0, m_pVB, 6*sizeof(FLOAT) + sizeof(DWORD) );
			m_pd3dDevice->DrawPrimitive( D3DPT_QUADLIST, 0, 1 );
		}	

		m_Font.Begin();

		m_Font.DrawText(m_nXOffset+  32, 16*2, 0xFFAAAAAA, L"DoomX Network Game Setup" );

		m_Font.DrawText( m_nXOffset+ 32, 16*4, 0xFFAAAAAA, L"Enter the IP address of the game to join," );
		m_Font.DrawText( m_nXOffset+ 32, 16*5, 0xFFAAAAAA, L"And Your Player Number (1-4)" );
		m_Font.DrawText( m_nXOffset+ 32, 16*6, 0xFFAAAAAA, L"Then Press A to accept" );
		m_Font.DrawText( m_nXOffset+ 32, 16*7, 0xFFAAAAAA, L"Or Press B to cancel" );

		WCHAR str[200];

		for ( int i = 0 ; i < 18 ; i++ )
		{
			swprintf( str, L"%c", ipaddr[i] ) ;
			if ( i == curr_pos )
				m_Font.DrawText( m_nXOffset+  50 + ( i * 16 ), 16*10, 0xffFFFFFF, str ) ;
			else
				m_Font.DrawText( m_nXOffset+  50 + ( i * 16 ), 16*10, 0xffAAAAAA, str ) ;
		} 

		m_Font.End();

		m_pd3dDevice->Present( NULL, NULL, NULL, NULL );

        XBInput_GetInput();
		if ( g_Gamepads[0].hDevice && g_Gamepads[0].bPressedAnalogButtons[ XINPUT_GAMEPAD_B ] ) 
		{
			strcpy( m_ipaddr, "0.0.0.0" ) ;
			m_ipNet = '1';
			break;
		}
		else if ( g_Gamepads[0].hDevice && g_Gamepads[0].bPressedAnalogButtons[ XINPUT_GAMEPAD_A ] ) 
		{
			fpos = ipaddr ;
			epos = strchr( fpos, '.' ) ;
			*epos = 0 ;
			epos++ ;
			ip1 = atoi( fpos ) ;

			fpos = epos ;
			epos = strchr( fpos, '.' ) ;
			*epos = 0 ;
			epos++ ;
			ip2 = atoi( fpos ) ;

			fpos = epos ;
			epos = strchr( fpos, '.' ) ;
			*epos = 0 ;
			epos++ ;
			ip3 = atoi( fpos ) ;
			ip4 = atoi( epos ) ;

			sprintf( m_ipaddr, "%u.%u.%u.%u", ip1, ip2, ip3, ip4 ) ;
			m_ipNet = ipaddr[17];

			
			Sleep(500);

			break;

	 
		}
		else if ( g_Gamepads[0].hDevice && g_Gamepads[0].wPressedButtons & XINPUT_GAMEPAD_DPAD_DOWN ) 
		{
			val1 = ipaddr[curr_pos] - '0' ;

			if ( val1 == 0 )
				val1 = 9 ;
			else
				val1-- ;

			ipaddr[curr_pos] = val1 + '0' ;

		}
		else if ( g_Gamepads[0].hDevice && g_Gamepads[0].wPressedButtons & XINPUT_GAMEPAD_DPAD_UP ) 
		{
			val1 = ipaddr[curr_pos] - '0' ;

			if ( val1 == 9 )
				val1 = 0 ;
			else
				val1++ ;

			ipaddr[curr_pos] = val1 + '0' ;

		}
		else if ( g_Gamepads[0].hDevice && g_Gamepads[0].wPressedButtons & XINPUT_GAMEPAD_DPAD_LEFT ) 
		{
			switch ( curr_pos )
			{
				case 0 : curr_pos = 17 ; break ;
				case  4 : curr_pos = 2 ; break ;
				case 8 : curr_pos = 6 ; break ;
				case 12 : curr_pos = 10 ; break ;
				case 17 : curr_pos = 14 ; break ;
				default : curr_pos-- ;
			}
		}
		else if ( g_Gamepads[0].hDevice && g_Gamepads[0].wPressedButtons & XINPUT_GAMEPAD_DPAD_RIGHT ) 
		{
			switch ( curr_pos )
			{
				case 14 : curr_pos = 17 ; break ;
				case 17 : curr_pos = 0 ; break ;
				case  2 : curr_pos = 4 ; break ;
				case 6 : curr_pos = 8 ; break ;
				case 10 : curr_pos = 12 ; break ;
				default : curr_pos++ ;
			}
		}
	}


}


void CDoomXApp::init_matrices(void){
D3DXMATRIX view_matrix;
D3DXMATRIX projection_matrix;
D3DXVECTOR3 eye_vector;
D3DXVECTOR3 lookat_vector;
D3DXVECTOR3 up_vector;

   //Here we build our View Matrix, think of it as our camera.

   //First we specify that our viewpoint is 8 units back on the Z-axis
   eye_vector=D3DXVECTOR3( 0.0f, 0.0f,-8.0f );

   //We are looking towards the origin
   lookat_vector=D3DXVECTOR3( 0.0f, 0.0f, 0.0f );

   //The "up" direction is the positive direction on the y-axis
   up_vector=D3DXVECTOR3(0.0f,1.0f,0.0f);

   D3DXMatrixLookAtLH(&view_matrix,&eye_vector,
                                   &lookat_vector,
                                   &up_vector);

   //Since our 'camera' will never move, we can set this once at the
   //beginning and never worry about it again
   m_pd3dDevice->SetTransform(D3DTS_VIEW,&view_matrix);


   D3DXMatrixPerspectiveFovLH(&projection_matrix, //Result Matrix
                              D3DX_PI/4,//Field of View, in radians.(PI/4) is typical (90 degrees)
                              ((float)640 / (float)480),     //Aspect ratio
                              1.0f,     //Near view plane
                              100.0f ); // Far view plane

   //Our Projection matrix won't change either, so we set it now and never touch
   //it again.
   m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &projection_matrix );

}