
#ifndef __GAMEPADX__
#define __GAMEPADX__

#include "Windoom.h"

//============================================================
//	PROTOTYPES
//============================================================
void ProcessGamepads(void);
void DoRumbleOn(void);
void DoRumbleOff(void);
 
#endif