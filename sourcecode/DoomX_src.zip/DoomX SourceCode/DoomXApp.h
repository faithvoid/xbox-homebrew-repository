// DoomXApp.h: interface for the CDoomXApp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CDoomXApp_H__2395988B_5FA7_4DD7_A378_4E31C7FDD9B1__INCLUDED_)
#define AFX_CDoomXApp_H__2395988B_5FA7_4DD7_A378_4E31C7FDD9B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <xtl.h>
#include <Xgraphics.h>
#include <XBApp.h>
#include <XBFont.h>
#include <XBInput.h>
#include <map>
#include <vector>

#include <io.h>
//#include <errno.h>

#include "DoomX.h"
 
extern "C" 
{
	void DrawText(const char* Text);
	
}


// constants for gameselect window scrolling etc
const int GAMESEL_MaxWindowList = 19;		//19 entries (0-18)
const int GAMESEL_WindowMiddle = 9;			//10th entry (0-9)

// constants for controller dead zone / speed up banding etc.
const float GAMESEL_cfDeadZone = 0.3f;
const float GAMESEL_cfMaxThresh = 0.93f;
const float GAMESEL_cfMaxPossible = 1.0f;
const float GAMESEL_cfRectifyScale = GAMESEL_cfMaxPossible/(GAMESEL_cfMaxPossible-GAMESEL_cfDeadZone);
const float GAMESEL_cfSpeedBandFastest = 3.0f;	// seconds (don`t worry for PAL NTSC dif xbapp handles that)
const float GAMESEL_cfFastestScrollMult = 10.0f;
const float GAMESEL_cfSpeedBandMedium = 2.0f;	// if the pad is held at max for given seconds list will move faster
const float GAMESEL_cfMediumScrollMult = 5.0f;
const float GAMESEL_cfSpeedBandLowest = 1.0f;
const float GAMESEL_cfLowestScrollMult = 2.0f;

class CDoomXApp : public CXBApplication
{
public:
	CDoomXApp();
	virtual ~CDoomXApp();

	CXBFont m_Font;	// Font object	

	CXBPackedResource       m_xprResource;
    LPDIRECT3DDEVICE8       m_pd3dDevice;
    LPDIRECT3DTEXTURE8      m_pBackgroundTexture;
    LPDIRECT3DVERTEXBUFFER8 m_pVB;

 
protected:
    virtual HRESULT Initialize();
    virtual HRESULT FrameMove();
    virtual HRESULT Render();
	virtual HRESULT Cleanup();
	virtual void doJoinGame();
	void MoveCursor();
	void FindAvailRoms();
	
	std::string GetROMTitalFromFile(const char *);
	
private:
	float fGameSelect;
	float fCursorPos;
	float fMaxCount; 
	float m_fFrameTime;			// amount of time per frame

	int   iGameSelect;
	int   iCursorPos;
	int   iNumGames;
	int   m_iMaxWindowList;
	int   m_iWindowMiddle;

	std::vector<std::string> m_vecAvailRoms;
	std::vector<std::string> m_vecAvailRomsFullName;

	DWORD cFLASHER;
	bool flashDir;

	int					m_lastPadValues[2] ;
	BOOL				m_bAmServer ;
	BOOL				m_bNetplay ;
	int		m_nXOffset, m_nFontHeight ;


	void init_matrices(void);
 
};
#endif