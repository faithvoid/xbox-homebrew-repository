// Standard Xbox headers

#include <xtl.h>
#include <XBInput.h>

DWORD hRumble;
int	nWeapPos = 0x02;


VOID CALLBACK DoRumbleOff( UINT idEvent, UINT uMsg, DWORD dwUser, DWORD dw1, DWORD dw2)
{

	timeKillEvent(hRumble);

	g_Gamepads[0].Feedback.Rumble.wLeftMotorSpeed  = WORD(0);
    g_Gamepads[0].Feedback.Rumble.wRightMotorSpeed = WORD(0);
    XInputSetState( g_Gamepads[0].hDevice, &g_Gamepads[0].Feedback );


}

extern "C" 
{
	#include "Windoom.h"
	#include "DoomGamePad.h"
	#include "doomdef.h"
	#include "doomstat.h"
	#include "d_event.h"
	#include "d_main.h"
	#include "m_argv.h"
	#include "g_game.h"
	#include "i_system.h"
	#include "m_misc.h"

	int    joyb1;
	int    joyb2;
	int    joyb3;
	int    joyb4;
	int    mouseb1;
	int    mouseb2;
	int    mouseb3;
	int    always_run;
	
}



void ProcessGamepads(void)
{

	static  event_t  event;
    static  event_t  kbevent;

	static DWORD	dwLastX = 0;
	static DWORD	dwLastY = 0;

	DWORD	dwX = 0;
	DWORD	dwY = 0;

	// scan our gamepads
	
	XBInput_GetInput(g_Gamepads);


	event.type = ev_joystick;
    event.data1 = 0;
	event.data2 = 0;
	event.data3 = 0;

	if (g_Gamepads[0].sThumbLY <= -12000 || g_Gamepads[0].wButtons & XINPUT_GAMEPAD_DPAD_DOWN)
	{

        event.data3 = 1;
	}
	else if (g_Gamepads[0].sThumbLY >= 12000 || g_Gamepads[0].wButtons & XINPUT_GAMEPAD_DPAD_UP)
	{

        event.data3 = -1;
	}
	else
		event.data3 = 0;

	if (g_Gamepads[0].sThumbRX <= -12000)
        event.data2 = -1;
	else if (g_Gamepads[0].sThumbRX >= 12000)
        event.data2 = 1;
	else
		event.data2 = 0;
      
 
	D_PostEvent(&event);

	// Process Keypresses

		if (g_Gamepads[0].bAnalogButtons[XINPUT_GAMEPAD_LEFT_TRIGGER] > 0)
			always_run = TRUE;
		else
			always_run = FALSE;
		
	
		if (g_Gamepads[0].bAnalogButtons[XINPUT_GAMEPAD_RIGHT_TRIGGER] > 0)
		{
			kbevent.type = ev_keydown;
			kbevent.data1 = KEY_RCTRL;
			D_PostEvent(&kbevent);
	
		}
		else if (g_Gamepads[0].bPressedAnalogButtons[XINPUT_GAMEPAD_X] > 0)
		{
			kbevent.type = ev_keydown;
			kbevent.data1 = KEY_ENTER;
			D_PostEvent(&kbevent);
	
		}
		else if (g_Gamepads[0].bPressedAnalogButtons[XINPUT_GAMEPAD_Y] > 0)
		{
			kbevent.type = ev_keydown;
			kbevent.data1 = KEY_TAB;
			D_PostEvent(&kbevent);
	
		}
		else if (g_Gamepads[0].bAnalogButtons[XINPUT_GAMEPAD_A] > 0)
		{
			kbevent.type = ev_keydown;
			kbevent.data1 = KEY_SPACE;
			D_PostEvent(&kbevent);
	
		}
		else
		{
			kbevent.type = ev_keyup;
			kbevent.data1 = KEY_RCTRL;
			D_PostEvent(&kbevent);

			kbevent.type = ev_keyup;
			kbevent.data1 = KEY_ENTER;
			D_PostEvent(&kbevent);

			kbevent.type = ev_keyup;
			kbevent.data1 = KEY_SPACE;
			D_PostEvent(&kbevent);

			kbevent.type = ev_keyup;
			kbevent.data1 = KEY_TAB;
			D_PostEvent(&kbevent);
		}




		if (g_Gamepads[0].sThumbLX <= -22000)
		{
			kbevent.type = ev_keydown;
			kbevent.data1 = KEY_COMMA;
			D_PostEvent(&kbevent);
    
		}
		else if (g_Gamepads[0].sThumbLX >= 22000)
        {


			kbevent.type = ev_keydown;
			kbevent.data1 = KEY_PERIOD;
			D_PostEvent(&kbevent);
		}
		else if (g_Gamepads[0].wPressedButtons & XINPUT_GAMEPAD_START)
		{
			kbevent.type = ev_keydown;
			kbevent.data1 = KEY_ESCAPE;
			D_PostEvent(&kbevent);
		}
		else
		{

			kbevent.type = ev_keyup;
			kbevent.data1 = KEY_COMMA;
			D_PostEvent(&kbevent);

			kbevent.type = ev_keyup;
			kbevent.data1 = KEY_PERIOD;
			D_PostEvent(&kbevent);

			kbevent.type = ev_keyup;
			kbevent.data1 = KEY_ESCAPE;
			D_PostEvent(&kbevent);

		
		}


		if (g_Gamepads[0].bPressedAnalogButtons[XINPUT_GAMEPAD_BLACK] > 0)
		{
			nWeapPos++;

			if (nWeapPos > NUMWEAPONS)
				nWeapPos = KEY_1;

			kbevent.type = ev_keydown;
			kbevent.data1 = nWeapPos;
			D_PostEvent(&kbevent);
		}
		else if (g_Gamepads[0].bPressedAnalogButtons[XINPUT_GAMEPAD_WHITE] > 0)
		{
			nWeapPos--;

			if (nWeapPos < KEY_1)
				nWeapPos = NUMWEAPONS;

			kbevent.type = ev_keydown;
			kbevent.data1 = nWeapPos;
			D_PostEvent(&kbevent);
		}
		else
		{
			kbevent.type = ev_keyup;
			kbevent.data1 = nWeapPos;
			D_PostEvent(&kbevent);

			kbevent.type = ev_keyup;
			kbevent.data1 = nWeapPos;
			D_PostEvent(&kbevent);

		}
	
		dwLastX = dwX;
 
 

}

void DoRumbleOn(void)
{
		hRumble = timeSetEvent(100,0,DoRumbleOff,0,TIME_ONESHOT);

        if( g_Gamepads[0].hDevice )
        {
            
            if( g_Gamepads[0].Feedback.Header.dwStatus != ERROR_IO_PENDING )
            {
                
                g_Gamepads[0].Feedback.Rumble.wLeftMotorSpeed  = WORD(0  * 65535.0f );
                g_Gamepads[0].Feedback.Rumble.wRightMotorSpeed = WORD(0.90 * 65535.0f );
                XInputSetState( g_Gamepads[0].hDevice, &g_Gamepads[0].Feedback );
            }


			
        }
    
}



