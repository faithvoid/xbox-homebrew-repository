/***************************************************************************/
/*                                                                         */
/* text.cpp                                                                */
/*                                                                         */
/***************************************************************************/
//Main header file for the XDK

#include <xfont.h>

#include <xtl.h>

#include <stdio.h>


// NEW NEW NEW NEW
XFONT*      m_pArial16BitmapFont;    // Pointer to the Arial16Normal Bitmap font    
XFONT*      m_pArial18BitmapFont;    // Pointer to the Arial18Normal Bitmap font    

LPDIRECT3DSURFACE8 g_pFrontBuffer;

XFONT*      m_pArialFont;

void InitialiseFonts()
{
	// NEW NEW NEW NEW
    g_pd3dDevice->GetBackBuffer(-1,D3DBACKBUFFER_TYPE_MONO,&g_pFrontBuffer);
    
	DWORD dwFontCacheSize = 16 * 1024; //1024 

	XFONT_OpenBitmapFont( L"D:\\Media\\Fonts\\Arial16Normal.bmf",
                           dwFontCacheSize, &m_pArial16BitmapFont );

	XFONT_OpenBitmapFont( L"D:\\Media\\Fonts\\Arial18Normal.bmf",
                           dwFontCacheSize, &m_pArial18BitmapFont );

	XFONT_OpenBitmapFont( L"D:\\Media\\Fonts\\times40font.bmf",
							dwFontCacheSize, &m_pArialFont);
}


void TextOut(long x_pos, long y_pos, WCHAR * szText)
{
	m_pArial16BitmapFont->TextOut( g_pFrontBuffer, szText, -1, x_pos, y_pos );
}

void TextOut(long x_pos, long y_pos, int NumberToText, int big=0, int rval=255, int gval=255, int bval=255)
{
	WCHAR strBuffer[100] = {0};

	swprintf(strBuffer,    // output buffer
				L"Frames Per Second %d",   // format-control string
				NumberToText);

	swprintf( strBuffer, L"%d", NumberToText );

	if ( big == 0 )
	{
		m_pArial16BitmapFont->SetTextColor(D3DCOLOR_XRGB(rval,gval,bval));
		m_pArial16BitmapFont->TextOut( g_pFrontBuffer, strBuffer, -1, x_pos, y_pos );
	}

	else
	{
		m_pArial18BitmapFont->SetTextColor(D3DCOLOR_XRGB(rval,gval,bval));
		m_pArial18BitmapFont->TextOut( g_pFrontBuffer, strBuffer, -1, x_pos, y_pos );
	}
}

void TextOut(long x_pos, long y_pos, float NumberToText, int big=0, int rval=255, int gval=255, int bval=255)
{
	// NEW NEW NEW NEW
	WCHAR strBuffer[100] = {0};

	swprintf(strBuffer,    // output buffer
				L"Frames Per Second %d",   // format-control string
				NumberToText);

	swprintf( strBuffer, L"%.2f", NumberToText );

	if ( big == 0 )
	{
		m_pArial16BitmapFont->SetTextColor(D3DCOLOR_XRGB(rval,gval,bval));
		m_pArial16BitmapFont->TextOut( g_pFrontBuffer, strBuffer, -1, x_pos, y_pos );
	}

	else
	{
		m_pArial18BitmapFont->SetTextColor(D3DCOLOR_XRGB(rval,gval,bval));
		m_pArial18BitmapFont->TextOut( g_pFrontBuffer, strBuffer, -1, x_pos, y_pos );
	}
}


void TextOutLarge(long x_pos, long y_pos, WCHAR * szText)
{

		m_pArialFont->TextOut( g_pFrontBuffer, szText, -1, x_pos, y_pos );

}


void DestroyFonts()
{
}