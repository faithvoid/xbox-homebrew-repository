void load_textures(void)
{
	
	D3DXCreateTextureFromFile( g_pd3dDevice, "d:\\media\\gfx\\mainmenu.bmp", &g_pMainMenuTexture);
	D3DXCreateTextureFromFile( g_pd3dDevice, "d:\\media\\gfx\\loading.bmp", &g_pLoadingTexture);
	D3DXCreateTextureFromFile( g_pd3dDevice, "d:\\media\\gfx\\back1.bmp", &g_pBackTexture);

	D3DXCreateTextureFromFileExA(
		g_pd3dDevice,
		"d:\\media\\gfx\\enemy1.bmp",
		0, 0,				// use values from file for width height
		0,					// full level of mipmapping
		0,					// Not used as a rendertarget()
		D3DFMT_A8R8G8B8,	// requested pixel format for image
		D3DPOOL_MANAGED,	// 
		D3DX_FILTER_LINEAR,	// filter
		D3DX_FILTER_LINEAR,	// mip filter
		D3DCOLOR_ARGB(255,0,0,0),	// set black as opaque
		NULL,				// dont return info on created texture
		NULL,				// no pallette entry
		&g_pEnemy1Texture);		// pointer to texture
	
	
	if (g_pEnemy1Texture == NULL){
//		MessageBox(NULL, "Error", "Error opening texture enemy", MB_OK);
	}

	D3DXCreateTextureFromFileExA(
		g_pd3dDevice,
		"d:\\media\\gfx\\enemy2.bmp",
		0, 0,				// use values from file for width height
		0,					// full level of mipmapping
		0,					// Not used as a rendertarget()
		D3DFMT_A8R8G8B8,	// requested pixel format for image
		D3DPOOL_MANAGED,	// 
		D3DX_FILTER_LINEAR,	// filter
		D3DX_FILTER_LINEAR,	// mip filter
		D3DCOLOR_ARGB(255,0,0,0),	// set black as opaque
		NULL,				// dont return info on created texture
		NULL,				// no pallette entry
		&g_pEnemy2Texture);		// pointer to texture
	
	
	if (g_pEnemy2Texture == NULL){
//		MessageBox(NULL, "Error", "Error opening texture enemy", MB_OK);
	}

	
	D3DXCreateTextureFromFileExA(
		g_pd3dDevice,
		"d:\\media\\gfx\\player.bmp",
		0, 0,				// use values from file for width height
		0,					// full level of mipmapping
		0,					// Not used as a rendertarget()
		D3DFMT_A8R8G8B8,	// requested pixel format for image
		D3DPOOL_MANAGED,	// 
		D3DX_FILTER_LINEAR,	// filter
		D3DX_FILTER_LINEAR,	// mip filter
		D3DCOLOR_ARGB(255,0,0,0),	// set black as opaque
		NULL,				// dont return info on created texture
		NULL,				// no pallette entry
		&g_pPlayerTexture);		// pointer to texture
	if (g_pPlayerTexture == NULL){
//		MessageBox(NULL, "Error", "Error opening texture player", MB_OK);
	}

	D3DXCreateTextureFromFileExA(
		g_pd3dDevice,
		"d:\\media\\gfx\\bullet.bmp",
		0, 0,				// use values from file for width height
		0,					// full level of mipmapping
		0,					// Not used as a rendertarget()
		D3DFMT_A8R8G8B8,	// requested pixel format for image
		D3DPOOL_MANAGED,	// 
		D3DX_FILTER_LINEAR,	// filter
		D3DX_FILTER_LINEAR,	// mip filter
		D3DCOLOR_ARGB(255,0,0,0),	// set black as opaque
		NULL,				// dont return info on created texture
		NULL,				// no pallette entry
		&g_pBulletTexture);		// pointer to texture
	if (g_pBulletTexture == NULL){
//		MessageBox(NULL, "Error", "Error opening texture bullet", MB_OK);
	}

	D3DXCreateTextureFromFileExA(
		g_pd3dDevice,
		"d:\\media\\gfx\\explosion.bmp",
		0, 0,				// use values from file for width height
		0,					// full level of mipmapping
		0,					// Not used as a rendertarget()
		D3DFMT_A8R8G8B8,	// requested pixel format for image
		D3DPOOL_MANAGED,	// 
		D3DX_FILTER_LINEAR,	// filter
		D3DX_FILTER_LINEAR,	// mip filter
		D3DCOLOR_ARGB(255,0,0,0),	// set black as opaque
		NULL,				// dont return info on created texture
		NULL,				// no pallette entry
		&g_pExplosionTexture);		// pointer to texture
	if (g_pExplosionTexture == NULL){
//		MessageBox(NULL, "Error", "Error opening texture explosion", MB_OK);
	}

	D3DXCreateTextureFromFileExA(
		g_pd3dDevice,
		"d:\\media\\gfx\\getready.bmp",
		0, 0,				// use values from file for width height
		0,					// full level of mipmapping
		0,					// Not used as a rendertarget()
		D3DFMT_A8R8G8B8,	// requested pixel format for image
		D3DPOOL_MANAGED,	// 
		D3DX_FILTER_LINEAR,	// filter
		D3DX_FILTER_LINEAR,	// mip filter
		D3DCOLOR_ARGB(255,0,0,0),	// set black as opaque
		NULL,				// dont return info on created texture
		NULL,				// no pallette entry
		&g_pGetReadyTexture);		// pointer to texture
	
	
	if (g_pGetReadyTexture == NULL){
//		MessageBox(NULL, "Error", "Error opening texture get ready!", MB_OK);
	}

	D3DXCreateTextureFromFileExA(
		g_pd3dDevice,
		"d:\\media\\gfx\\gameover.bmp",
		0, 0,				// use values from file for width height
		0,					// full level of mipmapping
		0,					// Not used as a rendertarget()
		D3DFMT_A8R8G8B8,	// requested pixel format for image
		D3DPOOL_MANAGED,	// 
		D3DX_FILTER_LINEAR,	// filter
		D3DX_FILTER_LINEAR,	// mip filter
		D3DCOLOR_ARGB(255,0,0,0),	// set black as opaque
		NULL,				// dont return info on created texture
		NULL,				// no pallette entry
		&g_pGameOverTexture);		// pointer to texture
	
	
	if (g_pGameOverTexture == NULL){
//		MessageBox(NULL, "Error", "Error opening texture game over!", MB_OK);
	}

	D3DXCreateTextureFromFileExA(
		g_pd3dDevice,
		"d:\\media\\gfx\\powerup_d.bmp",
		0, 0,				// use values from file for width height
		0,					// full level of mipmapping
		0,					// Not used as a rendertarget()
		D3DFMT_A8R8G8B8,	// requested pixel format for image
		D3DPOOL_MANAGED,	// 
		D3DX_FILTER_LINEAR,	// filter
		D3DX_FILTER_LINEAR,	// mip filter
		D3DCOLOR_ARGB(255,0,0,0),	// set black as opaque
		NULL,				// dont return info on created texture
		NULL,				// no pallette entry
		&g_pPowerUpBulletSpeedTexture);		// pointer to texture
	
	
	if (g_pPowerUpBulletSpeedTexture == NULL){
//		MessageBox(NULL, "Error", "Error opening texture game over!", MB_OK);
	}

	D3DXCreateTextureFromFileExA(
		g_pd3dDevice,
		"d:\\media\\gfx\\powerup_s.bmp",
		0, 0,				// use values from file for width height
		0,					// full level of mipmapping
		0,					// Not used as a rendertarget()
		D3DFMT_A8R8G8B8,	// requested pixel format for image
		D3DPOOL_MANAGED,	// 
		D3DX_FILTER_LINEAR,	// filter
		D3DX_FILTER_LINEAR,	// mip filter
		D3DCOLOR_ARGB(255,0,0,0),	// set black as opaque
		NULL,				// dont return info on created texture
		NULL,				// no pallette entry
		&g_pPowerUpSuperShotTexture);		// pointer to texture
	
	if (g_pPowerUpSuperShotTexture == NULL){
//		MessageBox(NULL, "Error", "Error opening texture game over!", MB_OK);
	}

	
	D3DXCreateTextureFromFileExA(
		g_pd3dDevice,
		"d:\\media\\gfx\\mothership.bmp",
		0, 0,				// use values from file for width height
		0,					// full level of mipmapping
		0,					// Not used as a rendertarget()
		D3DFMT_A8R8G8B8,	// requested pixel format for image
		D3DPOOL_MANAGED,	// 
		D3DX_FILTER_LINEAR,	// filter
		D3DX_FILTER_LINEAR,	// mip filter
		D3DCOLOR_ARGB(255,0,0,0),	// set black as opaque
		NULL,				// dont return info on created texture
		NULL,				// no pallette entry
		&g_pMothershipTexture);		// pointer to texture
	
	
	if (g_pMothershipTexture == NULL){
//		MessageBox(NULL, "Error", "Error opening texture game over!", MB_OK);
	}

	D3DXCreateTextureFromFileExA(
		g_pd3dDevice,
		"d:\\media\\gfx\\shield.bmp",
		0, 0,				// use values from file for width height
		0,					// full level of mipmapping
		0,					// Not used as a rendertarget()
		D3DFMT_A8R8G8B8,	// requested pixel format for image
		D3DPOOL_MANAGED,	// 
		D3DX_FILTER_LINEAR,	// filter
		D3DX_FILTER_LINEAR,	// mip filter
		D3DCOLOR_ARGB(255,0,0,0),	// set black as opaque
		NULL,				// dont return info on created texture
		NULL,				// no pallette entry
		&g_pPlayerShieldTexture);		// pointer to texture
	
	
	if (g_pPlayerShieldTexture == NULL){
	//	MessageBox(NULL, "Error", "Error opening texture shield", MB_OK);
	}

}


void free_textures(void)
{
	g_pBackTexture->Release();
	g_pEnemy1Texture->Release();
	g_pEnemy2Texture->Release();
	g_pPlayerTexture->Release();
	g_pBulletTexture->Release();
	g_pExplosionTexture->Release();
	g_pLoadingTexture->Release();
	g_pGetReadyTexture->Release();
	g_pGameOverTexture->Release();
	g_pPowerUpSuperShotTexture->Release();
	g_pPowerUpBulletSpeedTexture->Release();
	g_pMothershipTexture->Release();
	g_pPlayerShieldTexture->Release();
	g_pMainMenuTexture->Release();
}


