void render_ingame(void)
{

		
	
// Z-ORDER

// background		1.00
// enemy bullets	0.95
// enemies			0.90
// player bullets	0.85
// player			0.80

	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	// Render background
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	g_pd3dDevice->SetTexture(0, g_pBackTexture);
	g_pd3dDevice->SetVertexShader(D3DFVF_CUSTOM_TRANSFORMED_VERTEX); 
	g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, back_verts, sizeof(TRANSFORMED_VERTEX));

	
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	// Render bullets
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	g_pd3dDevice->SetTexture(0, g_pBulletTexture);
	for (int j=0; j<enemy_count;j++){
		if (enemy[j].bullet == true){
			g_pd3dDevice->SetVertexShader(D3DFVF_CUSTOM_TRANSFORMED_VERTEX);
			g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, enemy[j].bverts, sizeof(TRANSFORMED_VERTEX));
		}
	}

	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	// Render enemies
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

	for (j=0; j<6*15;j++){
		if (enemy[j].alive == true){
			if (enemy[j].type == 1){
				g_pd3dDevice->SetTexture(0, g_pEnemy2Texture);
			}
			if (enemy[j].type == 2){
				g_pd3dDevice->SetTexture(0, g_pEnemy1Texture);
			}
			g_pd3dDevice->SetVertexShader(D3DFVF_CUSTOM_TRANSFORMED_VERTEX); 
			g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, enemy[j].verts, sizeof(TRANSFORMED_VERTEX));
		}
	}

	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	// Render mothership
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	if (mothership.alive == true){
		g_pd3dDevice->SetTexture(0, g_pMothershipTexture);
		g_pd3dDevice->SetVertexShader(D3DFVF_CUSTOM_TRANSFORMED_VERTEX_ALPHA); 
		g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, mothership.verts, sizeof(TRANSFORMED_VERTEX_ALPHA));
	}

	
	
	
	
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	// Render player bullet
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	if (player.bullet == true){
		g_pd3dDevice->SetTexture(0, g_pBulletTexture);
		g_pd3dDevice->SetVertexShader(D3DFVF_CUSTOM_TRANSFORMED_VERTEX);
		g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, player.bverts, sizeof(TRANSFORMED_VERTEX));
	}

	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	// Render player
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	if (game_state != GS_GAMEOVER){
		g_pd3dDevice->SetTexture(0, g_pPlayerTexture);
		g_pd3dDevice->SetVertexShader(D3DFVF_CUSTOM_TRANSFORMED_VERTEX);
		g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, player.verts, sizeof(TRANSFORMED_VERTEX));
	}
		
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	// Render shield
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	if (player.powerup == PU_SHIELD){
		if (game_state != GS_GAMEOVER){
			g_pd3dDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_ARGB(150, 255,255,255) );
			g_pd3dDevice->SetTexture(0, g_pPlayerShieldTexture);
			g_pd3dDevice->SetVertexShader(D3DFVF_CUSTOM_TRANSFORMED_VERTEX);
			g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, player.verts, sizeof(TRANSFORMED_VERTEX));
			g_pd3dDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_ARGB(255, 255,255,255) );
		}
	}

	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	// Render powerups
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	for (j=0; j<MAX_POWERUPS;j++){
		if (powerup[j].alive == true){
			
			// select texture for powerup
			if (powerup[j].type == PU_SUPERSHOT){
				g_pd3dDevice->SetTexture(0, g_pPowerUpSuperShotTexture);
			}
			if (powerup[j].type == PU_BULLETSPEED){
				g_pd3dDevice->SetTexture(0, g_pPowerUpBulletSpeedTexture);
			}
			if (powerup[j].type == PU_SHIELD){
				g_pd3dDevice->SetTexture(0, g_pExplosionTexture);
			}
			
			// and render
			g_pd3dDevice->SetVertexShader(D3DFVF_CUSTOM_TRANSFORMED_VERTEX_ALPHA);
			g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, powerup[j].verts, sizeof(TRANSFORMED_VERTEX_ALPHA));
		}
	}

	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	// Render explosions
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	g_pd3dDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_ARGB(150, 255,255,255) );
	g_pd3dDevice->SetTexture(0, g_pExplosionTexture);

	for (j=0; j<50; j++){
		if (explosion[j].alive == true){
			g_pd3dDevice->SetVertexShader(D3DFVF_CUSTOM_TRANSFORMED_VERTEX_ALPHA);
			g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, explosion[j].verts, sizeof(TRANSFORMED_VERTEX_ALPHA));
		}
	}
	g_pd3dDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_ARGB(255, 255,255,255) );
	
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	// rendering states
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

}


void render_loading(void)
{
	g_pd3dDevice->SetTexture(0, g_pLoadingTexture);
	g_pd3dDevice->SetVertexShader(D3DFVF_CUSTOM_TRANSFORMED_VERTEX); 
	g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, back_verts, sizeof(TRANSFORMED_VERTEX));
}


void render_getready(void)
{
	render_ingame();
	
	g_pd3dDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_ARGB(200, 255,255,255) );
	render_quad_alpha(0, 200, 0.3f, 640, 100, g_pGetReadyTexture);
	g_pd3dDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_ARGB(255, 255,255,255) );

}

void render_gameover(void)
{
	render_ingame();

	g_pd3dDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_ARGB(200, 255,255,255) );
	render_quad_alpha(0, 200, 0.3f, 640, 100, g_pGameOverTexture);
	g_pd3dDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_ARGB(255, 255,255,255) );
}
	
void render_mainmenu(void)
{
	g_pd3dDevice->SetTexture(0, g_pMainMenuTexture);
	g_pd3dDevice->SetVertexShader(D3DFVF_CUSTOM_TRANSFORMED_VERTEX); 
	g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, back_verts, sizeof(TRANSFORMED_VERTEX));
}
