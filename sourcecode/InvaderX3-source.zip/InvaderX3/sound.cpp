
bool dmusic_init(void)
{
	return false;
}
