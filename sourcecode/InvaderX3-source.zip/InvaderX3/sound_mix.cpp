#include <xtl.h>


#include "sound.h"


IDirectMusicSegment8*	sample_player_shoot	=	NULL;
IDirectMusicSegment8*	sample_player_die	=	NULL;
IDirectMusicSegment8*	sample_enemy_shoot	=	NULL;
IDirectMusicSegment8*	sample_enemy_die	=	NULL;
IDirectMusicSegment8*	sample_playerup		=	NULL;
IDirectMusicSegment8*	sample_lifeup		=	NULL;
IDirectMusicSegment8*	sample_warning		=	NULL;
IDirectMusicSegment8*	sample_get_ready	=	NULL;
IDirectMusicSegment8*	sample_mothership	=	NULL;
IDirectMusicSegment8*	sample_killmship	=	NULL;


void InitSound()
{

	//--------------------------------------------------------------
//               AUDIO
//--------------------------------------------------------------

// Initialize DMusic
    IDirectMusicHeap* pNormalHeap;
    DirectMusicCreateDefaultHeap( &pNormalHeap );

    IDirectMusicHeap* pPhysicalHeap;
    DirectMusicCreateDefaultPhysicalHeap( &pPhysicalHeap );

   DirectMusicInitializeEx( pNormalHeap, pPhysicalHeap, &DirectMusicDefaultFactory );

    pNormalHeap->Release();
    pPhysicalHeap->Release();


    // Create loader object
    DirectMusicCreateInstance( CLSID_DirectMusicLoader, NULL,
                               IID_IDirectMusicLoader8, (VOID**)&g_pLoader );

    // Create performance object
    DirectMusicCreateInstance( CLSID_DirectMusicPerformance, NULL,
                               IID_IDirectMusicPerformance8, (VOID**)&g_pPerformance );

    // Initialize the performance with the standard audio path.
    // The flags (final) argument allows us to specify whether or not we want
    // DirectMusic to create a thread on our behalf to process music, using
    // DMUS_INITAUDIO_NOTHREADS.  The default is for DirectMusic to create its
    // own thread; DMUS_INITAUDIO_NOTHREADS tells DirectMusic not to do this,
    // and the app will periodically call DirectMusicDoWork().  For software
    // emulation on alpha hardware, it's generally better to have DirectMusic
    // create its own thread. On real hardware, periodically calling
    // DirectMusicDoWork may provide a better option.
	  g_pPerformance->InitAudioX( DMUS_INITAUDIO_NOTHREADS, 64, 128, 0 );

    // Tell DirectMusic where the default search path is
    g_pLoader->SetSearchDirectory( GUID_DirectMusicAllTypes,
                                   "D:\\Media\\Sounds", FALSE );

  //  // Load main music
  g_pLoader->LoadObjectFromFile( CLSID_DirectMusicSegment, IID_IDirectMusicSegment8,
                                   "xdk1.sgt", (VOID**)&g_pMusic );

    
  
  
  
  
  
  
  
  
  
	// Load a sound effect
	g_pLoader->LoadObjectFromFile(	CLSID_DirectMusicSegment, IID_IDirectMusicSegment8,
									"laser.wav", (VOID**)&sample_player_shoot );
	
	g_pLoader->LoadObjectFromFile(	CLSID_DirectMusicSegment, IID_IDirectMusicSegment8,
									"roidexpl.wav", (VOID**)&sample_player_die );

	g_pLoader->LoadObjectFromFile(	CLSID_DirectMusicSegment, IID_IDirectMusicSegment8,
									"gun.wav", (VOID**)&sample_enemy_shoot );
	
	g_pLoader->LoadObjectFromFile(	CLSID_DirectMusicSegment, IID_IDirectMusicSegment8,
									"die.wav", (VOID**)&sample_enemy_die );

	g_pLoader->LoadObjectFromFile(	CLSID_DirectMusicSegment, IID_IDirectMusicSegment8,
									"bonus1.wav", (VOID**)&sample_playerup );
	
	g_pLoader->LoadObjectFromFile(	CLSID_DirectMusicSegment, IID_IDirectMusicSegment8,
									"lifeup.wav", (VOID**)&sample_lifeup );

	g_pLoader->LoadObjectFromFile(	CLSID_DirectMusicSegment, IID_IDirectMusicSegment8,
									"warning.wav", (VOID**)&sample_warning );
	
	g_pLoader->LoadObjectFromFile(	CLSID_DirectMusicSegment, IID_IDirectMusicSegment8,
									"getready.wav", (VOID**)&sample_get_ready );
    
	g_pLoader->LoadObjectFromFile(	CLSID_DirectMusicSegment, IID_IDirectMusicSegment8,
									"mothership.wav", (VOID**)&sample_mothership );
 	
	g_pLoader->LoadObjectFromFile(	CLSID_DirectMusicSegment, IID_IDirectMusicSegment8,
									"killmship.wav", (VOID**)&sample_killmship );
	
	
	
	
	
	
	// Set the music to repeat for a while...
    g_pMusic->SetRepeats( 1 ); //0 for infinite

    //// Play segment on the default audio path
    //g_pPerformance->PlaySegmentEx( g_pMusic, NULL, NULL, 0,
//                                   0, NULL, NULL, NULL );

    // Get default (music) audiopath.
    g_pPerformance->GetDefaultAudioPath( &g_pMusicAudioPath );

    // Max volume for music
    g_pMusicAudioPath->SetVolume( (100*100)-10000, 0 );

//    If the application doesn't care about vertical HRTF positioning,
//       calling DirectSoundUseLightHRTF can save about 60k of memory. /
    // DirectSoundUseLightHRTF();
    DirectSoundUseFullHRTF();

    // Create a 3D audiopath
    g_pPerformance->CreateStandardAudioPath( DMUS_APATH_DYNAMIC_3D, 64,
                                             TRUE, &g_p3DAudioPath1 );





	//m_fGrooveLevel =  50.0f;
    m_fVolume      = 200.0f;

	DirectSoundCreate( NULL, &m_pDSound, NULL );

	//plays soudn in the background
//	m_Stream.Initialize( "D:\\Media\\Sounds\\default.wma", NULL );

	DirectSoundCreate( NULL, &m_pDSound, NULL );

    //
    // download the standard DirectSound effecs image
    //
    DownloadEffectsImage("d:\\media\\sounds\\dsstdfx.bin");



    m_dwPercentCompleted = 0;

    // Create worker thread to process audio
    m_hWorkerThread = CreateThread( NULL, 0, WMAFileStreamThreadProc, &m_Stream, 0, NULL );
    if( m_hWorkerThread == NULL )

	HRESULT DownloadEffectsImage(PCHAR pszScratchFile);

	DirectSoundCreate( NULL, &m_pDSound, NULL );


}

///////End sound init function /////////////////////////////////////////////