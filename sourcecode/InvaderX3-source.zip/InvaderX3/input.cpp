#define NUM_PORTS   1       // Number of controller ports.
//#define NUM_SLOTS	1

//char g_chMUDrives[NUM_PORTS][NUM_SLOTS];
HANDLE g_hPads[NUM_PORTS];


XDEVICE_PREALLOC_TYPE xdpt[] = {
	{XDEVICE_TYPE_GAMEPAD, 1},
//	{XDEVICE_TYPE_MEMORY_UNIT, 8}
};

struct DEVICE_STATE {
    XPP_DEVICE_TYPE *pxdt;
    DWORD dwState;
};

DEVICE_STATE g_dsDevices[] = {
    { XDEVICE_TYPE_GAMEPAD, 0 },
 //   { XDEVICE_TYPE_MEMORY_UNIT, 0 },
};

#define NUM_DEVICE_STATES   (sizeof(g_dsDevices)/sizeof(*g_dsDevices))

void HandleDeviceChanges(XPP_DEVICE_TYPE *pxdt, DWORD dwInsert, DWORD dwRemove );
//void ShowMUInfo( char chDrive );
//void EnumSavedGames( char chDrive );
HANDLE GetFirstController( void );


void device_init( void )
{
	int i;
    // Initialize the peripherals.
    XInitDevices( sizeof(xdpt) / sizeof(XDEVICE_PREALLOC_TYPE), xdpt );

    // Set device handles to invalid.
    ZeroMemory( g_hPads, sizeof(g_hPads) );

    // Set drive letters to invalid.
//    ZeroMemory( g_chMUDrives, sizeof(g_chMUDrives) );

	// Get initial state of all connected devices.
    for( i = 0; i < NUM_DEVICE_STATES; i++ )
    {
        g_dsDevices[i].dwState = XGetDevices( g_dsDevices[i].pxdt );
        HandleDeviceChanges( g_dsDevices[i].pxdt, g_dsDevices[i].dwState, 0 );
    }
}

void CheckDeviceChanges( DEVICE_STATE *pdsDevices )
{
    DWORD dwInsert, dwRemove;
    int i;

    // Check each device type to see if any changes have occurred.
    for( i = 0; i < NUM_DEVICE_STATES; i++ )
    {
        if( XGetDeviceChanges( pdsDevices[i].pxdt, &dwInsert, &dwRemove ) )
        {
            // Call handler to service the insertion and/or removal.
            HandleDeviceChanges( pdsDevices[i].pxdt, dwInsert, dwRemove );

            // Update new device state.
            pdsDevices[i].dwState &= ~dwRemove;
            pdsDevices[i].dwState |= dwInsert;
        }
    }
}

void HandleDeviceChanges(XPP_DEVICE_TYPE *pxdt, DWORD dwInsert, DWORD dwRemove )
{
    DWORD iPort;
    char szDrive[] = "X:\\";
	static int old_game_state;


    if( XDEVICE_TYPE_GAMEPAD == pxdt)
    {
        for( iPort = 0; iPort < NUM_PORTS; iPort++ )
        {
            // Close removals.
            if( (1 << iPort & dwRemove) && g_hPads[iPort] )
            {
                XInputClose( g_hPads[iPort] );
                g_hPads[iPort] = 0;
           }

            // Open insertions.
            if( 1 << iPort & dwInsert )
            {
                g_hPads[iPort] = XInputOpen( pxdt, iPort, XDEVICE_NO_SLOT, NULL );
           }
        }
    }

    return;
}


//
// Get latest gamepad state.
//
void ReadGamepad( void )
{
    static DWORD dwStartLast = 0;
    DWORD dwStartDown;
    XINPUT_STATE xis;
    HANDLE hPad;

    // Find first connected controller.
    if( !(hPad = GetFirstController()) )
    {
        return;
    }

    // Query latest state.
    XInputGetState( hPad, &xis );

    // Has the start button changed state?
    dwStartDown = xis.Gamepad.wButtons & XINPUT_GAMEPAD_START;
    if( dwStartDown != dwStartLast ){
		dwStartLast = dwStartDown;
		player.x++;
	}
}

void ReadGamepad2( void )
{
	// DPAD_LEFT move left		#define XINPUT_GAMEPAD_DPAD_LEFT        0x00000004
	// DPAD_RIGHT move right	#define XINPUT_GAMEPAD_DPAD_RIGHT       0x00000008
	// BUTTON_A fire			#define XINPUT_GAMEPAD_A                0
	// START restart level
    
    HANDLE hPad;
	XINPUT_STATE xis;

	DWORD dwSTART;
	DWORD dwDPAD_LEFT;
	DWORD dwDPAD_RIGHT;
	DWORD dwBACK;
	
	if( !(hPad = GetFirstController()) ){
		return;
	}

	// Get latest state
	XInputGetState(hPad, &xis);

	dwDPAD_LEFT = xis.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT;
	dwDPAD_RIGHT = xis.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT;
	dwSTART = xis.Gamepad.wButtons & XINPUT_GAMEPAD_START;
	dwBACK = xis.Gamepad.wButtons & XINPUT_GAMEPAD_BACK;

	if (dwBACK){
		game_state = GS_QUIT; // quit when pressed back
	}
	
	if (dwSTART){
	}

	if (dwDPAD_LEFT){
		player.x-=3.0f;
		if (player.x < player.sizex){
			player.x = player.sizex;
		}
	}

	if (dwDPAD_RIGHT){
		player.x+=3.0f;
		if (player.x > SCREEN_SIZE_X-player.sizex){
			player.x = SCREEN_SIZE_X-player.sizex;
		}
	}

	if (xis.Gamepad.bAnalogButtons[0]){
		if (game_state == GS_INGAME){
			player_fire();
		}
	}
}

// use from main menu
bool ReadGamepad3( void )
{
	// DPAD_LEFT move left		#define XINPUT_GAMEPAD_DPAD_LEFT        0x00000004
	// DPAD_RIGHT move right	#define XINPUT_GAMEPAD_DPAD_RIGHT       0x00000008
	// BUTTON_A fire			#define XINPUT_GAMEPAD_A                0
	// START restart level
    
    HANDLE hPad;
	XINPUT_STATE xis;

	DWORD dwSTART;
	DWORD dwBACK;
	
	if( !(hPad = GetFirstController()) ){
		return false;
	}

	// Get latest state
	XInputGetState(hPad, &xis);

	dwSTART = xis.Gamepad.wButtons & XINPUT_GAMEPAD_START;
	dwBACK = xis.Gamepad.wButtons & XINPUT_GAMEPAD_BACK;
	
	if (dwSTART){
		return true;
	}

	if (dwBACK){
		game_state = GS_QUIT; // quit when pressed back
	}
	return false;

}

// The index of the gamepad info in the device states array.
#define DS_GAMEPAD  0

//
// Find the first connected controller.
// This could be cached and then checked only when a device change
// is detected.
//
HANDLE GetFirstController( void )
{
    HANDLE hPad = 0;
    int i;
    

    // Check the global gamepad state for a connected device.
    for( i = 0; i < NUM_PORTS; i++ )
    {
        if( g_dsDevices[DS_GAMEPAD].dwState & 1 << i && g_hPads[i] ) {
            hPad = g_hPads[i];
            break;
        }
    }

    return hPad;
}

void get_input(void)
{
	CheckDeviceChanges(g_dsDevices);
	ReadGamepad2();
}

bool get_menu_input(void)
{
	CheckDeviceChanges(g_dsDevices);
	return ReadGamepad3();
}
