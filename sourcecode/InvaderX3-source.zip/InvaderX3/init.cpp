// HEADER FILES
#include <xtl.h>
#include <time.h>

// OS SPECIFIC FUNCTIONS
HRESULT init_d3d(void); 
void kill_d3d(void);
void render(void);

// GAME SPECIFIC FUNCTIONS
void seed_random(void);
void render(void);
void init_enemies(void);
void update_enemies(void);
void init_player(void);
void check_enemy_fire(int id);
void update_enemy_bullets(int id);
void init_bullets(void);
void update_player(void);
void init_player_bullet(void);
void player_fire(void);
void update_player_bullet(void);
int  random_range_int(int min, int max);
float GetDistanceFast2D(float x1, float y1, float x2, float y2);
void kill_enemy(int j);
void frame_blit(int frame, int x, int y, float var[8]);
void add_explosion(float x, float y, float sx, float sy);
void init_explosions(void);
void update_explosions(void);
void kill_player(void);
void render_quad_alpha(int x, int y, float z, int sizex, int sizey, LPDIRECT3DTEXTURE8 tex);
void restart_game(void);
void load_textures(void);
void init_powerups(void);
void create_powerup(int type, float x, float y);
void update_powerups(void);
void update_mothership(void);
void new_mothership(void);
void check_mothership(void);
void init_mothership(void);
void load_textures(void);
void free_textures(void);
void display_scores(void);

// GAME SPECIFIC GLOBALS
float	SCREEN_SIZE_X = 640;
float	SCREEN_SIZE_Y = 480;
int		round = 0;			// game round
float	xspeed = 1.0f;		// x scroll speed of enemies
float	enemy_count = 15*6;
float	total_enemies = 0;
int		enemy_alive = 0;	// running count on alive enemies
bool	done_mothership = false;
int		game_state = 0;
int		bullets_fired = 0;
DWORD	level_time = 0;
DWORD	gameover_time = 0;

LPDIRECT3D8 g_pD3D=NULL;
IDirect3DDevice8 *g_pd3dDevice=NULL;


// GLOBALS TEXTURE
LPDIRECT3DTEXTURE8	g_pBackTexture	 = NULL;	// Background Texture
LPDIRECT3DTEXTURE8	g_pEnemy1Texture = NULL;	// Enemy Type1 Texture
LPDIRECT3DTEXTURE8	g_pEnemy2Texture = NULL;	// Enemy Type2 Texture
LPDIRECT3DTEXTURE8	g_pPlayerTexture = NULL;	// Players Texture
LPDIRECT3DTEXTURE8	g_pBulletTexture = NULL;	// Bullet Texture
LPDIRECT3DTEXTURE8	g_pExplosionTexture = NULL;	// Explosion Texture
LPDIRECT3DTEXTURE8	g_pLoadingTexture = NULL;				// Loading Screen
LPDIRECT3DTEXTURE8	g_pGetReadyTexture = NULL;				// Get Ready Texture
LPDIRECT3DTEXTURE8	g_pGameOverTexture = NULL;				// Get Ready Texture
LPDIRECT3DTEXTURE8	g_pPowerUpSuperShotTexture = NULL;		// SuperShot Texture
LPDIRECT3DTEXTURE8	g_pPowerUpBulletSpeedTexture = NULL;	// DoubleShot Texture
LPDIRECT3DTEXTURE8	g_pMothershipTexture = NULL;			// MotherShip Texture
LPDIRECT3DTEXTURE8	g_pPlayerShieldTexture = NULL;			// PlayerShield Texture
LPDIRECT3DTEXTURE8	g_pMainMenuTexture = NULL;				// Main Menu texture

struct TRANSFORMED_VERTEX
{
    float	x,y,z, rhw; // The transfrmed screen position
    float	tu, tv;		// The texture coordinates
};
#define D3DFVF_CUSTOM_TRANSFORMED_VERTEX (D3DFVF_XYZRHW|D3DFVF_TEX1)

struct TRANSFORMED_VERTEX_ALPHA
{
    float		x,y,z, rhw; // The transfrmed screen position
	DWORD		color;		// vertex color
    float		tu, tv;		// The texture coordinates
};
#define D3DFVF_CUSTOM_TRANSFORMED_VERTEX_ALPHA (D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1)


TRANSFORMED_VERTEX back_verts[] ={
	{ 0.0f,				SCREEN_SIZE_Y,	1.0f,	1.0f,	0.0f,	1.0f },
	{ 0.0f,				0.0f,			1.0f,	1.0f,	0.0f,	0.0f },
	{ SCREEN_SIZE_X,	SCREEN_SIZE_Y,	1.0f,	1.0f,	1.0f,	1.0f },
	{ SCREEN_SIZE_X,	0.0f,			1.0f,	1.0f,	1.0f,	0.0f }
};

TRANSFORMED_VERTEX_ALPHA haze_verts[] ={
	{ 0.0f,				SCREEN_SIZE_Y,	1.0f,	1.0f,	0x7FFFFFFF,	0.0f,	1.0f },
	{ 0.0f,				0.0f,			1.0f,	1.0f,	0x7FFFFFFF,	0.0f,	0.0f },
	{ SCREEN_SIZE_X,	SCREEN_SIZE_Y,	1.0f,	1.0f,	0x7FFFFFFF,	1.0f,	1.0f },
	{ SCREEN_SIZE_X,	0.0f,			1.0f,	1.0f,	0x7FFFFFFF, 1.0f,	0.0f }
};


typedef struct{
	int id;
	int type;
	bool alive;
	bool hit;
	float x,y;
	bool bullet;
	float bulletx;
	float bullety;
	DWORD bullettime;
	DWORD lastfired;
	float sizex;
	float sizey;
	float bsizex;
	float bsizey;
	TRANSFORMED_VERTEX verts[4];
	TRANSFORMED_VERTEX bverts[4];
}enemy_t;
enemy_t enemy[6*15];

typedef struct{
	char name[64];
	bool alive;
	int lives;
	float x,y;
	bool bullet;
	float bulletx;
	float bullety;
	float sizex;
	float sizey;
	float bsizex;
	float bsizey;
	float bspeed;
	int powerup;
	DWORD poweruptime;
	TRANSFORMED_VERTEX verts[4];
	TRANSFORMED_VERTEX bverts[4];
	int score;
	int bonus;
}player_t;
player_t  player;

typedef struct{
	float x,y;							// pos
	float sx,sy;							// size
	int frame;							// current frame;
	bool alive;							// active explosion?
	DWORD lastframe;					// when last frame done
	TRANSFORMED_VERTEX_ALPHA verts[4];	// vert data
}explosion_t;
explosion_t explosion[50];


#define MAX_POWERUPS 10
typedef struct{
	float x,y;
	float speed;
	float sx,sy;
	int frame;
	bool alive;
	int type;
	DWORD lastframe;
	TRANSFORMED_VERTEX_ALPHA verts[4];	// vert data
}powerup_t;
powerup_t powerup[MAX_POWERUPS];

typedef struct{
	float x,y;
	float speed;
	float sx,sy;
	bool alive;
	TRANSFORMED_VERTEX_ALPHA verts[4];	// vert data
}mothership_t;
mothership_t mothership;


enum GAME_STATE{

	GS_INIT = 0,
	GS_LOADING,
	GS_INTRO,
	GS_MAINMENU,
	GS_GETREADY, // shown after completion of level
	GS_LEVELCOMPLETE,
	GS_INGAME,
	GS_STAGEBEGIN,
	GS_GAMEOVER,
	GS_HIGHSCORE,
	GS_QUIT,
	GS_PAUSED,
};

enum POWERUPS{
	
	PU_START = 0,
	PU_SUPERSHOT,
	PU_BULLETSPEED,
	PU_SHIELD,
	PU_END,
};

#define SafeRelease(pObject) if(pObject != NULL) {pObject->Release(); pObject=NULL;}


#include "input.cpp"
#include "texture.cpp"
#include "render.cpp"
#include "sound_mix.cpp"
#include "wmastream.cpp"
#include "text.cpp"

//----------------------------------------------------------------------------- 
// MAIN 
//----------------------------------------------------------------------------- 
void __cdecl main() 
{ 
	int count = 0;

	game_state = GS_INIT;
	init_d3d();
	load_textures();

	game_state = GS_LOADING;
	render();
	InitSound();

	// want ppl to see the intro screen. XBOX loads lightning fast
	Sleep(2500);

	// initialise sub routines
	seed_random();
	init_enemies();
	init_bullets();
	init_player();
	init_player_bullet();
	init_explosions();
	init_powerups();
	init_mothership();	
	InitialiseFonts();
	device_init();
	
	// show intro
	game_state = GS_INTRO;
	// show main menu
	game_state = GS_MAINMENU;
	render();

	// start game
//	game_state = GS_GETREADY;
//	PlaySound(sample_get_ready);

	render();

	level_time = GetTickCount();

	while(game_state != GS_QUIT){
		
		if (game_state == GS_MAINMENU){
			render();
			bool result = get_menu_input();
			if (result == true){
				// player pressed start
				restart_game();
			}
		}

		if (game_state == GS_GAMEOVER){
			display_scores();
			update_player();
			update_enemies();
			update_explosions();
			update_powerups();
			update_mothership();
			render();
			if (GetTickCount() - gameover_time >= 4000){
				game_state = GS_MAINMENU;	//restart_game();
			}
		}
		
		if (game_state == GS_LEVELCOMPLETE){
			
			get_input();

			display_scores();
			update_player();
			update_enemies();
			update_explosions();
			update_powerups();
			update_mothership();
			render();
			level_time = GetTickCount();
			game_state = GS_GETREADY;
		}
		
		if (game_state == GS_GETREADY){
			
			// only show accuracy bonus once a round is complete
			// little bit hacky but does the job
			if (round > 1){
				TextOut(260, 300, L"Accuracy Bonus:");
				TextOut(390, 300, player.bonus);
			}
			static int play = 0;
			
			get_input();
			
			display_scores();
			update_player();
			update_enemies();
			update_explosions();
			update_powerups();
			update_mothership();
			render();
			
			if (play == 0){
				PlaySound(sample_get_ready);
				play = 1;
			}

			if (GetTickCount() - level_time >= 4000){
				play = 0;
				player.bonus = 0;
				game_state = GS_INGAME;

			}
		}

		if (game_state == GS_INGAME){

			get_input();

			display_scores();
			update_player();
			update_enemies();
			update_explosions();
			update_powerups();
			update_mothership();
			render();
		}
	}


	// cleanup and shutdown
	free_textures();
	DestroyFonts();
    
	SafeRelease(g_pd3dDevice);
    SafeRelease(g_pD3D);

} 

float GetDistanceFast2D(float x1, float y1, float x2, float y2)
{
	return ( fabs(x1-x2) + fabs(y1-y2) );
}

void frame_blit(int frame, int x, int y, float var[8])
{
	static int resulty;
	static int resultx;
	static float ex;
	static float ey;
	
	resulty = frame/x;
	resultx = fmodf(frame,x);
	ex = ((float)1/(float)x);
	ey = ((float)1/(float)y);
	
	var[0] = resultx * ex;
	var[1] = resulty * ey;

	var[4] = var[0] + ex;
	var[5] = var[1] + ey;

	var[2] = var[4];
	var[3] = var[1];

	var[6] = var[0];
	var[7] = var[5];
}

void seed_random(void)
{
	srand( (unsigned)time( NULL ) );
}

int random_range_int(int min, int max)
{
	static int range;
	static int num;
	range = max - min;
	num = rand() % range;
	return (num + min);
}

//----------------------------------------------------------------------------- 
// Name: InitD3D() 
// Desc: Initializes Direct3D 
//----------------------------------------------------------------------------- 
HRESULT init_d3d()
{
    // Create the D3D object.
    if( NULL == ( g_pD3D = Direct3DCreate8( D3D_SDK_VERSION ) ) )
        return E_FAIL;

    // Set up the structure used to create the D3DDevice.
    D3DPRESENT_PARAMETERS d3dpp; 
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.BackBufferWidth        = (unsigned int)SCREEN_SIZE_X;
    d3dpp.BackBufferHeight       = (unsigned int)SCREEN_SIZE_Y;
    d3dpp.BackBufferFormat       = D3DFMT_X8R8G8B8;
    d3dpp.BackBufferCount        = 1;	//2;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_F24S8 ; // *NEW* D3DFMT_D16; //D3DFMT_D24S8;
    d3dpp.SwapEffect             = D3DSWAPEFFECT_DISCARD;
	d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;

    
	// Create the Direct3D device.
    if( FAILED( g_pD3D->CreateDevice( 0, D3DDEVTYPE_HAL, NULL,
                                      D3DCREATE_HARDWARE_VERTEXPROCESSING,
                                      &d3dpp, &g_pd3dDevice ) ) )
        return E_FAIL;

	// Turn off culling
    g_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

    // Turn off D3D lighting
    g_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );

    // Turn on the zbuffer
    g_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );

	return S_OK;

} 

//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// void render(void)
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// USAGE:	Renders Scene
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
void render(void)
{ 
	unsigned char red	= 0;
	unsigned char green	= 0;
	unsigned char blue	= 0; 

	g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(red,green,blue), 1.0f, 0 );
	
	if(SUCCEEDED(g_pd3dDevice->BeginScene())){ 
		
		g_pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, true);
		g_pd3dDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
		g_pd3dDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
		// seems most icons will be alpha blended leave this state enabled
		// all the time. 
		g_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
		g_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_TFACTOR );
		g_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
		
		// and adjust here
		g_pd3dDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_ARGB(255, 255,255,255) );
	
		if (game_state == GS_LOADING){
			render_loading();
		}

		if (game_state == GS_INTRO){
		}

		if (game_state == GS_MAINMENU){
			render_mainmenu();
		}

		if (game_state == GS_INGAME){
			render_ingame();
		}

		if (game_state == GS_GETREADY){
			render_getready();
		}

		if (game_state == GS_GAMEOVER){
			render_gameover();
		}

		if (game_state == GS_HIGHSCORE){
		}
		
		if (game_state == GS_QUIT){
		}

		if (game_state == GS_PAUSED){
		}

		
		g_pd3dDevice->EndScene();
	
	} 

	g_pd3dDevice->Present( NULL, NULL, NULL, NULL ); 

}


//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// void init_player(void)
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// USAGE:	Initialises player for a new game
//			Creates vertex structures from player x/y
//			Sets up Players Texture uv's
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
void init_player(void)
{
	
	player.sizex = 25;
	player.sizey = 20;

	player.lives = 3;
	player.bonus = 0;
	
	player.powerup = PU_START;

	player.x = (float)SCREEN_SIZE_X/2.0f;
	player.y = (float)SCREEN_SIZE_Y-player.sizey;

	player.verts[0].x = (float)player.x - player.sizex;
	player.verts[1].x = (float)player.x - player.sizex;
	player.verts[2].x = (float)player.x + player.sizex; // sizex
	player.verts[3].x = (float)player.x + player.sizex; // sizex

	player.verts[0].y = (float)player.y + player.sizey; // sizey
	player.verts[1].y = (float)player.y - player.sizey;
	player.verts[2].y = (float)player.y + player.sizey; // sizey
	player.verts[3].y = (float)player.y - player.sizey;

	player.verts[0].z = 0.5f;
	player.verts[1].z = 0.5f;
	player.verts[2].z = 0.5f;
	player.verts[3].z = 0.5f;

	player.verts[0].rhw = 1.0f;
	player.verts[1].rhw = 1.0f;
	player.verts[2].rhw = 1.0f;
	player.verts[3].rhw = 1.0f;

	player.verts[0].tu = 0.0f;
	player.verts[1].tu = 0.0f;
	player.verts[2].tu = 1.0f;
	player.verts[3].tu = 1.0f;
	
	player.verts[0].tv = 1.0f;
	player.verts[1].tv = 0.0f;
	player.verts[2].tv = 1.0f;
	player.verts[3].tv = 0.0f;

	player.bullet = false;
	
	player.bspeed = 8.0f;
	
	player.score = 0;
}
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// init_enemies(void)
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// USAGE:	Initialised enemies for use ingame
//			Creates vertex structures from enemy.x/y
//			Initialises enemy[n].bullet as false
//			Sets up Texture uv's
// GLOBALS:	
//			int round; used for detecting start row for enemies
//			the higher the round the lower the invaders start
//			local vars round_to_drop and max_round_drop effect
//			this behaviour
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
void init_enemies(void)
{
	float x,y = 0;
	float xoffset = 38;		// distance from one enemy to next in row
	float yoffset = 33;		// distance from one enemy to next in row
	float startx = 20;		// screen offset for enemies
	float starty = 60;		// screen offset for enemies
	float roundoffset = 10;	// enemies rows y start at 0 + (round * roundoffset)
	int	round_to_drop = 6;	// enemies dont spawn lower until this round
	int	max_drop_rounds =10;// dont drop on spawn after this round
	
	for (int k=0; k<6*15;k++){
		enemy[k].alive = false;
		enemy[k].bullet = false;
	}

	// re-seed random num gen
	seed_random();
	
	// set starting speed
	xspeed	 = 1.0f;
	// increase round count
	round++;
	total_enemies = 0;
	bullets_fired = 0;
	done_mothership = false;

	//ensure max of 6 rows of enemies
	int rows = round+1;
	if (rows >= 6){
		rows = 6;
	}
	
	for (y=0; y<rows; y++){
		for (x=0; x<15; x++){
			
			int id = (int)x+((int)y*15);
			enemy_t *en = &enemy[id];

			
			// add to active enemy count
			enemy_alive++;
			total_enemies++;
			
			en->sizex = 16;
			en->sizey = 16;

			if (y == 0){
				en->type = 1;
			}else{
				en->type = 2;
			}
			

			en->hit = false;

			en->x = startx+ (x*xoffset);
			
			// decide y start pos (spawn drop)
			
			if (round < round_to_drop){
				en->y = starty + (y*yoffset);
			}else{
				if (round >= max_drop_rounds){
					en->y = starty + (y*yoffset)+(max_drop_rounds*roundoffset);
				}else{
					en->y = starty + (y*yoffset)+(round*roundoffset);
				}
			}
			
			en->alive = true;
			en->bullet = false;
			en->bullettime = GetTickCount();
			
			en->verts[0].x = en->x - en->sizex;
			en->verts[1].x = en->x - en->sizex;
			en->verts[2].x = en->x + en->sizex; // sizex
			en->verts[3].x = en->x + en->sizex; // sizex

			en->verts[0].y = en->y + en->sizey; // sizey
			en->verts[1].y = en->y - en->sizey;
			en->verts[2].y = en->y + en->sizey; // sizey
			en->verts[3].y = en->y - en->sizey;
		
			en->verts[0].z = 0.6f;
			en->verts[1].z = 0.6f;
			en->verts[2].z = 0.6f;
			en->verts[3].z = 0.6f;

			en->verts[0].rhw = 1.0f;
			en->verts[1].rhw = 1.0f;
			en->verts[2].rhw = 1.0f;
			en->verts[3].rhw = 1.0f;

			en->verts[0].tu = 0.0f;
			en->verts[1].tu = 0.0f;
			en->verts[2].tu = 1.0f;
			en->verts[3].tu = 1.0f;
			
			en->verts[0].tv = 1.0f;
			en->verts[1].tv = 0.0f;
			en->verts[2].tv = 1.0f;
			en->verts[3].tv = 0.0f;

		}
	}

}
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// update_enemies(void)
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// USAGE:	Will move enemies left to right and then back again
//			Drops all enemies lower on screen.. invasion tactic
//			updates enemy bullets
//			checks for enemy collision against player bullet
//			checks and fires enemy bullet
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// FUNCTIONS REQUIRED: GetDistanceFast2D(), kill_enemy(j)
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
void update_enemies(void)
{
	static int i,j,miny = 0;
	static float dist = 0.0f;


	
	static int drop = 0;
	static int direction = 0;   // 0 = going right , 1 = going left
	static int drop_lines = 5;	// y Drop distance

	if (direction == 0){ // enemies moving towards right of screen

		for (j=0;j<enemy_count;j++){
			
			enemy_t *en = &enemy[j];
			
			if (en->bullet == true){
				update_enemy_bullets(j); // enemy might have bullets on screen even if enemy is dead
			}

			if (en->alive == true){
				// check player bullet against enemy
				if (player.bullet == true){
					dist = GetDistanceFast2D((float)player.bulletx, (float)player.bullety, (float)en->x, (float)en->y);
					if (dist <= en->sizex){
						kill_enemy(j);
					}
				}
				//update ref position
				en->x = en->x + xspeed;

				// update bullet status and check for random fire
				if (en->bullet == false){
					check_enemy_fire(j);
				}

				if (en->x >= SCREEN_SIZE_X - en->sizex){
//					en->x = 639.0f - en->sizex;
					direction = 1; // send enemies back towards left of screen

					if (game_state == GS_INGAME){
						drop = 1;
					}

				}

				// update verts
				en->verts[0].x = (float)en->x - en->sizex;
				en->verts[1].x = (float)en->x - en->sizex;
				en->verts[2].x = (float)en->x + en->sizex; // enemy sizex
				en->verts[3].x = (float)en->x + en->sizex; // enemy sizex
			}
		}
	}

	if (direction == 1){ // enemies moving towards right of screen

		for (j=0;j<enemy_count;j++){

			enemy_t *en = &enemy[j];
			
			if (en->bullet == true){
				update_enemy_bullets(j); // enemy might have bullets on screen even if enemy is dead
			}
			if (en->alive == true){

				if (player.bullet == true){
					dist = GetDistanceFast2D(player.bulletx, player.bullety, en->x, en->y);
					if (dist <= en->sizex){
						kill_enemy(j);
					}
				}

				//update ref position
				en->x = en->x - xspeed;

				// update bullet status and check for random fire
				if (en->bullet == false){
					check_enemy_fire(j);
				}					
					
					if (en->x <= 0.0f + (float)en->sizex){
//						en->x = 0.0f + (float)en->sizex;
						direction = 0; // send enemies back towards left of screen
						
						if (game_state == GS_INGAME){
							drop = 1;
						}
					}

				// update verts
				en->verts[0].x = (float)en->x - en->sizex;
				en->verts[1].x = (float)en->x - en->sizex;
				en->verts[2].x = (float)en->x + en->sizex; // enemy sizex
				en->verts[3].x = (float)en->x + en->sizex; // enemy sizex
			}
		}
	}

	if (game_state == GS_INGAME){
		if (drop == 1){		// drop all enemies down a line
			drop = 0;
			for (i=0;i<enemy_count; i++){
				if (enemy[i].alive == true){
					
					enemy_t *en = &enemy[i];

					en->y = en->y + drop_lines;
					en->verts[0].y = (float)en->y + en->sizey; // enemy sizey
					en->verts[1].y = (float)en->y - en->sizey;
					en->verts[2].y = (float)en->y + en->sizey; // enemy sizey
					en->verts[3].y = (float)en->y - en->sizey;
					
					miny = SCREEN_SIZE_Y - (player.sizex);
					// check if planet invaded
					if (en->y > miny){
						gameover_time = GetTickCount();
						game_state = GS_GAMEOVER;
					}


				}
			}
		}
	}


}
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// void check_enemy_fire(int id)
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// USAGE:	should only be called if the enemy[id].bullet is active(bTrue)
//			This function is a bit hacky, basically it will fail after the 150th round
//			I doubt anyone will get this far. however never assume anything about a players
//			action. Who knows what they will do?!
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
void check_enemy_fire(int id)
{
	static int random = 0;

	if (game_state == GS_INGAME){
		random = random_range_int(1,150);
		int difficulty = round;
		if (difficulty > 30){
			difficulty = 30;
		}
		
		enemy_t *en = &enemy[id];
		
		
		if (GetTickCount() - en->lastfired >= 1000.0f){	// fixme

			en->lastfired = GetTickCount();
		
			if (random < difficulty){
				
				PlaySound(sample_enemy_shoot);
				
				en->bullet = true;
				
				en->bulletx = en->x;
				en->bullety = en->y;

				en->bverts[0].x = (float)en->bulletx - en->bsizex;
				en->bverts[1].x = (float)en->bulletx - en->bsizex;
				en->bverts[2].x = (float)en->bulletx + en->bsizex; // sizex
				en->bverts[3].x = (float)en->bulletx + en->bsizex; // sizex

				en->bverts[0].y = (float)en->bullety + en->bsizey; // sizey
				en->bverts[1].y = (float)en->bullety - en->bsizey;
				en->bverts[2].y = (float)en->bullety + en->bsizey; // sizey
				en->bverts[3].y = (float)en->bullety - en->bsizey;
			}
		}
	}
}
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// void update_enemy_bullets(int id)
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// USAGE:	should only be called if the enemy bullet is active
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
void update_enemy_bullets(int id)
{
	static float dist = 0.0f;
	
	enemy_t *en = &enemy[id];
	
	int speed = 20; // millisecs between bullet updates (fixme)
	if (GetTickCount() - en->bullettime >= speed){
		en->bullety+=2;
		en->bverts[0].y = (float)en->bullety + en->bsizey; // sizey
		en->bverts[1].y = (float)en->bullety - en->bsizey;
		en->bverts[2].y = (float)en->bullety + en->bsizey; // sizey
		en->bverts[3].y = (float)en->bullety - en->bsizey;
	}

	// check that bullet is in game area
	if (en->bullety > SCREEN_SIZE_Y){
		en->bullet = false;
	}

	// check if bullet hits player
	if (game_state == GS_INGAME){
		dist = GetDistanceFast2D(player.x, player.y, en->bulletx, en->bullety);
		
		
		if (player.powerup != PU_SHIELD){
			
			if (dist <= player.sizex){
				kill_player();
				en->bullet = false;
			}
		}



	}

}
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// void init_bullets(void)
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// USAGE: initialises all enemies bullets use at start of game only
//		  this func should not be called at the start of a round
//		  init_enemies() will set up bullets for new round status
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
void init_bullets(void)
{
	static int id = 0;
	
	// set up uv coords for bullets
	for (id=0; id<enemy_count; id++){
		
		enemy_t *en = &enemy[id];
		
		en->bsizex = 8;
		en->bsizey = 8;
		
		en->bverts[0].tu = 0.0f;
		en->bverts[1].tu = 0.0f;
		en->bverts[2].tu = 1.0f;
		en->bverts[3].tu = 1.0f;
			
		en->bverts[0].tv = 0.0f;
		en->bverts[1].tv = 1.0f;
		en->bverts[2].tv = 0.0f;
		en->bverts[3].tv = 1.0f;

		en->bverts[0].z = 0.9f;
		en->bverts[1].z = 0.9f;
		en->bverts[2].z = 0.9f;
		en->bverts[3].z = 0.9f;

		en->lastfired = GetTickCount();
		en->bullet = false;
	}
}
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// void update_player(void)
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
// USAGE:	Updates the players verts based on players position
//=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-
void update_player(void)
{
	// update verts
	player.verts[0].x = (float)player.x - player.sizex;
	player.verts[1].x = (float)player.x - player.sizex;
	player.verts[2].x = (float)player.x + player.sizex; // sizex
	player.verts[3].x = (float)player.x + player.sizex; // sizex

	player.verts[0].y = (float)player.y + player.sizey; // sizey
	player.verts[1].y = (float)player.y - player.sizey;
	player.verts[2].y = (float)player.y + player.sizey; // sizey
	player.verts[3].y = (float)player.y - player.sizey;

	if (player.bullet == true){
		update_player_bullet();
	}

	//check for life up
	static long lifeupat[] = {1500, 5000, 10000, 15000, 20000, 30000, 40000, 55000, 70000};
	static int lifeup = 0;

	// does player get an extra life
	if (lifeup < 8){
		if (player.score >= lifeupat[lifeup]){
			PlaySound(sample_playerup);
			player.lives++;
			lifeup++;
		}
	}

	// does player get an extra life
	if (lifeup == 8){
		if (player.score >= lifeupat[8]){
			PlaySound(sample_playerup);
			player.lives++;
			lifeupat[8]+=20000;
		}
	}
	
	// shield powerup expires after 10 seconds
	if (player.powerup == PU_SHIELD){
		if (GetTickCount() - player.poweruptime >= 10000){
			player.powerup = PU_START;
		}
	}

	// if powerup is bulletspeed then upgrade speed
	// if not then bullet speed is normal
	if (player.powerup == PU_BULLETSPEED){
		player.bspeed = 15.0f;
	}else{
		player.bspeed = 9.0f;
	}

}
void init_player_bullet(void)
{
	player.bverts[0].tu = 0.0f;
	player.bverts[1].tu = 0.0f;
	player.bverts[2].tu = 1.0f;
	player.bverts[3].tu = 1.0f;
			
	player.bverts[0].tv = 1.0f;
	player.bverts[1].tv = 0.0f;
	player.bverts[2].tv = 1.0f;
	player.bverts[3].tv = 0.0f;

	player.bverts[0].z = 0.8f;
	player.bverts[1].z = 0.8f;
	player.bverts[2].z = 0.8f;
	player.bverts[3].z = 0.8f;

	player.bsizex = 6;
	player.bsizey = 6;
	
	player.bullet = false;


}
void player_fire(void)
{
	if (player.bullet == false){	// can only fire if no active bullets
		PlaySound(sample_player_shoot);
		player.bullet = true;
		player.bulletx = player.x;
		player.bullety = player.y;
		bullets_fired++;
	}
}
void update_player_bullet(void)
{
	player.bullety = player.bullety-player.bspeed;		// FIXME   (dont hardcode speeds)
	
	if (player.bullety <= 0){
		player.bullet = false;
		return;
	}

	player.bverts[0].x = player.bulletx - player.bsizex;
	player.bverts[1].x = player.bulletx - player.bsizex;
	player.bverts[2].x = player.bulletx + player.bsizex; // sizex
	player.bverts[3].x = player.bulletx + player.bsizex; // sizex

	player.bverts[0].y = player.bullety + player.bsizey; // sizey
	player.bverts[1].y = player.bullety - player.bsizey;
	player.bverts[2].y = player.bullety + player.bsizey; // sizey
	player.bverts[3].y = player.bullety - player.bsizey;
}

void kill_enemy(int j)
{
	static int random = 0;
	
	if (game_state == GS_INGAME){

		PlaySound(sample_enemy_die);

		enemy[j].alive = false;

		
		// if players powerup is SUPERSHOT
		// then bullet does not destruct when hits an enemy
		// bullet does distruct otherwise
		if (player.powerup != PU_SUPERSHOT){
			player.bullet = false;
		}

		if (enemy[j].type == 1){
			player.score+=25;
		}

		if (enemy[j].type == 2){
			player.score+=10;
		}

		add_explosion(enemy[j].x, enemy[j].y, enemy[j].sizex, enemy[j].sizey);
		xspeed = xspeed + 0.03f; // speed enemies up each time one is killedq


		// detect if this enemy will release a powerup
		random = random_range_int(1,50);
		if (random == 1){
			create_powerup(PU_SUPERSHOT, enemy[j].x, enemy[j].y);
		}
		if (random == 2){
			create_powerup(PU_BULLETSPEED, enemy[j].x, enemy[j].y);
		}
		if (random == 3){
			create_powerup(PU_SHIELD, enemy[j].x, enemy[j].y);
		}
		
		
		// check if its time to add a mothership to this stage
		check_mothership();
		
		enemy_alive--;
		if (enemy_alive == 0){
			game_state = GS_LEVELCOMPLETE;
			
			player.bonus = ( (float)total_enemies / (float)bullets_fired ) * 1000.0f;
			player.score = player.score + player.bonus;

			init_enemies();
		}
	}
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// void init_explosions(void)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
void init_explosions(void)
{
	static int j = 0;
	for (j=0; j<50; j++){
		explosion[j].alive = false;
		explosion[j].lastframe = GetTickCount();
	}
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// void add_explosion(float x, float y, float sx, float sy)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// INPUT :	x - xposition of explosion
//			y - yposition of explosion
//			sx - x size of explosion
//			sy - y size of explosion
//
// USAGE:
//			Creates bitmapped explosion at given location
//			add_explosion() randomly offsets the size by a small
//			amount to give a variable apperance
//
// FUNCTIONS REQUIRED: frame_blit()
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void add_explosion(float x, float y, float sx, float sy)
{
	static float zpos = 0.4f;
	static float uv[8];
	static int j = 0;
	static float xoffset, yoffset = 0;
	
	// find a free explosion slot
	for (j=0; j<50; j++){

		if (explosion[j].alive == false){ // use this explosion slot
		
			explosion_t *exp = &explosion[j];
		
			exp->x = x;
			exp->y = y;
			
			xoffset = (float)random_range_int(1,100)/100.0f;
			yoffset = (float)random_range_int(1,100)/100.0f;

			exp->sx = sx + sx + sx*xoffset;
			exp->sy = sy + sy + sy*yoffset;

			exp->frame = 0;
			exp->alive = true;
			exp->lastframe = GetTickCount();

			exp->verts[0].x = x - exp->sx;
			exp->verts[1].x = x - exp->sx;
			exp->verts[2].x = x + exp->sx;
			exp->verts[3].x = x + exp->sx;
			exp->verts[0].y = y + exp->sy;
			exp->verts[1].y = y - exp->sy;
			exp->verts[2].y = y + exp->sy;
			exp->verts[3].y = y - exp->sy;

			frame_blit(exp->frame, 4, 4, uv);

			exp->verts[0].tu = uv[2];
			exp->verts[1].tu = uv[0];
			exp->verts[2].tu = uv[4];
			exp->verts[3].tu = uv[6];
			exp->verts[0].tv = uv[3];
			exp->verts[1].tv = uv[1];
			exp->verts[2].tv = uv[5];
			exp->verts[3].tv = uv[7];

			exp->verts[0].color = D3DCOLOR_ARGB(255, 255,255,255);
			exp->verts[1].color = D3DCOLOR_ARGB(255, 255,255,255);
			exp->verts[2].color = D3DCOLOR_ARGB(255, 255,255,255);
			exp->verts[3].color = D3DCOLOR_ARGB(255, 255,255,255);
			
			exp->verts[0].z = zpos;
			exp->verts[1].z = zpos;
			exp->verts[2].z = zpos;
			exp->verts[3].z = zpos;

			break; // only create 1 explosion
		}
	}
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// void update_explosions(void)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// USAGE:
//			Cycles through all explosions until finds an active
//			one, then updates the explosions current frame
//
// FUNCTIONS REQUIRED: frame_blit()
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
void update_explosions(void)
{
	static float uv[8];

	for (int j=0;j<50;j++){
		
		if (explosion[j].alive == true){

			if (GetTickCount() - explosion[j].lastframe >= 40){

				explosion[j].frame++;
				explosion[j].lastframe = GetTickCount();

				frame_blit(explosion[j].frame, 4, 4, uv);

				explosion[j].verts[0].tu = uv[2];
				explosion[j].verts[1].tu = uv[0];
				explosion[j].verts[2].tu = uv[4];
				explosion[j].verts[3].tu = uv[6];
				explosion[j].verts[0].tv = uv[3];
				explosion[j].verts[1].tv = uv[1];
				explosion[j].verts[2].tv = uv[5];
				explosion[j].verts[3].tv = uv[7];
				
				if (explosion[j].frame >= 15){
					explosion[j].alive = false;
				}

			}
		}
	}
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// void kill_player(void)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// USAGE:
//			Creates a full screen explosion, same as
//			update_explosions()
//			Takes a life from player and checks if player
//			is out of lives
//
// FUNCTIONS REQUIRED: frame_blit()
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
void kill_player(void)
{
	static float uv[8];

	// find a free explosion slot
	for (int j=0; j<50; j++){
		if (explosion[j].alive == false){ // sweet

			PlaySound(sample_player_die);
			
			explosion_t *exp = &explosion[j];

			exp->frame = 0;
			exp->alive = true;
			exp->lastframe = GetTickCount();

			exp->verts[0].x = 0-SCREEN_SIZE_X*0.25f;				//(float)x - exp->sx;
			exp->verts[1].x = 0-SCREEN_SIZE_X*0.25f;				//(float)x - exp->sx;
			exp->verts[2].x = SCREEN_SIZE_X + SCREEN_SIZE_X*0.25f;				//(float)x + exp->sx;
			exp->verts[3].x = SCREEN_SIZE_X + SCREEN_SIZE_X*0.25f;				//(float)x + exp->sx;
			exp->verts[0].y = SCREEN_SIZE_Y + SCREEN_SIZE_Y*0.25f;				//(float)y + exp->sy;
			exp->verts[1].y = 0-SCREEN_SIZE_Y*0.25f;				//(float)y - exp->sy;
			exp->verts[2].y = SCREEN_SIZE_Y + SCREEN_SIZE_Y*0.25f;				//(float)y + exp->sy;
			exp->verts[3].y = 0-SCREEN_SIZE_Y*0.25f;				//(float)y - exp->sy;

			frame_blit(exp->frame, 4, 4, uv);

			exp->verts[0].tu = uv[2];
			exp->verts[1].tu = uv[0];
			exp->verts[2].tu = uv[4];
			exp->verts[3].tu = uv[6];
			exp->verts[0].tv = uv[3];
			exp->verts[1].tv = uv[1];
			exp->verts[2].tv = uv[5];
			exp->verts[3].tv = uv[7];

			exp->verts[0].color = D3DCOLOR_ARGB(255, 255,255,255);
			exp->verts[1].color = D3DCOLOR_ARGB(255, 255,255,255);
			exp->verts[2].color = D3DCOLOR_ARGB(255, 255,255,255);
			exp->verts[3].color = D3DCOLOR_ARGB(255, 255,255,255);

			break;
		}
	}
	
	// take all powerups away from player
	player.powerup = PU_START;

	// take a life from player
	player.lives--;

	// is player out of lives?...
	if (player.lives <= 0){
		gameover_time = GetTickCount();
		game_state = GS_GAMEOVER;
	}
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// void render_quad_alpha(int x, int y, int sizex, int sizey, float z)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Renders a with top left starting at x,y with dimensions sizex,sizey
// z is for z positioning
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
void render_quad_alpha(int x, int y, float z, int sizex, int sizey, LPDIRECT3DTEXTURE8 tex)
{
	static TRANSFORMED_VERTEX_ALPHA verts[4];
	
	// *START* should move all this crap init stuff out of the rendering pipeline
	// !OR use a vertex shader
	verts[0].x = (float)x;
	verts[1].x = (float)x;
	verts[2].x = (float)x + (float)sizex;
	verts[3].x = (float)x + (float)sizex;

	verts[0].y = (float)y + (float)sizey;
	verts[1].y = (float)y;
	verts[2].y = (float)y + (float)sizey;
	verts[3].y = (float)y;

	verts[0].rhw = 1.0f;
	verts[1].rhw = 1.0f;
	verts[2].rhw = 1.0f;
	verts[3].rhw = 1.0f;

	verts[0].z = z;
	verts[1].z = z;
	verts[2].z = z;
	verts[3].z = z;

	verts[0].color = D3DCOLOR_ARGB(255, 255,255,255);
	verts[1].color = D3DCOLOR_ARGB(255, 255,255,255);
	verts[2].color = D3DCOLOR_ARGB(255, 255,255,255);
	verts[3].color = D3DCOLOR_ARGB(255, 255,255,255);
	
	verts[0].tu = 0.0f;
	verts[1].tu = 0.0f;
	verts[2].tu = 1.0f;
	verts[3].tu = 1.0f;

	verts[0].tv = 1.0f;
	verts[1].tv = 0.0f;
	verts[2].tv = 1.0f;
	verts[3].tv = 0.0f;
	// *END* should move all this crap init stuff out of the rendering pipeline

	g_pd3dDevice->SetTexture(0, tex);
	g_pd3dDevice->SetVertexShader(D3DFVF_CUSTOM_TRANSFORMED_VERTEX_ALPHA); 
	g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, verts, sizeof(TRANSFORMED_VERTEX_ALPHA));
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// void restart_game(void)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// USAGE:
//			initalised game state to a new game
//			call when player selects start
//			Ensure all init functions have been called at least once
//			some init functions are called here, however it is better
//			to call them all once at application load.
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
void restart_game(void)
{
	enemy_alive = 0;
	round = 0;
	
	seed_random();
	init_enemies();
	init_bullets();
	init_player();
	init_player_bullet();
	init_explosions();
	

	// show intro
	game_state = GS_INTRO;
	// show main menu
	game_state = GS_MAINMENU;

	
	// start game
	game_state = GS_GETREADY;
	render();

	level_time = GetTickCount();

}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// void create_powerup(int type, float x, float y)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// USAGE:
//			Creates a powerup of kind type at given location x,y
//			see enum POWERUP for definitions of powerup types
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
void create_powerup(int type, float x, float y)
{
	for (int j=0; j<MAX_POWERUPS; j++){
		if (powerup[j].alive == false){// use this slot for new powerup
			
			powerup_t *po = &powerup[j];
			
			po->type = type;
			po->x = x;
			po->y = y;
			po->sx = 14.0f;
			po->sy = 14.0f;
			po->frame = 0;
			po->speed = 1;
			po->alive = true;
			po->lastframe = GetTickCount();

			po->verts[0].x = x - po->sx;
			po->verts[1].x = x - po->sx;
			po->verts[2].x = x + po->sx;
			po->verts[3].x = x + po->sx;
			po->verts[0].y = y + po->sy;
			po->verts[1].y = y - po->sy;
			po->verts[2].y = y + po->sy;
			po->verts[3].y = y - po->sy;

			static float uv[8];
			frame_blit(po->frame, 4, 4, uv);

			po->verts[0].tu = uv[2];
			po->verts[1].tu = uv[0];
			po->verts[2].tu = uv[4];
			po->verts[3].tu = uv[6];
			po->verts[0].tv = uv[3];
			po->verts[1].tv = uv[1];
			po->verts[2].tv = uv[5];
			po->verts[3].tv = uv[7];

			po->verts[0].color = D3DCOLOR_ARGB(255, 255,255,255);
			po->verts[1].color = D3DCOLOR_ARGB(255, 255,255,255);
			po->verts[2].color = D3DCOLOR_ARGB(255, 255,255,255);
			po->verts[3].color = D3DCOLOR_ARGB(255, 255,255,255);

			po->verts[0].z = 0.7f;
			po->verts[1].z = 0.7f;
			po->verts[2].z = 0.7f;
			po->verts[3].z = 0.7f;
			break;
		}
	}
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// void init_powerups(void)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// USAGE:
//			Initialises all powerups for usage
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
void init_powerups(void)
{
	for (int j=0;j<MAX_POWERUPS;j++){
		powerup[j].type = 0;
		powerup[j].alive = false;
	}
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// void update_powerups(void)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// USAGE:
//			Cycles through all active powerups and updates rendered frame
//			Checks if player shoots powerup and advances powerup type by 1
//			Checks if player picks up powerup
//			*TODO* give player powerup abilities
//
// FUNCTIONS REQUIRED: 	GetDistanceFast2D();	
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
void update_powerups(void)
{
	for (int j=0;j<MAX_POWERUPS;j++){
		
		if (powerup[j].alive == true){

			powerup_t *po = &powerup[j];
			
			po->y = po->y + po->speed;
			
			if (GetTickCount() - po->lastframe >= 66){

				po->frame++;
				po->lastframe = GetTickCount();

				if (po->frame >= 16){
					po->frame = 0;
				}

				static float uv[8];
				frame_blit(po->frame, 4, 4, uv);

				po->verts[0].tu = uv[2];
				po->verts[1].tu = uv[0];
				po->verts[2].tu = uv[4];
				po->verts[3].tu = uv[6];
				po->verts[0].tv = uv[3];
				po->verts[1].tv = uv[1];
				po->verts[2].tv = uv[5];
				po->verts[3].tv = uv[7];
				
				po->verts[0].y = po->y + po->sy;
				po->verts[1].y = po->y - po->sy;
				po->verts[2].y = po->y + po->sy;
				po->verts[3].y = po->y - po->sy;

				
				// check if player picks up this powerup
				float dist = GetDistanceFast2D(po->x, po->y, player.x, player.y);
				if (dist <= (player.sizex + po->sy*0.5) ){

					PlaySound(sample_playerup);
					po->alive = false;
					player.powerup = po->type;
					player.poweruptime = GetTickCount();
				}

				// check if player shoots this powerup
				if (player.bullet == true){
					dist = GetDistanceFast2D(po->x, po->y, player.bulletx, player.bullety);
					if (dist <= (po->sy*2) ){
						player.bullet = false;
						po->type++;
						if (po->type >= PU_END){
							po->type = PU_START + 1;
						}
					}
				}
				
				// kill powerup when it goes offscreen
				if (po->y > SCREEN_SIZE_Y+po->sy){
					po->alive = false;
				}

			}
		}
	}
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// void init_mothership(void)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// USAGE:
//			Initialises mothership for use ingame - only call at app start
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
void init_mothership(void)
{
	mothership.speed = 5;
	mothership.alive = false;

	mothership.sx = 20;
	mothership.sy = 20;

	mothership.speed = 3.0f;
	mothership.y = 40;

	mothership.verts[0].z = 0.6f;
	mothership.verts[1].z = 0.6f;
	mothership.verts[2].z = 0.6f;
	mothership.verts[3].z = 0.6f;

	mothership.verts[0].tu = 0.0f;
	mothership.verts[1].tu = 0.0f;
	mothership.verts[2].tu = 1.0f;
	mothership.verts[3].tu = 1.0f;

	mothership.verts[0].tv = 1.0f;
	mothership.verts[1].tv = 0.0f;
	mothership.verts[2].tv = 1.0f;
	mothership.verts[3].tv = 0.0f;

	mothership.verts[0].y = mothership.y + mothership.sy;
	mothership.verts[1].y = mothership.y - mothership.sy;
	mothership.verts[2].y = mothership.y + mothership.sy;
	mothership.verts[3].y = mothership.y - mothership.sy;

	mothership.verts[0].color = D3DCOLOR_ARGB(255, 255,255,255);
	mothership.verts[1].color = D3DCOLOR_ARGB(255, 255,255,255);
	mothership.verts[2].color = D3DCOLOR_ARGB(255, 255,255,255);
	mothership.verts[3].color = D3DCOLOR_ARGB(255, 255,255,255);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// void check_mothership(void)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// USAGE:
//			Checks if it is time to respawn mothership
//			Currently spawns a ship when half the enemies in a stage are
//			destroyed *TODO* make this a little less linear...
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// FUNCTIONS REQUIRED: new_mothership()
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// GLOBALS USED: bool done_mothership, int enemy_alive, int total_enemies
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
void check_mothership(void)
{
	if (done_mothership == false){
		if ( enemy_alive <= (total_enemies*0.5f) ){
			done_mothership = true;
			new_mothership();
		}
	}
}

void new_mothership(void)
{
	mothership.alive = true;
	mothership.x = SCREEN_SIZE_X + mothership.sx;
	mothership.y = 40;
	PlaySound(sample_mothership);

}

void update_mothership(void)
{
	if (mothership.alive == true){
		
		
		mothership.x = mothership.x - mothership.speed;

		// see if mothership goes offscreen
		if (mothership.x <= (0-mothership.sx)){
			mothership.alive = false;
			return;
		}

		// see if player shoots mothership
		if (player.bullet == true){
			float dist = GetDistanceFast2D(mothership.x, mothership.y, player.bulletx, player.bullety);

			//mothership hit by player bullet
			if (dist <= mothership.sy){
				mothership.alive = false;
				add_explosion(mothership.x, mothership.y, mothership.sx*1.25f, mothership.sy*1.25f);
				player.bullet = false;
				player.score = player.score + 1000;
				PlaySound(sample_killmship);
				return;
			}
		
		}
		
		// update mothership pos if still alive
		mothership.verts[0].x = (float)mothership.x - mothership.sx;
		mothership.verts[1].x = (float)mothership.x - mothership.sx;
		mothership.verts[2].x = (float)mothership.x + mothership.sx;
		mothership.verts[3].x = (float)mothership.x + mothership.sx;
	}

}

void display_scores(void)
{
	TextOut(100, 2, round);
	TextOut(350, 2, player.score);
	TextOut(585, 2, player.lives);
}
