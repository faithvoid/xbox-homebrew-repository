/*
 * Heart of Darkness engine rewrite
 * Copyright (C) 2009-2011 Gregory Montoir (cyx@users.sourceforge.net)
 */

#ifndef LZW_H__
#define LZW_H__

int decodeLZW(const uint8_t *src, uint8_t *dst);

#endif // LZW_H__

