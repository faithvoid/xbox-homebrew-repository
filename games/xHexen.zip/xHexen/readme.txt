xHexen v1.1 ported by A600

What's New
----------

- Added a wad selector (read below)
- Added HDTV modes, thanks to Lantus. For 720p, use the default720.xbe
- Fixed the joypad sensitivity for look up/down

This is an update so you need the v1.0 version. Overwrite the default.xbe
and edit and copy the wads.cfg file if you want to use the wad selector.



This port is based on HHexen, UHexen and Hexen32 (my GP32 port) and
it was possible thanks to the SDLx libs by Lantus.

Copy the full or shareware version (hexen.wad) to the folder where you installed xHexen

IMPORTANT NOTE: Don't use the 1.0 version of the full game (20.128.392 bytes)
because there are some problems with it. Use instead 1.1 or 1.2 (20.083.672 bytes) versions.


WAD SELECTOR
------------

Edit the wads.cfg included and add as many entries as you want.

The syntax is very easy:

[name displayed] = [commandline options]

Copy it to the xHexen folder along with the wads.
Next time you run xHexen, a wads selector will be displayed.
If the wads.cfg only has one entry, the wads selector won't appear
and it'll run that entry.

You can add up to 4000 entries and use options like -warp, etc

Here is an example:

#Hexen wads
Hexen = 
Death Kings of the Dark Citadel = -file hexdd.wad -nomusic
Caldera = -file caldera.wad
Centromere = -file cent092b.wad
Chuxen: Beyond Hexen = -file chuxen.wad
HexQuake = -file hexquake.wad
The Dark Portal = -file drkportl.wad
Undermountain = -file black.wad


CONTROLS
--------

Left Analog 		-> Move Forward/Backward - Strafe
Left Analog Thumb 	-> Center Fly
Right Analog 		-> Turn Right/Left - Look Up/Down
Right Analog Thumb 	-> Center View
Left Trigger 		-> Run
Right Trigger 		-> Shoot
White 			-> Fly Up
Black 			-> Fly Down
A			-> Activate - Select Menu Option - Confirm
B 			-> Use Inventory Object - Back to the Previous Menu
X 			-> Jump
Y 			-> Map On/Off
DPad Up 		-> Next Weapon
DPad Down 		-> Previous Weapon
DPad Left 		-> Inventory Left
DPad Right 		-> Inventory Right
Start			-> Main Menu


VIEW MAP CONTROLS
-----------------

Left Analog 		-> Move Map
Right Analog 		-> Zoom In/Out
A			-> Follow Mode On/Off
B 			-> Reset Zoom



-A600-