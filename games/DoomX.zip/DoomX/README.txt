===========================
 	 DOOM-X 
 
 by Carcharius, LikkleBaer
===========================



v2.2 Beta
---------

Bug-fixes, ui updates



What's New
----------

- Save freezing bug fixed

- New UI background



WAD Setup
---------

Doom-X is not a standalone program. It requires you to have the WAD data files from the PC version of each Doom game that you wish to play. These files are located in the game's main directory and have the .wad extension. Put your Doom WAD files in Doom-X's 'WADs' directory, each supported WAD has its own folder, and ensure they are named as follows:


	GAME				FOLDER				NAME
	----				------				----
	Doom (retail version)		Doom/				DOOM.WAD
	Doom (shareware version)	DoomS/				DOOM1.WAD
	Doom II				Doom II/			DOOM2.WAD
	Ultimate Doom			Ultimate Doom/			DOOMU.WAD
	Final Doom: TNT	Evilution	Final Doom/TNT			TNT.WAD
	Final Doom: Plutonia Exp.	Final Doom/Plutonia		PLUTONIA.WAD


If you do not currently have any main WAD files to use with Doom-X then multiple versions of the shareware release can be found here: 

http://doomworld.com/pageofdoom/shareware.html

Custom mods in the form of pWAD files are also supported. Each main game folder in the WADs/ directory now has a sub-folder called 'custom' inside it. Any pWAD files you have should be placed in the 'custom' folder of whichever version of Doom the mod requires to run (check the documentation that comes with your mod to find out which Doom to use it with). For example, if you have a pWAD called BAERDOOM.WAD that is intended for use with Doom II, you would place it in WADS/Doom II/custom/



Using Mods
----------

To view custom mods on the launcher screen, highlight the name of a main game and push the Black button. All available mods for that version of Doom should now appear in a list beneath it. Highlight the mod you wish to play and press the A button to start playing the customized game or return to the main game list by pressing the B button.

Some mods only make changes to a single map in the game. To start on a map other than the default first one, highlight the mod that you wish to play and use the left and right D-Pad controls to change the START MAP setting to whichever map your mod uses (check the mod's documentation for this info).

NOTE: Many mods that are available on the net come with .DEH patches that are intended to be applied to the Doom executable in order for the mod to run correctly. This type of modification is not supported by Doom-X and the majority of mods that require it will not work. These include Aliens TC, Wolfendoom, and others.

For additional info on mods see Q & A section below.
	


Controls
--------

There are four different controller presets available. You can select your preferred configuration in the setup menu. The button layouts for the various presets are as follows:

	In-Game Controls - Default
	--------------------------
	L Analogue Stick	Walk and Strafe
	R Analogue Stick	Turn
	A			Open Door/Use Switch
	B			Next Weapon
	X			Previous Weapon
	L Trigger		Run
	R Trigger		Fire Weapon
	Back			Toggle Map/Automap
	Start			Display Menu


	Map Controls - Default
	----------------------
	D-Pad			Pan View
	White			Zoom in
	Black			Zoom out
	Y			Toggle follow mode
	L Analogue Stick	Walk and Strafe
	R Analogue Stick	Turn
	A			Open Door/Use Switch
	B			Next Weapon
	X			Previous Weapon
	L Trigger		Run
	R Trigger		Fire Weapon
	Back			Toggle Map/Automap
	Start			Display Menu


	In-Game Controls - Southpaw
	---------------------------
	L Analogue Stick	Turn
	R Analogue Stick	Walk and Strafe
	A			Open Door/Use Switch
	B			Next Weapon
	X			Previous Weapon
	L Trigger		Fire Weapon
	R Trigger		Run
	Back			Toggle Map/Automap
	Start			Display Menu
	

	Map Controls - Southpaw
	-----------------------
	D-Pad			Pan View
	White			Zoom in
	Black			Zoom out
	Y			Toggle follow mode
	L Analogue Stick	Turn
	R Analogue Stick	Walk and Strafe
	A			Open Door/Use Switch
	B			Next Weapon
	X			Previous Weapon
	L Trigger		Fire Weapon
	R Trigger		Run
	Back			Toggle Map/Automap
	Start			Display Menu


	In-Game Controls - Legacy
	--------------------------
	L Analogue Stick	Walk and Turn
	R Analogue Stick	Strafe
	A			Open Door/Use Switch
	B			Next Weapon
	X			Previous Weapon
	L Trigger		Run
	R Trigger		Fire Weapon
	Back			Toggle Map/Automap
	Start			Display Menu


	Map Controls - Legacy
	---------------------
	D-Pad			Pan View
	White			Zoom in
	Black			Zoom out
	Y			Toggle follow mode
	L Analogue Stick	Walk and Turn
	R Analogue Stick	Strafe
	A			Open Door/Use Switch
	B			Next Weapon
	X			Previous Weapon
	L Trigger		Run
	R Trigger		Fire Weapon
	Back			Toggle Map/Automap
	Start			Display Menu


	In-Game Controls - Legacy Southpaw
	----------------------------------
	L Analogue Stick	Strafe
	R Analogue Stick	Walk and Turn
	A			Open Door/Use Switch
	B			Next Weapon
	X			Previous Weapon
	L Trigger		Fire Weapon
	R Trigger		Run
	Back			Toggle Map/Automap
	Start			Display Menu


	Map Controls - Legacy Southpaw
	------------------------------
	D-Pad			Pan View
	White			Zoom in
	Black			Zoom out
	Y			Toggle follow mode
	L Analogue Stick	Strafe
	R Analogue Stick	Walk and Turn
	A			Open Door/Use Switch
	B			Next Weapon
	X			Previous Weapon
	L Trigger		Fire Weapon
	R Trigger		Run
	Back			Toggle Map/Automap
	Start			Display Menu


	Menu Controls - All
	-------------------
	D-Pad			Move Cursor/Sliders
	A			Select
	Y			Y / Enter save name	
	B			Back / N
	Start			Close Menu



System Link
-----------

NOTE: The System Link feature is still very much a work-in-progress so it may not work 100% correctly 100% of the time. Thus far it has only been tested on a LAN with 2 Xboxes though up to 4 should work fine. Detailed and constructive feedback on this feature would be appreciated.

ALSO NOTE: System Link is only available for main game WADs and cannot be used with mods.

Doom-X allows up to 4 Xboxes to be linked together for Deathmatch or Co-operative play. To do this, first ensure that your consoles are linked correctly using the method described in the Xbox manual. Choose an Xbox to be the host machine then, in the Doom-X launcher, highlight the game you wish to play and press the White button to display the System Link menu. This contains a randomly generated name for the linked game and the following setup options:

PLAYERS - Sets number of players 1-4

DEATHMATCH - NORM = Standard Deathmatch
	     ALT  = Deathmatch with respawning items
	     OFF  = Co-operative game

NO MONSTERS - ON/OFF

WARP - Sets the map on which to start the game

After altering these settings to your liking select the 'HOST' option at the bottom of the menu. The game is now set up and will start when the number of currently connected players has reached the number specified in the PLAYERS setting above. This process can be aborted at any time by pressing the B button. 
To have the other linked Xboxes join the game, make sure you highlight the same main WAD from the launcher, press White, and select the 'JOIN' option. If there is only one game being hosted then no further action is required since it will be joined automatically. If multiple games are being hosted then it is simply a case of selecting which game you wish to join from the list that appears.




Q & A
-----

Q: Why didn't you port JDoom/Doom Legacy/other 'enhanced' version of Doom instead?

A: Because in my opinion the original Doom is still the best. Adding things like 3D graphics, full look-around, and jump controls, does nothing to enhance the experience for me and in some cases even ruins the claustrophobic feel that made the original Doom so exciting.


Q: Can you please add this feature or that feature?

A: Probably not. Feature-wise, Doom-X is pretty close to complete. If your most wanted addition isn't in there then it's probably because we chose not to include it. Sorry.


Q: How do I save/load a game?

A: Just choose Save Game from the menu and select a slot with A. When the prompt appears press Y to automatically create a name and then A again to create the save file. Each version of Doom has its own set of independent save slots which are used for both main game and mod saves. To restore a saved game simply choose Load Game from the menu and select the game you wish to load from the list.


Q: Does Doom-X run from disc?

A: Yes, but you may occasionally experience a momentary in-game freeze. This happens when Doom-X accesses the disc to obtain data from the WAD file but is brief and infrequent.


Q: How do I change the resolution?

A: Resolution mode is now changed via the Setup menu. Press X on the launcher screen.


Q: Why doesn't my favourite mod work?

A: If this is the case, first make sure you have the pWAD set up for use with the correct main game (a WAD intended for Doom will not necessarily work with Ultimate or Shareware Doom). Next ensure that the mod is not one that requires a .DEH patch by checking that one is not included in the original archive. And if your mod only makes changes to one map in the game then make sure you set the correct start map on the launcher. Also see next Q.


Q: My favourite mod freeze up whilst playing, what should I do?

A: Doom-X is a port of WinDoom so if it crashes in the PC version it's likely to do the same thing in Doom-X.

 
Q: How do I play a mod that has 2 pWADs?

A: The only way to get mods that consist of more than one pWAD to load in Doom-X is to use a PC WAD editor such as WinTEX to merge them into a single file. If done correctly it should then work as normal. See the documentation of your chosen editing program for details on how to do this.


Q: Can I rename my mod files?

A: Yes, your pWAD files can be named whatever you like within the limitations of the FAT-X file system. The only exception is that the names cannot contain the '-' character since this causes Doom-X to interpret the command line incorrectly and the mod will not work.


Q: Why can't I change the start map for main games and co-op games?

A: Because this function is only intended for use with mods and Deathmatch games. If you're really desperate to play a specific level from a main WAD then just use a custom mod in which that level is unchanged.


Q: Does the System Link feature work with tunnelling applications such as XLink Kai or XBConnect? 

A: This has not been tested AT ALL. So the answer is it may work and it may not. Give it a try and let us know.


Q: What happens if I choose a different main WAD when joining a System Link game?

A: Just don't ;)


Q: Why can't I use the System Link feature with mods?

A: Cos you can't :p


Q: Will you marry me?

A: Maybe.



Planned Features
----------------

Not many now :)



Thankies to
-----------

Carcharius - for doing just about everything ^_^

Lantus - for the original Doom-X and for the Xbox SDL port

Bero - for the DoomDC source

Bruce Lewis - for the WinDoom source

Id Software - for making this classic game open-source in the first place



Comments or Questions
---------------------

http://forums.xbox-scene.com



Version History
---------------


v2.0 Beta
---------

As you can see, this is a huge release. It implements pretty much every feature we wanted to include in Doom-X and a few more besides. Any future releases will be primarily focused on bug-fixes, tweaks, and tidy-ups.
So, without further time-wasting, check out the list of changes below and enjoy this new version. ^_^


What's New
----------

- Mod support (pWADs only) with selectable Start Map

- System link support for up to 4 players added (*extremely experimental* see below   for details)

- Graphics rendering code rewritten (performance gain)

- Turning controls now fully analogue

- 3 alternate controller configurations added (Legacy, Southpaw, and Legacy Southpaw)

- Now detects controller in the lowest numbered port

- Setup menu added to launcher for resolution mode and other settings

- Start map can be changed for mods

- Updated launcher with graphics, sound effects and new options

- Xbox save games with title and save images added (saves from older versions should   transfer automatically)

- Freezing issues should be fixed

- Fixed weapon cycling order bug

- Fixed map panning controls

- Fixed consecutive WAD loading bug

- '.'s in startup text now display correctly

- In-game menu bug fixed (Quit Game showing twice)

- Other small bugfixes



v1.1 Beta
---------

Bug-fix release.


What's New
----------

- Fixed weapon sound bug

- Fixed freezing when controller is unplugged

- Renamed XBE to 'default.xbe'



v1.0 Beta
---------

This is it! The long-awaited revival of Doom on the Xbox. It's based on lantus' Doom-X which is based on Bruce Lewis' WinDoom which is based on the original source by Id. Anyways, lots of new features and improvements to enjoy. So have fun ^_^.


What's New
----------

- New title screen

- MIDI music

- WAD selector

- Fixed weapon select bug

- Menu sliders fully functional

- New control system and button mappings (see below)

- New Per-WAD save system

- Selecting 'Quit Game' now returns to the WAD selector

- Various additional bugfixes
