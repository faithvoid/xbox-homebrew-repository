Doom Legacy - XBOX Port
-----------------------

Version: 0.05.142 pre-alpha


Merry Christmas!

This is an early version of a port of Doom Legacy v1.42



I wanted to get a proper release done by now, but I haven't had time, so I
decided to release a version as it is, as a present to the scene.

The work was started by lantus, who had partially ported an older legacy version.
He kindly passed the work he had done over to me, I used that as a basis for porting
the more recent v1.42 - So big props to lantus for kicking the whole project off.

As stated above - this is a pre-alpha release. Lots of stuff isn't implemented yet
and there may well be a lot that doesn't work properly. 

Please be aware of this and don't expect it to be perfect!

That being said, there is plenty that does work, including....

 - All Doom games should work (Doom, Doom II, Ultimate Doom and Final Doom)
 - Heretic works (Hexen isn't supported in this version of Doom Legacy)
 - Two player split screen works
 - Network play should work
 - IWAD files shown in launcher can be adding to/changing by editing the wads\iwads.xml file
 - XBOX specific in game options, including control setups
 - Video mode can be set/changed from Doom Legacy options


This should be enough information to get you up and playing. I don't want to go into too much 
detail as this is a very, very early version so things are liable to change in the future.

Seasons Greetings!

Carcharius



Notes
-----

Launcher:

This release consists of 2 xbe files - default.xbe (the launcher application) and DoomLegacy.xbe
(the Doom Legacy application itself)

Both of these need to be present in order for things to work properly.

The launcher is just something quick and dirty that I threw together, just to get some wad
selection facility in there (see wad files section below). Later releases will be much improved.



Wad files:

Wad files need to be placed in the wads\iwads folder.
Images to use in the launcher for each wad should be placed in the wads\images folder.

Each IWAD needs a corresponding entry in the wads\iwads.xml file.

Each wad entry in the xml file consists of 3 parts - a name, a path (to the wad) and a path 
to an image file (that is displayed in the launcher).

The structure of the file should be fairly self explanatory and isn't complicated, so I won't
go into too much detail.



Network play:

I say that this should work - I haven't actually tested an xbox<->xbox game. 
But it does work xbox<->pc Doom Legacy 1.42.



Thanks
------

Big thanks to the Doom Legacy team (legacy.newdoom.com)
Thanks to lantus for starting the xbox port and for porting the SDL libraries.


Contact
-------

forums.xbox-scene.com
