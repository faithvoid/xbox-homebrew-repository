.-=-=-=-=-=-=-=-=-=-=-.
|InvaderX version 3.0|
.=-=-=-=-=-=-=-=-=-=-='

This will be the last release of InvaderX, now named INVADER-X3

Some people are having problems with screen being cut off, this is because your television does not fully
support 640x480 resolution. I could have fixed this by lowering the resolution of InvaderX,
but i didnt so sorry to those that are effected. I will add option for this mode in all future XBOX games i release.

Features added since Ver 1:

 Sound is now working - Thanks chossy
 Text Output - Thanks Ben3D
 WMA support
 Attack Powerups
 Extra Lives
 Motherships
 Another Enemy Type
 Main Menu
 Accuracy ratings
 Powerups
 Removed music due to file size
 As of version 3 i have also released the source code. Find it included in the archive.

Fixes : Gross looking explosions. XBOX's Z-Buffer work 'slightly' different the the PC DirectX equivalent.
Misc other stuff

//=-=-=-=-=-=-=-=-=-

I dont have alot of time to develop for the xbox due to real world commitments,
however things to look out in next release:

Mail me lubby@hushmail.com for code talk or whatever

those in #xbox-dev please contact me

greetz #xbins & #xfactor

