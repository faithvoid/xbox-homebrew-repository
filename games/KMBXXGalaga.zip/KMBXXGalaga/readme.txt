KMBXXGalaga
===========

Port/Adaptation XBOX du jeu XGalaga par KaMbiOkIkA (GueuX'Net - 2K4).

Sute Officiel	:	http://sourceforge.net/projects/xgalaga-sdl/

Commandes
*********

Start/A Demarrer Une Partie/Pause/Reprise
Back	Quitter Une Partie/Retour Au DashBoard
GamePad Deplacement
JoySticks Analogiques Gauche/Droit        Calibration ecran (sur menu 
                                          principal uniquement)

www.gueux.net