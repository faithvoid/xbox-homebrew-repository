KMBXDelirium
============

Port/Adaptation XBOX du jeu Delirium par KaMbiOkIkA (GueuX'Net - 2004).

Createur original : Mika Halttunen	http://mhgames.cjb.net/

Commandes Menus
***************

Start/A Valider
Back  	Quitter/Annuler
JoySticks Analogiques Gauche/Droit        Calibration ecran

Commandes Jeu
*************

Start	Pause/Reprise
Back  	Quitter La Partie
A	Tirer
Stick Gauche	Deplacer Le Canon
Stick Droit     Tourner Le Canon

www.gueux.net